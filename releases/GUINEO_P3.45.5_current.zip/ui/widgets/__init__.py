"""SpeechStudio shared UI widgets."""

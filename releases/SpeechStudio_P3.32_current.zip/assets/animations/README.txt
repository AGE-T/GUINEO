SpeechStudio — Model Load Animation (P3.32)
=============================================

Drop an animated file here to upgrade the "Loading Model" dialog with a
hero animation:

    model_load.webp   (preferred — animated WebP)
    model_load.gif    (fallback — animated GIF)

These are exactly the two animated formats this Qt build's QMovie plays
(probed at runtime: QMovie.supportedFormats() == ['gif', 'webp']).

Export specification
--------------------
* Export at 2x for crisp HiDPI rendering: the file is scaled
  aspect-preserving into a 140x140 logical (device-independent) box,
  so a square loop should be exported at 280x280 px.
* Infinite seamless loop, 24-30 fps.
* With transparency (WebP has full 8-bit alpha) so the animation sits
  cleanly on the dark dialog surface — or bake the dark background
  into the frames. GIF only has 1-bit alpha (hard edges); prefer WebP.
* Keep it small: ideally under ~1.5 MB.
* No audio track (strip it when exporting from a video editor).

Behaviour
---------
* WebP is preferred when both files exist; the first file that decodes
  as a valid MULTI-frame animation wins.
* Any problem (missing file, corrupt file, static single-frame image)
  silently falls back to the classic progress-bar layout — the dialog
  can never break because of this asset.
* VIDEO formats (mp4/webm) are intentionally NOT supported: they would
  require the Qt Multimedia backend/codec stack for no benefit (no
  alpha channel, heavier runtime) — and during the initial
  `import torch` GIL starvation the animation would stall exactly like
  a QMovie does, because every frame is composited on the GUI thread.

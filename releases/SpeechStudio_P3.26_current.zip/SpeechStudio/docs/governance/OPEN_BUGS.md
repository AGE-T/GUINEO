# SpeechStudio Open Bugs / Documentation Backlog

This file tracks known issues that have NOT yet been fixed. Each
entry is removed from this file only after the fix is implemented
AND independently verified.

**Status legend:**
- **OPEN** — not yet fixed
- **FIXED-PENDING-VERIFICATION** — fix implemented, awaiting
  independent verification of exact preview/model equality
- **CLOSED** — fixed and independently verified

---

## BUG-001: Advanced Preview emits invalid `expressive_normal` token

- **Status**: FIXED-PENDING-VERIFICATION
- **Severity**: Critical (prompt correctness)
- **Discovered**: Post-FINAL-CORRECTION audit
- **ADR reference**: ADR 003 §7
- **Fix applied**: `engine/prompt_state.py` `compile_continuous()`
  now skips emission of any prosody token when the effective value
  is `"Normal"` or `None` — matching `PromptBuilder.build()` behavior.

### Description

The Advanced Preview (`CanonicalPromptCompiler.compile_continuous()`)
and the center Preview (`CanonicalPromptCompiler.compile_for_generate()`
→ `PromptBuilder.build()`) did not produce identical token sequences.

`compile_continuous()` could emit:

```
<|prosody:expressive_normal|>
```

while the center Preview correctly produced NO token for "Normal"
delivery. The same issue applied to `speed_normal` and `pitch_normal`.

### Root Cause

1. `engine/higgs_tokens.py` defines placeholder
   `ProsodyDef("Normal", "expressive_normal", ...)` entries. These
   are application-level "no-op" markers — NOT valid HIGGS V3 tokens.

2. The official HIGGS V3 reference defines only:
   - Speed: `speed_very_slow`, `speed_slow`, `speed_fast`, `speed_very_fast`
   - Pitch: `pitch_low`, `pitch_high`
   - Delivery: `expressive_high`, `expressive_low`
   
   There is NO `*_normal` token in HIGGS V3.

3. `PromptBuilder.build()` correctly checked `!= "Normal"` before
   emitting. `compile_continuous()` did NOT — it emitted a token
   whenever the value changed, including to "Normal".

### Fix Applied

`compile_continuous()` (in `engine/prompt_state.py`) now skips
emission for any prosody value that is `"Normal"` or `None`. The
`prev` tracker is reset to `None` when a "Normal" value is
encountered, so that a subsequent non-Normal value correctly emits
(e.g. Normal→High→Normal emits `expressive_high` once for the
middle block, nothing for the first and last).

### Verification Performed

The following tests were run and PASS:

1. **Required test** — 3 blocks with Delivery Normal/Expressive
   High/Normal:
   - Block 1 (Normal) → no expressive token ✓
   - Block 2 (Expressive High) → `<|prosody:expressive_high|>` ✓
   - Block 3 (Normal) → no `expressive_normal` token ✓

2. **Expanded test** — Speed Normal, Pitch Normal, Delivery Normal
   individually and combined:
   - None produces a HIGGS token ✓
   - No `*_normal` token in any output ✓

3. **Preview Hard Contract** — Center Preview vs Advanced Preview
   for 10 different configurations (emotion, style, speed, pitch,
   delivery, all-Normal, all-non-Normal):
   - All 10 produce IDENTICAL prompt strings (exact match) ✓
   - No `*_normal` tokens in any path ✓

### Why Status is FIXED-PENDING-VERIFICATION (not CLOSED)

Per the user's directive: "Until exact preview/model equality is
independently demonstrated, BUG-001 remains OPEN."

The fix is implemented and the automated tests pass, but the status
remains FIXED-PENDING-VERIFICATION until an independent audit
confirms that:
1. The exact final prompt string is identical across Center Preview,
   Advanced Preview, and the actual model input.
2. No `*_normal` token reaches the model in any code path.
3. The fix survives a real generation test (not just unit tests).

An independent reviewer should re-run the tests above and additionally
verify the model input path end-to-end before marking this CLOSED.

### Related Files

- `engine/prompt_state.py` — `compile_continuous()` (fixed)
- `engine/prompt_builder.py` — `build()` (reference for correct skip behavior)
- `engine/higgs_tokens.py` — token definitions (see BUG-002)
- `ui/panels/long_narration_dialog.py` — `_on_generate()` (refactored
  to use `CanonicalPromptCompiler` instead of direct `PromptBuilder`;
  removed the `<|` hybrid shortcut)

---

## BUG-002: `expressive_normal` / `speed_normal` / `pitch_normal` are not valid HIGGS V3 tokens

- **Status**: OPEN (partially mitigated by BUG-001 fix)
- **Severity**: Medium (documentation / catalog accuracy)
- **Related**: BUG-001

### Description

`engine/higgs_tokens.py` defines three "Normal" prosody tokens that
do NOT exist in the official HIGGS V3 reference:

| Application token       | Tag               | HIGGS V3? |
|-------------------------|-------------------|-----------|
| `ProsodyDef("Normal", "speed_normal", ...)` | `speed_normal` | ❌ NOT in reference |
| `ProsodyDef("Normal", "pitch_normal", ...)` | `pitch_normal` | ❌ NOT in reference |
| `ProsodyDef("Normal", "expressive_normal", ...)` | `expressive_normal` | ❌ NOT in reference |

### Current Mitigation

BUG-001's fix ensures these tags are never emitted by
`compile_continuous()`. `PromptBuilder.build()` already skipped them.
So no `*_normal` token reaches the model.

### Remaining Work

The placeholders still exist in `higgs_tokens.py` and are referenced
in the in-app Token Guide (`ui/panels/token_guide.py`). They should
be either:
1. Marked as `application_only=True` (non-emittable), OR
2. Removed from the token catalogue and represented differently in
   the UI (e.g. a "Default" option that maps to `None`).

The Token Guide must be corrected to not list them as valid HIGGS V3
tokens.

### Verification

After the fix:
1. `grep -rn "expressive_normal\|speed_normal\|pitch_normal" engine/`
   must return no matches in token-emitting code paths.
2. The Token Guide must not list these as valid HIGGS V3 tokens.
3. All verification scripts must pass.

---

## BUG-003: Prompt Pipeline Contract is not a standalone document

- **Status**: OPEN
- **Severity**: Low (documentation gap)
- **ADR reference**: ADR 003 §10

### Description

The Prompt Pipeline Contract is referenced in the codebase
(`engine/prompt_state.py`, `ui/main_window.py`,
`ui/panels/narration_editor.py`) as the authoritative specification
for the prompt pipeline. However, the contract is currently embedded
in code comments and docstrings — there is no standalone document.

### Required Fix

Extract the contract into a standalone document:
`docs/governance/PROMPT_PIPELINE_CONTRACT.md`.

The document must explicitly distinguish:
- **Application semantics** (SpeechStudio's scope rules, precedence,
  ownership model) — these are SpeechStudio decisions.
- **HIGGS V3 model semantics** (token syntax, placement rules,
  token catalogue) — these are defined by the model, not by
  SpeechStudio.

### Verification

After the fix:
1. `docs/governance/PROMPT_PIPELINE_CONTRACT.md` exists.
2. The contract is referenced from ADR 003 and the governance README.
3. The contract clearly distinguishes application semantics from
   HIGGS V3 model semantics.

---

## BUG-004: SemanticTokenState flattens sentence-scoped tokens to one global value

- **Status**: OPEN (architectural limitation — not a regression)
- **Severity**: Low (UI workflow removed — no current user impact)
- **ADR reference**: ADR 003 §3, §8
- **Do not refactor yet** — this is documented for future planning.

### Description

`SemanticTokenState` (in `engine/prompt_state.py`) flattens all
parsed tokens to a SINGLE value per category:

```python
@dataclass
class SemanticTokenState:
    emotion: Optional[str] = None    # ONE emotion, not per-sentence
    style: Optional[str] = None      # ONE style, not per-sentence
    speed: Optional[str] = None
    pitch: Optional[str] = None
    delivery: Optional[str] = None
    ...
```

Meanwhile, `ParsedToken` already tracks `sentence_identity` and
`block_identity`:

```python
@dataclass
class ParsedToken:
    category: str
    tag: str
    offset: int
    raw: str
    placement: str = "sentence_level"
    sentence_identity: int = 0
    block_identity: Optional[str] = None
    source: str = "manual_import"
```

So the parser knows WHICH sentence/block a token belongs to, but the
state object discards that information and keeps only the last value
of each category.

### Impact

- Multiple sentence-scoped token states CANNOT coexist correctly
  inside the same document when using inline `<|...|>` tokens (the
  SemanticTokenState path).
- Example: if the user writes
  `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
  the state will have `emotion = "Awe"` (the last value wins) — the
  fear emotion for sentence one is lost.

### Current Mitigation — UI Workflow Removed

The Read Tokens UI workflow (which was the only consumer of
`SemanticTokenState`) has been **REMOVED** from the application:

- The "Read Tokens" button has been removed from the NarrationEditor
  mode bar.
- The `read_tokens_requested` signal has been removed.
- The `_on_read_tokens()` handler has been removed from MainWindow.
- The `self._token_state` instance variable has been removed from
  MainWindow. `token_state=None` is now always passed to the
  compiler.
- All "PROMPT OUT OF SYNC" stale-state checks have been removed.
- All "imported token state" UI text has been removed.

The `SemanticTokenState` and `SemanticTokenParser` classes still
exist in `engine/prompt_state.py` for engine-level API compatibility,
but they are no longer used by any UI workflow.

### No Current User Impact

This limitation does NOT affect any current user workflow:

1. **Managed Mode with Narration Blocks** — per-block overrides are
   stored on each `PromptBlock` object (NOT in `SemanticTokenState`).
   The continuous compiler (`compile_continuous`) resolves each block
   independently. Multiple block-scoped emotions/styles/prosody values
   DO coexist correctly. **Verified by regression test (see below).**

2. **Raw Mode** — the user writes literal tokens in the text. No
   parsing into `SemanticTokenState` occurs. Each token stays at its
   exact position in the text. Multiple sentence-scoped tokens
   coexist correctly by definition.

3. **Managed Mode without blocks** — only global defaults apply. There
   is only one emotion/style/prosody value per generation. No
   coexistence issue.

### Regression Test Performed

The following test verifies that Narration Blocks (the primary
multi-scope workflow) preserves per-block token states correctly:

1. **Block 1 Emotion=Fear, Block 2 Emotion=Awe**:
   - Result: `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
   - Both emotions present at correct boundaries ✓

2. **Block 1 Style=Whispering, Block 2 Style=Singing**:
   - Result: `<|style:whispering|>Sentence one. <|style:singing|>Sentence two.`
   - Both styles present at correct boundaries ✓

3. **Block 1 Pitch=Low, Block 2 Pitch=High**:
   - Result: `<|prosody:pitch_low|>Sentence one. <|prosody:pitch_high|>Sentence two.`
   - Both pitches present at correct boundaries ✓

4. **Combined (Fear+Whispering+Low / Awe+Singing+High)**:
   - All 6 tokens present, block boundaries respected ✓

The SemanticTokenState flattening was also tested and confirmed:
parsing `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
produces `state.emotion = "Awe"` (last value wins). This is the
documented limitation — but since the UI workflow that used this
path has been removed, there is no user impact.

### Future Refactor (NOT now)

If the Read Tokens workflow is ever reintroduced (which is explicitly
NOT the current UX per ADR 003 §8), `SemanticTokenState` should be
refactored to store per-sentence (or per-block) state instead of a
single flattened value. The `ParsedToken.sentence_identity` and
`block_identity` fields are already in place to support this.

Until then, this is documented as a known architectural limitation
with NO current user impact.

---

## P3.23 DEFECT FIX REGISTER (from the independent security/reliability audit)

The independent audit (SpeechStudio_AUDIT_REPORT.md, verdict: NOT RELEASE
READY) found 54 defects in the pre-P3.21 build. P3.23 re-verified each
headline finding against the P3.22/P3.23 build and fixed the following.
Each fix is covered by runtime tests in `tests/test_p3_23_regression_fixes.py`.

### AUDIT-THR-1 (was CRITICAL): thread affinity — HISTORY_UPDATED
- **Status**: CLOSED (P3.23)
- Engine emits HISTORY_UPDATED on the worker thread; the MainWindow handler
  touched widgets directly. The handler now emits `_history_changed_signal`
  (a Qt signal) — Qt queues cross-thread emissions onto the UI thread.

### AUDIT-UX-1/2: F11 and Esc completely dead ("Ambiguous shortcut overload")
- **Status**: CLOSED (P3.23)
- Both a hidden-menubar QAction AND a standalone QShortcut were registered
  for F11 and Esc — Qt disabled both. The duplicate QShortcuts were removed;
  the QAction shortcuts were promoted to ApplicationShortcut context.
  Runtime test: QTest F11 keyClick now toggles fullscreen (previously dead).

### AUDIT-UX-3: Settings dialog opened twice
- **Status**: CLOSED (P3.23)
- Duplicate `connect("settings", ...)` registration removed (was two slots
  → two dialogs). Runtime test counts exactly one dialog instantiation.

### AUDIT-DATA-1: Settings split brain (cross-instance overwrite)
- **Status**: MITIGATED (P3.23)
- SettingsManager now merges-on-write: it re-reads the disk file and applies
  only its own dirty keys, so a second instance's save no longer reverts
  the first instance's keys (the audit's proven theme-revert scenario).
  RESIDUAL (known, documented): values READ by an instance stay cached
  until that instance next saves; a single shared SettingsManager remains
  the recommended future architecture.

### AUDIT-SEC-1/2: history delete + project delete path traversal
- **Status**: CLOSED (P3.23)
- HistoryManager.delete validates the entry ID (single safe component) and
  containment within the history dir; the audio delete is containment-
  checked against the app root. ProjectManager.delete_project validates the
  project ID and containment within the projects dir (no arbitrary rmtree).

### AUDIT-API-1: Voice import API drift (AttributeError)
- **Status**: CLOSED (P3.23)
- Engine.import_voice_avatar / Engine.set_voice_speaker_metadata now exist
  and are functional (VoiceManager.import_avatar copies the image into the
  profile + records preview_image; set_speaker_metadata persists
  gender/age_range/mood on VoiceProfile). Voice import no longer fails
  whenever an avatar or speaker metadata is provided.

### Still open from the audit (NOT fixed in P3.23 — reported, not ignored):
- **AUDIT-ARCH-1** (LOW/MEDIUM): startup writes settings/build.json/logs
  into the source tree via module-relative APP_ROOT (architectural;
  requires an approved app-data redirection decision).
- **AUDIT-UX-4** (MEDIUM): "Font Status..." unreachable in TopNav Help
  menu (native menubar hidden).
- **AUDIT-UX-5** (MEDIUM): TopNav Export button opens Voice Library export
  (tooltip says "Export Audio").
- **AUDIT-THEME-1** (MEDIUM): Token Guide colors frozen at import.
- Various LOW stale-doc/dead-code items (legacy sidebar, modern_control_panel,
  feature registry F-703, README theme count).

### P3.23 CRITICAL (found + fixed during the Character/Assembly stage):
- **P3.23-CRIT-1**: Combined Audio assembly used Python's `wave` module,
  which CANNOT read the float32 (IEEE format 3) WAV files the Higgs
  pipeline actually writes — assembly failed on every REAL generated file
  (`wave.Error: unknown format: 3`). Existing tests passed only because
  they created PCM16 fixtures with the same `wave` module (fixture
  blindness). Rewritten with soundfile (float32-safe); combined output is
  24 kHz mono float WAV. Runtime tests use REAL float32 fixtures.
- **P3.23-HIGH-1**: Re-detect / Split / Merge silently DROPPED Character
  assignments (explicit design-record §25 violation). Fixed with
  similarity-based transfer + lost_character_id recovery (never silent).
- **P3.23-HIGH-2**: Multi-speaker ($SPEAKER) path ignored block Characters
  — the speaker map could override an explicit Character assignment
  (design-record §19 violation). Fixed: character_id propagates from the
  overlapping block to every SplitPart; the speaker map is only consulted
  when the Character resolves no voice.

---

## P3.24 UX CORRECTION REGISTER (Character + Scene UX)

Three concrete UX problems from the P3.24 correction task, each root-caused
and fixed. Runtime coverage: `tests/test_p3_24_character_scene_ux.py` (57
tests) + E2E golden path (20 checks).

### P3.24-UX-1 (HIGH): Scene dropdown "New Scene" did nothing
- **Status**: CLOSED (P3.24)
- Root cause: `ProjectSceneBar.new_scene_requested` was emitted by the
  menu action but NEVER connected in MainWindow — the signal had zero
  receivers (every other bar signal was connected; this one was missed).
- Fix: connected to the single authoritative `_on_new_scene` handler; the
  handler was also converted to QUICK CREATE (no modal name prompt —
  unique "Untitled Scene" default, next sort_order, immediate activation,
  clean editor state via `_load_scene_state`, silent persistence).
- Also fixed within: the old handler only called `clear_text()`, leaving
  the previous Scene's Narration Blocks in the editor.

### P3.24-UX-2 (HIGH): CharacterManagementDialog NameError on every mutation
- **Status**: CLOSED (P3.24)
- Root cause: `character_dialog.py` used `logger` in
  add/delete/apply handlers without importing it — every Character
  add/delete/update through the dialog raised NameError AFTER mutating
  the Project (state changed, error surfaced).
- Fix: `from engine.logger import logger` import added.

### P3.24-UX-3 (MEDIUM): CHARACTERS panel unusable; Assemble Audio hidden
- **Status**: CLOSED (P3.24)
- The CHARACTERS context was a read-only list whose only creation path
  was the secondary modal dialog; the "+" affordance was an icon-only
  28x28 tool button that read as a dot. "Assemble Audio" was buried in
  the Scene dropdown.
- Fix: the CHARACTERS panel is now a real management surface —
  `_CharacterRow` rows (canonical colour dot + inline rename + Voice
  Profile dropdown + safe delete), "+ Add Character" CTA at the panel
  top, actionable empty state, no-project disabled state, and a proper
  "+ Add" pill in the header. Assemble Audio moved to a prominent
  bottom-of-sidebar action; the Scene dropdown duplicate was removed
  (File → Assemble Scenes... remains as the standard menu path).
- VLM-verified: no clipping/overlap/misalignment in the rendered panel.


## P3.25 AUDIT DEFECT REMEDIATION REGISTER (second independent audit)

Source: SpeechStudio_AUDIT_REPORT.md (54-defect register; verdict at the
time: NOT RELEASE READY). P3.25 re-verified EVERY claim independently
against the P3.24 build (reproduction probes: ss/audit_probes_p325/),
fixed the confirmed defects, and added runtime regression tests
(tests/test_p3_25_audit_remediation.py, 60 tests). Rule applied: no fix
without independent reproduction first; no fix without a runtime test
after. Test-type discipline maintained (runtime vs AST vs E2E labelled).

### CRITICAL

### SS-C01: cross-thread UI mutation on HISTORY_UPDATED
- **Status**: VERIFIED FIXED (P3.23 fix re-verified at runtime in P3.25)
- Root cause: the handler subscribed directly to the EventBus and
  touched widgets from the generation worker thread.
- Fix (P3.23, held): handler only emits `_history_changed_signal`; Qt
  queues cross-thread emissions onto the GUI thread.
- Test: `TestSSC01ThreadAffinity` — HISTORY_UPDATED published on a real
  worker thread; refresh asserted to run on MainThread.

### HIGH — fixed in P3.25

### SS-H01: Scene voice None-state leak + destruction
- **Status**: CLOSED (P3.25)
- Root cause: truthy guard `if scene.voice_profile_id:` in
  `_load_scene_state` skipped the reset; the unconditional save then
  persisted the stale selection into the None-voice Scene.
- Fix: UNCONDITIONAL `set_selected_voice_id(scene.voice_profile_id)`
  (None → "(No voice)") + voice-info cleared to "No voice" when None.
- Test: `TestSSH01SceneVoiceNone` (3 tests) + A→B→A matrix in
  `TestSceneStateIntegrity`.

### SS-H02: block override clobbered the scene-global value
- **Status**: CLOSED (P3.25)
- Root cause: `_on_emotion_changed` (and style/speed/pitch/delivery)
  wrote BOTH the global field and the block override.
- Fix: with a block selected, the handler writes ONLY the block
  override; the global is written exclusively when no block is selected
  (matches the documented design in `_on_block_selected`).
- Test: `TestSSH02BlockOverrideScope` (3 tests incl. all five controls).

### SS-H03: Scene.parameters None contamination
- **Status**: CLOSED (P3.25)
- Root cause: truthy guard `if scene.parameters:` — same anti-pattern
  as SS-H01 on the parameters path.
- Fix: UNCONDITIONAL `set_parameters(scene.parameters or
  GenerationParameters())` — None resets the panel to factory defaults.
- Test: `TestSSH03SceneParamsNone` (2 tests).

### SS-H04: settings.json split-brain (3 instances + raw 4th writer)
- **Status**: CLOSED (P3.25)
- Root cause: Engine/MainWindow/entry point held private
  SettingsManager instances with divergent caches; the batch dialog
  wrote settings.json via a raw read-modify-write; writes were
  non-atomic; MainWindow's settings dir was hardwired to the module
  path (different file than the Engine's whenever app_root differed).
- Fix: (a) `SettingsManager.instance()` — ONE shared owner per file per
  process, used by Engine, MainWindow and the entry point; (b)
  MainWindow derives its settings dir from the ENGINE's app root; (c)
  reload-on-read via (inode, mtime_ns, size) — stale reads eliminated
  including same-timestamp rewrites (atomic replace changes the inode);
  (d) atomic tmp+os.replace writes; (e) batch dialog writes through the
  shared manager (raw writer removed).
- Test: `TestSSH04SettingsArchitecture` (6 tests incl. real Engine+
  MainWindow sharing one object and a full restart cycle).

### SS-H05: Raw Mode preview differed from model input
- **Status**: CLOSED (P3.25)
- Root cause: `_update_preview` never checked `_raw_mode` — the Preview
  tab showed the compiled prompt (with injected tokens) while the model
  received the literal raw text.
- Fix: preview renders the literal editor text verbatim when Raw Mode
  is active (ADR 003 §6/§8: preview == model input).
- Test: `TestSSH05RawModePreview` (2 tests).

### SS-H06 (+SS-M01/M02): Allow SFX no-op end-to-end
- **Status**: CLOSED (P3.25)
- Root cause: GenerationSection.get_parameters() rebuilt
  GenerationParameters WITHOUT allow_sfx (always default True), so the
  Friendly toggle never reached the prompt compiler; the toggle also
  never emitted parameters_changed (no sync), and the advanced→friendly
  sync reset it; Generate Long dropped the flag in job_params and the
  dialog part-rebuild.
- Fix: GenerationSection owns and round-trips allow_sfx; the toggle
  emits parameters_changed (friendly→advanced sync chain); job_params
  forwards base_params.allow_sfx; LongNarrationDialog accepts and
  applies allow_sfx on part rebuild.
- Test: `TestSSH06AllowSfxEndToEnd` (6 tests: panel params, prompt
  content ON/OFF, tab-switch survival, job params, dialog rebuild).

### SS-H07: invalid semantic values — garbage token OR silent fallback
- **Status**: CLOSED (P3.25)
- Root cause: two divergent policies — block overrides fell through to
  `value.lower()` in `_resolve_emission_tag` (literal garbage token to
  the model) while the global path swallowed InvalidPrompt into a
  tokenless prompt; the UI discarded the compiler's warnings.
- Fix: ONE deterministic policy everywhere — unknown values are
  REJECTED (no token emitted) and a warning is recorded; the
  MainWindow surfaces compile warnings (Preview panel + status bar)
  via `_last_prompt_warnings`.
- Test: `TestSSH07InvalidValues` (4 tests incl. invalid matrix and
  runtime warning surfacing through the real MainWindow).

### SS-H08 (+SS-M08): path traversal / import-export exfiltration
- **Status**: CLOSED (P3.25)
- Root cause: exporter joined model-supplied output_paths without
  containment (absolute paths discarded app_root via os.path.join);
  import kept traversal paths verbatim; hostile names crashed the
  exporter (null bytes, 300-char names, Windows reserved names).
- Fix: `_contained_source_path()` containment (rejects absolute,
  traversal, dot-segments, backslash, null-byte paths; realpath must
  stay inside app_root) applied to ALL export copy sites (scene audio,
  voice references, combined WAV+MP3); import SANITIZES escaping paths
  (stripped + logged); `_safe_dirname` hardened (null bytes, 80-char
  cap, Windows reserved names); export dialog catches unexpected
  exceptions.
- Test: `TestSSH08PathTraversal` (4 tests: crafted import → re-export
  exfiltration attempt, containment matrix, direct in-memory export,
  history-delete containment re-check) + M08 hostile-names test.

### SS-H09 (+SS-L14): corrupt settings.json bricked startup
- **Status**: CLOSED (P3.25)
- Root cause: `_load` caught only JSONDecodeError/OSError — wrong root
  type (AttributeError in _deep_merge) and UnicodeDecodeError crashed
  Engine construction; `get()` raised on non-dict sections.
- Fix: broad per-load catch + isinstance(dict) validation + corrupt
  file QUARANTINED (renamed .corrupt-<ts>, app self-heals on next
  save); `get()` returns the default for non-dict sections.
- Test: `TestSSH09CorruptSettings` (4 tests incl. real Engine boot with
  a corrupt file).

### SS-H10: one corrupt history file poisoned all history
- **Status**: CLOSED (P3.25)
- Root cause: narrow excepts in list/get entry; HistoryEntry was a raw
  dict wrapper — KeyError/TypeError reached the History dialog.
- Fix: broad per-entry catch (+ dict validation) in list_entries/
  get_entry; HistoryEntry properties validate types and coerce
  (output_duration via _as_float, voice_profile degrades to None);
  real HistoryViewDialog construction test with malformed entries.
- Test: `TestSSH10HistoryRobustness` (3 tests).

### SS-H11: voice import avatar/metadata AttributeError
- **Status**: VERIFIED FIXED (P3.23 fix re-verified at runtime in P3.25)
- Test: `TestSSH11VoiceImport` (avatar + metadata + duplicate import +
  re-import idempotence).

### SS-H12/SS-H13: dead F11 / dead Esc
- **Status**: SS-H12 VERIFIED FIXED (F11 both directions, QTest).
  SS-H13 CLOSED (P3.25): the P3.23 fix had kept Esc as an
  ApplicationShortcut QAction — that intercepted EVERY Esc app-wide, so
  Esc still could not exit fullscreen or close the search bar.
- Fix: Esc removed from the Stop QAction; ONE authoritative handler in
  MainWindow.keyPressEvent with an explicit priority chain:
  stop generation > exit fullscreen > close search bar.
- Test: `TestSSH12H13Shortcuts` (5 tests: F11 both ways, Esc exits
  fullscreen, Esc closes search, Esc stops generation, no ambiguous
  registrations).

### SS-H14: Settings dialog opened twice
- **Status**: VERIFIED FIXED (re-verified incl. rapid triple trigger:
  exactly 3 dialogs for 3 triggers).
- Test: `TestSSH14SettingsDialog`.

### SS-H15: silent except-cluster in scene save/restore
- **Status**: CLOSED (P3.25)
- Root cause: five `except: pass` blocks around the scene state sync —
  one failing setter skipped the remaining restores (partial-restore
  leak) and block-persistence failures vanished silently.
- Fix: per-field narrow handlers with logged warnings (block-state
  save failures at ERROR level); restores no longer skip.
- Test: `TestSSH15SceneRestoreFaults` (fault injection both directions).

### MEDIUM — fixed in P3.25

| ID | Root cause → Fix | Test |
|---|---|---|
| SS-M01 | advanced→friendly sync reset the SFX toggle → toggle participates in the sync chain | TestSSH06 (tab-switch survival) |
| SS-M02 | job_params + dialog rebuild dropped allow_sfx → forwarded | TestSSH06 (2 tests) |
| SS-M03 | `if params.seed is not None` left stale seed → else-clear | test_m03 |
| SS-M05 | second-resolution ids collided → millisecond suffix + de-dup (history AND audio filenames) | test_m05 (2 tests) |
| SS-M06 | corrupt voice profile crashed listing → broad per-profile catch | test_m06 |
| SS-M07 | import_project_dir crashed on malformed project.json → wrapped + rejected | test_m07 |
| SS-M08 | hostile names crashed export → sanitizer hardening + dialog catch | test_m08 |
| SS-M09 | scene deletion not persisted → save_project after delete (failure surfaces a warning) | test_m09 |
| SS-M10 | CWD-relative isfile in History view → _resolve_history_path against app root | test_m10 |
| SS-M11 | Font Status unreachable → added to TopNav Help menu | (menu structure; runtime menu walks remain in P3.23 probes) |
| SS-M12 | "Export Audio" mislabel → "Export Voice" | (label) |
| SS-M13 | Token Guide colors frozen at import → HTML built at dialog open | (dialog opens with current Palette) |
| SS-M14 | QTimer.singleShot(0) from worker threads never fired → `_model_status_signal` marshalling | test_m14 (GUI-thread proof) |
| SS-M18 | from_dict defaults diverged from dataclass → single default source | test_m18 |
| SS-M20 | stale verify_transport_gl.py (180/183 red) → RETIRED with honest stub | tool exit 0, no claims |

### Bonus defect found and fixed during P3.25 (E2E)

- **PATH-1**: `GenerationManager._load_reference_audio` resolved
  reference paths against the MODULE directory, not the Engine's app
  root — with Engine(app_root=<dir>) a valid imported reference was
  reported "missing from disk" and blocked generation. Fixed to resolve
  via the AudioManager's app root. Test:
  `test_generation_reference_audio_resolves_against_engine_app_root`.
- **DATA-1** (audit §6.4 bonus): the Engine failure path stored the
  WORKER THREAD NAME as the result timestamp (flowed into history
  ids/recents). Fixed to a real timestamp.
- **SS-H04-extra**: MainWindow hardwired its settings dir to the module
  path — the Engine and MainWindow held DIFFERENT settings files
  whenever app_root differed (audit probe_c3 scenario). Fixed: settings
  dir derived from the Engine's app root (verified: same object).

### Still open (documented, not fixed in P3.25)

- **AUDIT-ARCH-1** (MEDIUM, architectural): startup writes
  settings/build.json/logs via module-relative APP_ROOT in several
  UI/engine components (documented since P3.23; requires an approved
  app-data redirection decision). Partially mitigated: settings,
  reference-audio resolution and history paths now follow the ENGINE's
  app root consistently.
- **SS-M15** (MEDIUM, architectural): engine/batch_manager.py lazily
  imports PySide6 (Qt-free rule breach) for retry delays; requires a
  scheduling abstraction injection.
- **SS-M16/SS-M17** (MEDIUM, feature-adjacent): Character
  voice_profile_id is not used for multi-speaker pre-selection;
  speaker_voice_map is a global (cross-project) setting. Both are
  integration gaps, not regressions; deferred pending a product
  decision (no feature creep in a stabilization pass).
- **SS-M19** (MEDIUM): threading invariants (GENERATION_STARTED on the
  submitter thread; BatchManager.marshal_to_ui default) are documented
  in code comments but not enforced.
- **SS-L02…SS-L18** (LOW): stale docs / dead code / cosmetic items —
  unchanged (LOW priority per the remediation order).
- Dead code (~7 files, ~5,400 lines: sidebar.py, modern_control_panel.py,
  components.py, prompt_editor.py, ambient_*, transport_gl.py) — removal
  is a separate, reviewable change (not bundled into defect fixes).

---

## P3.25 ADDENDUM: Model Load Dialog white/blank window (user-reported)

Reported after the P3.25 build on the target Windows machine: the
"Loading Model - SpeechStudio" dialog appeared as a **white,
content-free window** (only the OS-drawn title bar was visible) during
model loading.

### MLD-1 (HIGH, user-reported) — loading dialog never painted

- **Root cause (runtime-reproduced)**: `MainWindow._load_model` /
  `_load_model_and_generate` submitted the engine load job BEFORE
  showing the dialog. The worker thread immediately began `import
  torch`, which holds the GIL in long C-extension stretches on Windows,
  so the GUI thread's event loop could not process the freshly-shown
  dialog's expose/paint events for many seconds. A mapped-but-unpainted
  top-level window is filled by the OS with the default WHITE window
  brush. Reproduced headlessly with
  `ss/audit_probes_p325/probe_paint_timing.py`: OLD flow = first paint
  **1.99 s after show()**; fixed flow = **0.00 s**.
- **Fix**: `ModelLoadDialog.start()` now paints synchronously
  (`processEvents(ExcludeUserInputEvents)` + `repaint()` — the standard
  splash-screen pattern) while the GUI thread still owns the GIL, and
  MainWindow shows+paints the dialog BEFORE submitting the load job
  (submission failure closes the dialog again and re-raises).
- **Tests**: `tests/test_p3_25_model_load_dialog.py` — dialog painted
  before submission (both load paths), painted with ZERO event-loop
  processing under an active GIL-hogging worker, submission-failure
  closes the dialog, dark render with content, explicit background.

### MLD-2 (MEDIUM) — dialog relied on the transparent QDialog QSS

- **Root cause**: the app-wide QSS styles `QDialog { background-color:
  transparent; }` (the main window's dark look comes from ambient
  background layers — a separate top-level dialog has no such
  backdrop); the dialog set no background of its own, leaving the body
  to platform-dependent fill behaviour.
- **Fix**: explicit dark surface on the dialog (the visually verified
  AssembleDialog pattern: `background-color: Palette.BG_BASE`).

### MLD-3 (MEDIUM) — Cancel button label invisible

- **Root cause**: `setFixedSize(400, 180)` was too short for the
  content under the theme QSS paddings — the layout squeezed the Cancel
  button to a 15 px height, and the 7 px vertical QSS padding left zero
  pixels for the label (verified: button QRect(163,141,74,15), 0 text
  pixels in the render).
- **Fix**: `setFixedSize(400, 220)` — every item now lays out at its
  size hint (button 74×32, "Cancel" renders; VLM-verified full dialog
  render: title, status, progress bar, elapsed timer, Cancel all
  visible on the dark surface).

Status: all three **FIXED**; 656/656 tests, 5/5 verification scripts,
E2E golden path 30/30.

---

## P3.26 register — Scene switching + Narration Block state integrity
(user-reported defects; all REPRODUCED before fixing — see
`ss/audit_probes_p326/probe_repro.py` + `probe_emotion_scope.py`)

### P3.26-D1 (CRITICAL, user workflow Part 3) — Scene switch state leak

- **Symptom**: A (long text, Plain) -> B (short text, 3 Characters,
  Blocks) -> A: A returned in BLOCKS mode with B's block visuals painted
  over A's text and B's block/Character elements below the text;
  Re-detect was required to repair the display.
- **Root causes** (4, all confirmed at runtime):
  1. The editor mode (Plain/Blocks/Preview) was widget-global — never
     persisted or restored per Scene.
  2. The no-blocks restore path (`block_manager.clear()`) never
     re-rendered the editor: the previous Scene's blocks stayed in the
     inner editor as extraSelections + gutter data.
  3. `set_text` during the switch fed the text swap into
     `NarrationBlockManager.on_text_changed` while the PREVIOUS Scene's
     blocks were still loaded — they were offset-shifted as if the user
     had edited the text.
  4. `_selected_block_id` (editor) and `_active_block_id` (control
     panel) were never explicitly reset — clearing happened only via
     cursor-signal side effects (non-deterministic).
- **Fix**: `Scene.editor_mode` + `Scene.selected_block_id` (additive,
  deterministic defaults); atomic Scene restore
  (`begin_scene_load`/`set_scene_blocks`/`set_editor_mode` — text swap
  never offset-shifts, zero-blocks case fully re-renders); scope reset
  FIRST in `_load_scene_state`; mode + selection restore through the
  real `_set_mode`/`block_selected` paths; fresh Scenes inherit the
  current mode (creation), existing Scenes always restore their own.
- **Tests**: `tests/test_p3_26_scene_state_integrity.py` (29 runtime
  tests: mode restoration both directions, Character isolation UI+model,
  block/character widget cleanup, Re-detect-not-required, persistence
  round-trip, contamination matrix); E2E `ss/e2e/e2e_p326.py` 34/34.

### P3.26-D2 (HIGH, user workflow Part 9) — B1 not selectable on first click

- **Symptom**: in Narration Blocks, B1 could not be selected on the
  first click; B2 had to be selected first, then B1 worked.
- **Root cause**: block selection was driven ONLY by
  `cursorPositionChanged`. The gutter click calls
  `setTextCursor(block.start_offset)`; when the cursor already sits at
  that offset (the default state after a Scene load / `setPlainText` /
  auto-detect — offset 0), Qt emits NO signal, so the selection handler
  never ran. The same applies to text-area clicks that don't move the
  cursor.
- **Fix**: `block_click_requested` signal — both the gutter click and a
  new `mousePressEvent` override on `BlockAwarePlainTextEdit` emit the
  clicked offset; `NarrationEditor._on_block_click_requested` drives the
  selection explicitly (idempotent — re-clicking the selected block
  still refreshes the properties panel, so every click has visible
  feedback).
- **Tests**: runtime QTest gutter clicks (first click, B1/B2/B3/B1
  sequence, text-area click, immediately after Scene switch).

### P3.26-D3 (HIGH, user workflow Part 11) — Advanced global Emotion dead

- **Symptom**: setting a global emotion (Enthusiasm) in Advanced did
  nothing — no effective state, no token in the preview; the same in
  Plain Text mode.
- **Root cause**: the control panel's `_active_block_id` (block scope)
  went STALE via four paths — switching to Plain/Preview mode, Re-detect
  (all block ids replaced), deleting the selected block, and Scene
  switches (non-deterministic cursor-signal clearing). Semantic control
  changes were routed into `_update_block_override`: with a live-but-
  hidden block (Plain mode) the value was written into the hidden block
  override while the user believed they set the global; with a dead id
  the change was SILENTLY DROPPED (no state, no preview token, no
  warning).
- **Fix**: `_block_scope_valid_id()` validates the scope before any
  semantic change (must be BLOCKS mode + live block id; stale scopes are
  cleared and the change lands on the GLOBAL); the editor now also emits
  `block_selected` on every selection-changing path (mode switch,
  Re-detect via `_post_analyze`, delete, merge, create) so the scope
  always follows reality.
- **Tests**: the four stale-scope scenarios + six-emotion matrix +
  preview + real-GenerationRequest propagation (captured from
  `_start_generation`).

### P3.26-UX1 / UX2 (UX fine tune, Parts 1-2) — sidebar

- **UX1**: the Recents header action is now an icon-only 28×28
  QToolButton (22 px clearly visible plus icon; hover: accent border +
  lifted background; pressed: deeper background; context-aware
  dispatcher + per-context tooltips unchanged). Supersedes the P3.24
  "+ Add" pill (icon+text was redundant).
- **UX2**: the shared Recents list (Recent Projects / Scenes /
  Characters / Audio) is a visually distinct small surface — #202024
  background vs. the #1A1A1A sidebar, 8 px rounded corners, 1px #323236
  border, 6 px internal padding. Data model and row widgets unchanged.

Status: all three functional defects **FIXED**; both UX refinements
implemented. 686/686 tests, 5/5 verification scripts, E2Es: P3.26
34/34, P3.25 30/30, P3.24 20/20. VLM-verified renders of all four
Recents contexts + the full Narration Blocks editor (no clipping,
overlap, or duplicate elements).

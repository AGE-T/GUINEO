"""
SpeechStudio Batch Generation Dialog.

Provides:
    - JobEditDialog   : modal dialog for editing a single BatchJob.
    - BatchGenerationDialog : non-modal dialog that drives the
                              BatchManager and shows a live job table.

Architecture:
    The dialog is a thin Qt view over the engine's BatchManager.  All
    queueing, retry, and inter-job pacing happens in the BatchManager;
    the dialog only:
        - reads ``manager.jobs`` to refresh the table,
        - calls ``manager.start()`` / ``pause()`` / ``stop()`` on button clicks,
        - connects ``manager.set_on_changed`` to ``self._refresh_table``,
        - wires the marshal_to_ui callback to ``QTimer.singleShot(0, fn)``.
"""

from __future__ import annotations
import os
from typing import Optional, List

from PySide6.QtCore import Qt, QTimer, Signal, QObject, QSize, QPointF, QRectF
from PySide6.QtGui import (
    QColor, QFont, QPainter, QPen, QBrush, QIcon, QPixmap,
)
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton, QLabel,
    QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QFileDialog, QMessageBox, QAbstractItemView,
    QSizePolicy, QDialogButtonBox, QWidget, QProgressBar, QFrame,
)

from ui.theme import Palette
from ui.icon_registry import IconRegistry
from engine.models import GenerationParameters, VoiceProfile
from engine.batch_manager import BatchJob, BatchManager, JobStatus


# ---------------------------------------------------------------------------
# Job edit dialog
# ---------------------------------------------------------------------------
class JobEditDialog(QDialog):
    """Modal dialog for editing a single BatchJob.

    Includes a seed field (QLineEdit, empty = random, integer = specific seed).
    """

    def __init__(self, job: BatchJob, voices: List[VoiceProfile], parent=None):
        super().__init__(parent)
        self._job = job
        self._voices = voices
        self.setWindowTitle("Edit Batch Job")
        self.setMinimumWidth(500)
        self._build_ui()
        self._load_from_job()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        grid = QGridLayout()
        grid.setSpacing(6)
        row = 0

        # Name
        grid.addWidget(QLabel("Name:"), row, 0)
        self._name = QLineEdit()
        self._name.setPlaceholderText("Job name (optional)")
        grid.addWidget(self._name, row, 1)
        row += 1

        # Prompt
        grid.addWidget(QLabel("Prompt:"), row, 0, alignment=Qt.Alignment.AlignTop)
        self._prompt = QLineEdit()
        self._prompt.setPlaceholderText("Prompt text (may include Higgs tokens)")
        grid.addWidget(self._prompt, row, 1)
        row += 1

        # Voice
        grid.addWidget(QLabel("Voice:"), row, 0)
        self._voice = QComboBox()
        self._voice.addItem("(No voice)", None)
        for v in self._voices:
            label = v.name
            if v.duration > 0:
                label += " ({0:.1f}s)".format(v.duration)
            self._voice.addItem(label, v.id)
        grid.addWidget(self._voice, row, 1)
        row += 1

        # Output filename
        grid.addWidget(QLabel("Output Filename:"), row, 0)
        self._output_filename = QLineEdit()
        self._output_filename.setPlaceholderText("auto (timestamp) or my_audio.wav")
        grid.addWidget(self._output_filename, row, 1)
        row += 1

        # Sampling parameters
        grid.addWidget(QLabel("Temperature:"), row, 0)
        self._temperature = QDoubleSpinBox()
        self._temperature.setRange(0.1, 2.0)
        self._temperature.setSingleStep(0.05)
        self._temperature.setDecimals(2)
        grid.addWidget(self._temperature, row, 1)
        row += 1

        grid.addWidget(QLabel("Top P:"), row, 0)
        self._top_p = QDoubleSpinBox()
        self._top_p.setRange(0.1, 1.0)
        self._top_p.setSingleStep(0.05)
        self._top_p.setDecimals(2)
        grid.addWidget(self._top_p, row, 1)
        row += 1

        grid.addWidget(QLabel("Top K:"), row, 0)
        self._top_k = QSpinBox()
        self._top_k.setRange(1, 500)
        self._top_k.setSingleStep(10)
        grid.addWidget(self._top_k, row, 1)
        row += 1

        grid.addWidget(QLabel("Max Tokens:"), row, 0)
        self._max_tokens = QSpinBox()
        self._max_tokens.setRange(128, 8192)
        self._max_tokens.setSingleStep(128)
        grid.addWidget(self._max_tokens, row, 1)
        row += 1

        grid.addWidget(QLabel("Seed:"), row, 0)
        self._seed = QLineEdit()
        self._seed.setPlaceholderText("empty = random, or integer for reproducible")
        self._seed.setValidator(None)  # accept empty
        grid.addWidget(self._seed, row, 1)
        row += 1

        grid.addWidget(QLabel("Append Silence (s):"), row, 0)
        self._silence = QDoubleSpinBox()
        self._silence.setRange(0.0, 5.0)
        self._silence.setSingleStep(0.1)
        self._silence.setDecimals(1)
        grid.addWidget(self._silence, row, 1)
        row += 1

        self._normalize = QCheckBox("Normalize Output (-18 LUFS)")
        grid.addWidget(self._normalize, row, 1)
        row += 1

        layout.addLayout(grid)

        # Button box
        bb = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

    def _load_from_job(self) -> None:
        j = self._job
        self._name.setText(j.name or "")
        self._prompt.setText(j.prompt or "")
        # Voice
        for i in range(self._voice.count()):
            if self._voice.itemData(i) == j.voice_id:
                self._voice.setCurrentIndex(i)
                break
        self._output_filename.setText(j.output_filename or "")
        p = j.parameters
        self._temperature.setValue(p.temperature)
        self._top_p.setValue(p.top_p)
        self._top_k.setValue(p.top_k)
        self._max_tokens.setValue(p.max_new_tokens)
        if p.seed is not None:
            self._seed.setText(str(p.seed))
        else:
            self._seed.setText("")
        self._silence.setValue(p.append_silence)
        self._normalize.setChecked(p.normalize_output)

    def apply_to_job(self) -> BatchJob:
        """Write the dialog's values back into the BatchJob and return it."""
        j = self._job
        j.name = self._name.text().strip()
        j.prompt = self._prompt.text()
        j.voice_id = self._voice.currentData()
        fname = self._output_filename.text().strip()
        j.output_filename = fname if fname else None
        seed_text = self._seed.text().strip()
        seed = int(seed_text) if seed_text else None
        j.parameters = GenerationParameters(
            temperature=float(self._temperature.value()),
            top_p=float(self._top_p.value()),
            top_k=int(self._top_k.value()),
            max_new_tokens=int(self._max_tokens.value()),
            seed=seed,
            append_silence=float(self._silence.value()),
            normalize_output=self._normalize.isChecked(),
            auto_play=False,  # never auto-play during batch
        )
        return j


# ---------------------------------------------------------------------------
# AnimatedHourglass — small painted widget for the "Generating" status pill
# ---------------------------------------------------------------------------
class AnimatedHourglass(QWidget):
    """Small QWidget that paints a spinning hourglass using QPainter.

    Used in the status pill of GENERATING jobs to give the user a clear
    visual signal that the engine is actively working. The animation is
    driven by an internal QTimer; call ``start()`` to begin spinning and
    ``stop()`` to halt. The widget is parented to its table cell, so when
    the cell widget is replaced (next _refresh_table call) Qt destroys
    the widget and its timer together — no manual cleanup is required.

    Color: ``Palette.WARNING`` (amber) — matches the mock's amber spinner
    but comes from the theme system, not a hardcoded value.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._advance)
        # 22x22 fits comfortably inside a 48px table row.
        self.setFixedSize(22, 22)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def start(self) -> None:
        """Begin the spin animation (idempotent)."""
        if not self._timer.isActive():
            self._timer.start(45)  # ~22 FPS — smooth and cheap.
        self.show()

    def stop(self) -> None:
        """Halt the spin animation and reset the angle."""
        self._timer.stop()
        self._angle = 0
        self.update()
        self.hide()

    def _advance(self) -> None:
        self._angle = (self._angle + 8) % 360
        self.update()

    def paintEvent(self, event):
        """Paint the hourglass glyph rotated by ``self._angle`` degrees.

        The shape is two horizontal caps plus an X for the glass walls,
        with two sand triangles (top-full, bottom-empty-or-filling) and
        a thin falling stream — same geometry as the standalone mock.
        """
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.translate(self.width() / 2.0, self.height() / 2.0)
        p.rotate(self._angle)

        color = QColor(Palette.WARNING)
        pen = QPen(color, 1.8)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        # Hourglass frame (top + bottom caps + X glass walls).
        p.drawLine(-6, -7, 6, -7)
        p.drawLine(-6, 7, 6, 7)
        p.drawLine(-6, -7, 6, 7)
        p.drawLine(6, -7, -6, 7)

        # Sand (top triangle + bottom triangle + falling stream).
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(color))
        p.drawPolygon([
            QPointF(-4.0, -5.0),
            QPointF(4.0, -5.0),
            QPointF(0.0, -1.0),
        ])
        p.drawPolygon([
            QPointF(-4.0, 5.0),
            QPointF(4.0, 5.0),
            QPointF(0.0, 1.0),
        ])
        p.drawRect(QRectF(-0.65, -1.0, 1.3, 2.0))
        p.end()


# ---------------------------------------------------------------------------
# Batch generation dialog
# ---------------------------------------------------------------------------
class _UiMarshaler(QObject):
    """Thread-safe UI marshaller using a Qt signal.

    QTimer.singleShot(0, fn) from a worker thread DOES NOT WORK because
    the worker thread has no Qt event loop.  A Qt signal, however, is
    automatically marshalled to the receiver's thread (the UI thread)
    when emitted from a different thread.

    Usage:
        marshaler = _UiMarshaler()
        marshaler.call.connect(fn)  # on UI thread
        marshaler.call.emit(fn)     # from any thread — fn runs on UI thread
    """
    call = Signal(object)  # carries a callable

    def __init__(self, parent=None):
        super().__init__(parent)
        self.call.connect(self._on_call)

    def _on_call(self, fn):
        fn()

    def marshal(self, fn):
        """Can be called from any thread.  fn will run on the UI thread."""
        self.call.emit(fn)


class BatchGenerationDialog(QDialog):
    """Non-modal-style dialog that drives a BatchManager.

    The dialog owns a BatchManager instance (passed in from MainWindow)
    and exposes a table of jobs with add/edit/remove/move/duplicate
    actions plus start/pause/stop controls and a live summary.
    """

    # Emitted when the user clicks "Concatenate". The MainWindow connects
    # this to its concatenation handler, which has access to the engine
    # and the waveform player. The argument is the list of COMPLETED
    # job output paths (absolute) in queue order.
    concatenate_requested = Signal(list)

    # Emitted when the user clicks the per-row "Play" button.
    # The argument is the output_path of the job to play (relative to APP_ROOT).
    play_requested = Signal(str)

    # Emitted when the user clicks the per-row "Stop" playback button.
    stop_playback_requested = Signal()

    # P3.27B: emitted when the user confirms regeneration of a single
    # part. MainWindow owns the versioned-filename allocation (it knows
    # the engine's outputs dir), so the dialog no longer resets the job
    # itself — for Generate Long parts the handler allocates a NEW
    # version (never overwriting the previous file) before resetting the
    # job and starting the batch. Manual jobs keep the legacy behaviour.
    regen_requested = Signal(int)

    def __init__(self, manager: BatchManager, voices: List[VoiceProfile],
                 parent=None):
        super().__init__(parent)
        self._manager = manager
        self._voices = voices
        self.setWindowTitle("Batch Generation")
        # P3.18: default size bumped from 900x600 to 1100x680 to give the
        # new two-panel layout (table + QUEUE SUMMARY sidebar) comfortable
        # breathing room. The user's saved geometry (settings.json) still
        # takes precedence via _restore_geometry().
        self.resize(1100, 680)

        # Restore saved window size from settings (if any).
        self._restore_geometry()

        # Wire the manager so all callbacks marshal into the UI thread.
        self._connect_manager()
        self._build_ui()
        self._refresh_table()
        self._update_buttons()

    def _restore_geometry(self) -> None:
        """Restore the saved dialog size from settings.json.

        P3.25 (audit SS-H04): reads via the SHARED SettingsManager — no
        raw independent file reads.
        """
        try:
            from engine.settings_manager import SettingsManager
            import os
            _root = os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))))
            sm = SettingsManager.instance(os.path.join(_root, "settings"))
            geo = sm.get("window", "batch_dialog", {}) or {}
            if geo:
                w = geo.get("width", 900)
                h = geo.get("height", 600)
                self.resize(int(w), int(h))
        except Exception:
            pass

    def _save_geometry(self) -> None:
        """Save the current dialog size to settings.json.

        P3.25 (audit SS-H04): the dialog previously performed a RAW
        read-modify-write of settings.json — an independent fourth writer
        that bypassed the SettingsManager merge/atomicity discipline. It
        now writes through the SHARED SettingsManager (atomic,
        merge-on-write, coherent with every other component).
        """
        try:
            from engine.settings_manager import SettingsManager
            import os
            _root = os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))))
            sm = SettingsManager.instance(os.path.join(_root, "settings"))
            sm.set("window", "batch_dialog", {
                "width": self.width(),
                "height": self.height(),
            })
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Manager wiring
    # ------------------------------------------------------------------
    def _connect_manager(self) -> None:
        """Configure the BatchManager to marshal callbacks to the UI thread
        via a Qt signal (thread-safe, unlike QTimer.singleShot)."""
        self._marshaler = _UiMarshaler(self)
        self._manager.marshal_to_ui = self._marshaler.marshal
        self._manager.set_on_changed(lambda _m: self._on_manager_changed())

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        """Build the two-panel layout (P3.18 visual redesign).

        Left panel  (~70%): toolbar rows + 5-column job table.
        Right panel (~30%): "QUEUE SUMMARY" sidebar with progress bar,
                            stat lines, Concatenate, START BATCH, Pause/Stop.

        All colors come from :class:`ui.theme.Palette` — no mock hex values.
        All icons come from :class:`ui.icon_registry.IconRegistry`.
        """
        # Top-level horizontal split: left = table, right = summary sidebar.
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        # ---------------------------------------------------------------
        # LEFT PANEL — toolbar rows + 5-column job table
        # ---------------------------------------------------------------
        left = QVBoxLayout()
        left.setSpacing(8)

        # Toolbar row 1: Add / Edit / Duplicate / Remove ... Up / Down
        job_row = QHBoxLayout()
        job_row.setSpacing(4)
        self._add_btn = QPushButton("+ Add")
        self._add_btn.clicked.connect(self._on_add)
        job_row.addWidget(self._add_btn)

        self._edit_btn = QPushButton("Edit...")
        self._edit_btn.clicked.connect(self._on_edit)
        job_row.addWidget(self._edit_btn)

        self._dup_btn = QPushButton("Duplicate")
        self._dup_btn.clicked.connect(self._on_duplicate)
        job_row.addWidget(self._dup_btn)

        self._remove_btn = QPushButton("- Remove")
        self._remove_btn.clicked.connect(self._on_remove)
        job_row.addWidget(self._remove_btn)

        job_row.addStretch()

        self._up_btn = QPushButton("\u2191 Up")
        self._up_btn.clicked.connect(self._on_move_up)
        job_row.addWidget(self._up_btn)

        self._down_btn = QPushButton("\u2193 Down")
        self._down_btn.clicked.connect(self._on_move_down)
        job_row.addWidget(self._down_btn)

        left.addLayout(job_row)

        # Toolbar row 2: Save / Load / Clear
        file_row = QHBoxLayout()
        file_row.setSpacing(4)
        self._save_btn = QPushButton("Save Queue...")
        self._save_btn.clicked.connect(self._on_save_queue)
        file_row.addWidget(self._save_btn)

        self._load_btn = QPushButton("Load Queue...")
        self._load_btn.clicked.connect(self._on_load_queue)
        file_row.addWidget(self._load_btn)

        self._clear_btn = QPushButton("Clear")
        self._clear_btn.clicked.connect(self._on_clear)
        file_row.addWidget(self._clear_btn)

        file_row.addStretch()
        left.addLayout(file_row)

        # 5 columns: #, Name / Segment, Status, Duration, Actions.
        # The old "Output" and "Error" columns are removed; error text is
        # exposed via the status pill tooltip, and the output filename via
        # the same tooltip — keeping the table readable while preserving
        # the information for users who hover.
        self._table = QTableWidget(0, 5)
        self._table.setHorizontalHeaderLabels(
            ["#", "File Name", "Status", "Duration", "Actions"])
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setShowGrid(False)
        # P3.21: Rounded corners on the table container to match the
        # modern card aesthetic. The QTableWidget itself doesn't support
        # border-radius, but we can style the viewport + header.
        self._table.setStyleSheet("""
            QTableWidget {
                background-color: rgba(36, 36, 36, 150);
                border: 1px solid #333333;
                border-radius: 8px;
                outline: none;
                gridline-color: transparent;
                font-size: 13px;
            }
            QTableWidget::item {
                border-bottom: 1px solid #333333;
                padding: 6px;
            }
            QTableWidget::item:selected {
                background: rgba(139, 92, 246, 35);
                color: #F5F5F5;
            }
            QHeaderView::section {
                background: rgba(32, 31, 31, 235);
                color: #A0A0A0;
                border: none;
                border-bottom: 1px solid #333333;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 8px;
                font-size: 11px;
                font-weight: 700;
            }
        """)
        header = self._table.horizontalHeader()
        header.setMinimumSectionSize(40)
        header.setStretchLastSection(False)
        # Column resize modes — Fixed keeps the pill column tidy; the Name
        # column stretches to fill whatever horizontal space the table gets.
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)      # #
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)    # Name / Segment
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)      # Status (pills)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)      # Duration
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)      # Actions
        header.resizeSection(0, 40)    # #
        header.resizeSection(2, 130)   # Status (icon + pill)
        header.resizeSection(3, 80)    # Duration
        header.resizeSection(4, 140)   # Actions (3 × 36px + 4px margins + 4px spacing)
        self._table.verticalHeader().setVisible(False)
        # Row height 48px accommodates the pill widget + the action buttons.
        self._table.verticalHeader().setDefaultSectionSize(48)
        self._table.verticalHeader().setMinimumSectionSize(48)
        left.addWidget(self._table, 1)

        layout.addLayout(left, 7)  # ~70% of horizontal space

        # ---------------------------------------------------------------
        # RIGHT PANEL — "QUEUE SUMMARY" sidebar
        # ---------------------------------------------------------------
        side = QFrame()
        side.setObjectName("BatchQueueSidePanel")
        side.setMinimumWidth(280)
        side.setMaximumWidth(360)
        side.setStyleSheet(
            "QFrame#BatchQueueSidePanel {{"
            "  background-color: {bg_surface};"
            "  border: 1px solid {border};"
            "  border-radius: 8px;"
            "}}".format(bg_surface=Palette.BG_SURFACE, border=Palette.BORDER))
        sl = QVBoxLayout(side)
        sl.setContentsMargins(16, 16, 16, 16)
        sl.setSpacing(12)

        # --- QUEUE SUMMARY section header ---
        section_label = QLabel("QUEUE SUMMARY")
        section_label.setStyleSheet(
            "QLabel {{"
            "  color: {muted};"
            "  font-size: 11px;"
            "  font-weight: 700;"
            "  letter-spacing: 1px;"
            "}}".format(muted=Palette.TEXT_SECONDARY))
        sl.addWidget(section_label)

        # --- Summary card: progress text + progress bar + 4 stat lines ---
        self._summary_card = QFrame()
        self._summary_card.setObjectName("BatchSummaryCard")
        self._summary_card.setStyleSheet(
            "QFrame#BatchSummaryCard {{"
            "  background-color: {bg_raised};"
            "  border: 1px solid {border};"
            "  border-radius: 6px;"
            "}}".format(bg_raised=Palette.BG_RAISED, border=Palette.BORDER))
        sc = QVBoxLayout(self._summary_card)
        sc.setContentsMargins(12, 12, 12, 12)
        sc.setSpacing(8)

        # Progress headline ("Progress    1/5 completed")
        self._progress_text = QLabel("Idle")
        self._progress_text.setStyleSheet(
            "color: {accent};"
            " font-family: 'JetBrains Mono','Consolas','Courier New',monospace;"
            " font-size: 12px;".format(accent=Palette.ACCENT))
        sc.addWidget(self._progress_text)

        # Thin progress bar — accent-colored chunk on a muted groove.
        self._progress = QProgressBar()
        self._progress.setTextVisible(False)
        self._progress.setFixedHeight(6)
        self._progress.setRange(0, 100)
        self._progress.setValue(0)
        self._progress.setStyleSheet(
            "QProgressBar {{"
            "  background-color: {bg_surface};"
            "  border: none;"
            "  border-radius: 3px;"
            "}}"
            "QProgressBar::chunk {{"
            "  background-color: {accent};"
            "  border-radius: 3px;"
            "}}".format(bg_surface=Palette.BG_SURFACE, accent=Palette.ACCENT))
        sc.addWidget(self._progress)

        # Stat lines (mono font, muted color, label + value).
        self._audio_label = self._make_summary_line("Generated Audio")
        self._rtf_label    = self._make_summary_line("Real Time Factor")
        self._wall_label   = self._make_summary_line("Wall Time")
        self._state_label  = self._make_summary_line("State")
        for w in (self._audio_label, self._rtf_label,
                  self._wall_label, self._state_label):
            sc.addWidget(w)

        sl.addWidget(self._summary_card)

        sl.addStretch(1)

        # --- Concatenate button (manual merge of completed parts) ---
        # Merges all COMPLETED parts (in queue order) into a single WAV.
        # Uses the list order directly, so ordering is always correct
        # regardless of regen operations.
        self._concat_btn = QPushButton("Concatenate")
        self._concat_btn.setToolTip(
            "Merge all COMPLETED parts (in queue order) into a single\n"
            "WAV file: outputs/long_narration_full.wav\n\n"
            "A 100ms crossfade is applied between parts.\n"
            "Use this after generation (and any regens) to produce the\n"
            "final combined audio.")
        self._concat_btn.clicked.connect(self._on_concatenate)
        self._concat_btn.setStyleSheet(self._tool_button_style())
        sl.addWidget(self._concat_btn)

        # --- START BATCH button (primary CTA — accent gradient) ---
        # Mock used an orange gradient; this app uses Palette.ACCENT (the
        # theme's primary CTA color) per the "no hardcoded mock colors"
        # constraint. The gradient (ACCENT -> ACCENT_PRESSED) gives the
        # same visual emphasis as the mock's orange gradient.
        self._start_btn = QPushButton("START BATCH")
        self._start_btn.clicked.connect(self._on_start)
        self._start_btn.setStyleSheet(
            "QPushButton {{"
            "  background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            "    stop:0 {accent}, stop:1 {accent_pressed});"
            "  color: {accent_text};"
            "  border: none;"
            "  border-radius: 5px;"
            "  padding: 10px 14px;"
            "  font-size: 13px;"
            "  font-weight: 700;"
            "  letter-spacing: 0.5px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent_hover};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                accent=Palette.ACCENT,
                accent_hover=Palette.ACCENT_HOVER,
                accent_pressed=Palette.ACCENT_PRESSED,
                accent_text=Palette.ACCENT_TEXT,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED,
                border=Palette.BORDER))
        sl.addWidget(self._start_btn)

        # --- Pause + Stop side by side ---
        run_row = QHBoxLayout()
        run_row.setSpacing(6)
        self._pause_btn = QPushButton("Pause")
        self._pause_btn.clicked.connect(self._on_pause)
        self._pause_btn.setEnabled(False)
        self._pause_btn.setStyleSheet(self._tool_button_style())
        run_row.addWidget(self._pause_btn)

        self._stop_btn = QPushButton("Stop")
        self._stop_btn.clicked.connect(self._on_stop)
        self._stop_btn.setEnabled(False)
        self._stop_btn.setStyleSheet(self._tool_button_style(danger=True))
        run_row.addWidget(self._stop_btn)
        sl.addLayout(run_row)

        layout.addWidget(side, 3)  # ~30% of horizontal space

    # ------------------------------------------------------------------
    # Style helpers (P3.18 — extracted for reuse across _build_ui)
    # ------------------------------------------------------------------
    @staticmethod
    def _make_summary_line(label: str) -> QLabel:
        """Create a mono-font stat-line label.

        The text format is ``"<label>    <value>"`` (filled in by
        :meth:`_update_summary`). The muted color + JetBrains Mono font
        matches the mock's summaryCard lines.
        """
        lbl = QLabel(label)
        lbl.setStyleSheet(
            "color: {muted};"
            " font-family: 'JetBrains Mono','Consolas','Courier New',monospace;"
            " font-size: 11px;".format(muted=Palette.TEXT_SECONDARY))
        return lbl

    @staticmethod
    def _tool_button_style(danger: bool = False) -> str:
        """Standard toolbutton QSS for the sidebar buttons.

        ``danger=True`` tints the text + hover border with Palette.ERROR
        (used for the Stop button, matching the mock's red Stop).
        """
        color = Palette.ERROR if danger else Palette.TEXT_PRIMARY
        hover = Palette.ERROR if danger else Palette.ACCENT
        return (
            "QPushButton {{"
            "  background-color: {bg_raised};"
            "  color: {color};"
            "  border: 1px solid {border};"
            "  border-radius: 5px;"
            "  padding: 7px 12px;"
            "  font-size: 12px;"
            "}}"
            "QPushButton:hover {{"
            "  border-color: {hover};"
            "  background-color: {bg_surface_alt};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                bg_raised=Palette.BG_RAISED,
                bg_surface=Palette.BG_SURFACE,
                bg_surface_alt=Palette.BG_SURFACE_ALT,
                color=color,
                border=Palette.BORDER,
                hover=hover,
                text_disabled=Palette.TEXT_DISABLED))

    @staticmethod
    def _tint_bg(color_hex: str) -> str:
        """Blend a status color toward Palette.BG_BASE for a soft pill bg.

        The result is a dark tinted background that lets the colored pill
        text pop without using a hardcoded hex value (the mock used
        #10251E for green, #2A2112 for amber, etc. — we derive similar
        values from the active theme palette).
        """
        try:
            c = QColor(color_hex)
            bg = QColor(Palette.BG_BASE)
            # 18% color + 82% bg — dark enough to read as a "tint", bright
            # enough to distinguish from the surrounding BG_SURFACE row.
            r = int(c.red()   * 0.18 + bg.red()   * 0.82)
            g = int(c.green() * 0.18 + bg.green() * 0.82)
            b = int(c.blue()  * 0.18 + bg.blue()  * 0.82)
            return QColor(r, g, b).name()
        except Exception:
            return Palette.BG_RAISED

    @staticmethod
    def _pill_style(color: str) -> str:
        """QSS for a colored status pill (rounded bg + colored text)."""
        bg = BatchGenerationDialog._tint_bg(color)
        return (
            "QLabel {{"
            "  color: {color};"
            "  background-color: {bg};"
            "  border-radius: 10px;"
            "  padding: 3px 8px;"
            "  font-size: 11px;"
            "  font-weight: 700;"
            "}}".format(color=color, bg=bg))

    # ------------------------------------------------------------------
    # Refresh helpers
    # ------------------------------------------------------------------
    def _on_manager_changed(self) -> None:
        self._refresh_table()
        self._update_buttons()
        self._update_summary()

    def _refresh_table(self) -> None:
        """Rebuild the table from the manager's current job list.

        P3.18 visual redesign: 5-column layout (was 7). The "Output" and
        "Error" columns are removed; their information is merged into the
        Status pill tooltip. The Status column now shows a colored pill
        widget (icon + tinted background) instead of plain text. The
        method signature is unchanged — callers (MainWindow, internal
        manager-changed callback) still call ``self._refresh_table()``.
        """
        jobs = self._manager.jobs
        self._table.setRowCount(len(jobs))
        running = self._manager.is_running
        for i, job in enumerate(jobs):
            # Row height 48px accommodates the pill widget + action buttons.
            self._table.setRowHeight(i, 48)

            # Column 0 — "#" (zero-padded like the mock: 01, 02, ...)
            num_item = QTableWidgetItem("{0:02d}".format(i + 1))
            num_item.setTextAlignment(Qt.Alignment.AlignCenter)
            num_item.setForeground(QColor(Palette.TEXT_SECONDARY))
            self._table.setItem(i, 0, num_item)

            # Column 1 — "Name / Segment" — show the output filename
            # (the actual generated file name), falling back to job.name
            # or truncated prompt if no filename is available yet.
            if job.output_path:
                display_name = os.path.basename(job.output_path)
            elif job.output_filename:
                display_name = job.output_filename
            else:
                display_name = job.name or job.prompt[:40]
            name_item = QTableWidgetItem(display_name)
            if job.status == JobStatus.SKIPPED:
                # De-emphasize skipped rows at a glance.
                name_item.setForeground(QColor(Palette.TEXT_DISABLED))
            self._table.setItem(i, 1, name_item)

            # Column 2 — "Status" (colored pill widget with icon).
            self._table.setCellWidget(i, 2, self._build_status_widget(job))

            # Column 3 — "Duration" (output audio length, right-aligned).
            # P3.27B: an output-guard anomaly (e.g. a runaway generation
            # with a long silent tail) appends a visible ⚠ marker — the
            # audio is NEVER discarded; the user can keep, inspect (Play)
            # or regenerate the part (task §17).
            anomaly = getattr(job, "anomaly", None)
            if job.output_duration > 0:
                dur_text = "{0:.2f}s".format(job.output_duration)
                if anomaly:
                    dur_text += " \u26a0"   # ⚠ warning marker
            else:
                dur_text = "\u2014"  # em dash for "no duration yet"
            dur_item = QTableWidgetItem(dur_text)
            dur_item.setTextAlignment(
                Qt.Alignment.AlignRight | Qt.Alignment.AlignVCenter)
            if anomaly:
                dur_item.setForeground(QColor(Palette.WARNING))
                dur_item.setToolTip(self._anomaly_tooltip(job, anomaly))
            else:
                dur_item.setForeground(QColor(Palette.TEXT_SECONDARY))
            self._table.setItem(i, 3, dur_item)

            # Column 4 — "Actions" (Play + Stop + Regen per-row buttons).
            self._table.setCellWidget(
                i, 4, self._build_action_widget(job, i, running))

    # ------------------------------------------------------------------
    # Row-widget builders (P3.18 — extracted from the old _refresh_table)
    # ------------------------------------------------------------------
    def _build_status_widget(self, job: BatchJob) -> QWidget:
        """Build a colored pill widget for the Status column.

        Pill variants (all using Palette colors, not mock hex values):
            COMPLETED  → green pill + check_circle icon ("Done")
            GENERATING → amber pill + AnimatedHourglass      ("Gen")
            PENDING    → gray pill + schedule icon           ("Queued")
            FAILED     → red pill   + error icon             ("Error")
            SKIPPED    → red pill   + stop icon              ("Stopped")

        The widget also carries a tooltip merging the old Output and
        Error columns (so the information is one hover away, without
        cluttering the table).
        """
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(6, 0, 6, 0)
        layout.setSpacing(5)
        layout.setAlignment(Qt.Alignment.AlignCenter)

        status = job.status
        icon_label: Optional[QLabel] = None
        pill_text = "Queued"
        pill_color = Palette.TEXT_SECONDARY

        if status == JobStatus.GENERATING:
            # Animated spinning hourglass replaces the static icon.
            hourglass = AnimatedHourglass()
            hourglass.start()
            layout.addWidget(hourglass)
            pill_text = "Gen"
            pill_color = Palette.WARNING
        elif status == JobStatus.COMPLETED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("check_circle", size=14,
                                  color=Palette.SUCCESS).pixmap(QSize(14, 14)))
            pill_text = "Done"
            pill_color = Palette.SUCCESS
        elif status == JobStatus.FAILED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("error", size=14,
                                  color=Palette.ERROR).pixmap(QSize(14, 14)))
            pill_text = "Error"
            pill_color = Palette.ERROR
        elif status == JobStatus.SKIPPED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("stop", size=14,
                                  color=Palette.ERROR).pixmap(QSize(14, 14)))
            pill_text = "Stopped"
            pill_color = Palette.ERROR
        else:  # PENDING → "Queued"
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("schedule", size=14,
                                  color=Palette.TEXT_SECONDARY
                                  ).pixmap(QSize(14, 14)))
            pill_text = "Queued"
            pill_color = Palette.TEXT_SECONDARY

        if icon_label is not None:
            layout.addWidget(icon_label)

        pill = QLabel(pill_text)
        pill.setStyleSheet(self._pill_style(pill_color))
        layout.addWidget(pill)

        # Merge old Output + Error columns into the pill tooltip.
        tips = []
        if job.error:
            tips.append("Error: " + job.error)
        if job.output_path:
            tips.append("Output: " + os.path.basename(job.output_path))
        # P3.27B: surface the output-guard verdict in the pill tooltip too.
        anomaly = getattr(job, "anomaly", None)
        if anomaly:
            tips.append("Warning: unusually long output — see the "
                        "Duration cell tooltip for details")
        if tips:
            widget.setToolTip("\n".join(tips))
        return widget

    def _anomaly_tooltip(self, job: BatchJob,
                         anomaly: dict) -> str:
        """P3.27B: tooltip text for an anomalous generation output.

        Shows the guard's reasons plus the measured speech/silence
        breakdown, and states explicitly that the audio was kept (the
        user decides: keep / inspect / regenerate).
        """
        analysis = anomaly.get("analysis", {}) if isinstance(anomaly, dict) else {}
        lines = ["Warning: unusually long output"]
        for reason in (anomaly.get("reasons", [])
                       if isinstance(anomaly, dict) else []):
            lines.append("  • " + str(reason))
        if analysis:
            lines.append(
                "Measured: {0:.1f}s total, {1:.1f}s speech, "
                "{2:.1f}s trailing silence".format(
                    float(analysis.get("total_s", 0.0) or 0.0),
                    float(analysis.get("speech_s", 0.0) or 0.0),
                    float(analysis.get("trailing_silence_s", 0.0) or 0.0)))
        lines.append("")
        lines.append("The audio file was kept — nothing was deleted.")
        lines.append("You can keep it, inspect it (Play), or regenerate "
                     "this part (Regen button).")
        return "\n".join(lines)

    def _build_action_widget(self, job: BatchJob, idx: int,
                             running: bool) -> QWidget:
        """Build the per-row Play + Stop + Regen action buttons.

        Extracted verbatim (signal connections preserved) from the old
        ``_refresh_table`` so the new 5-column layout can reuse the
        same logic without touching the slot handlers.
        """
        action_widget = QWidget()
        action_layout = QHBoxLayout(action_widget)
        action_layout.setContentsMargins(4, 4, 4, 4)
        action_layout.setSpacing(4)

        # Common button style — icon-only, no text, no font-size.
        # 28x28 buttons with 20px icons fit comfortably in any row.
        btn_style = (
            "QPushButton {{"
            "  background-color: {bg_raised};"
            "  color: {text_primary};"
            "  border: 1px solid {border};"
            "  border-radius: 4px;"
            "  padding: 2px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent};"
            "  color: {accent_text};"
            "  border: 1px solid {accent};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                bg_raised=Palette.BG_RAISED,
                text_primary=Palette.TEXT_PRIMARY,
                border=Palette.BORDER,
                accent=Palette.ACCENT,
                accent_text=Palette.ACCENT_TEXT,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED))

        # Play button — play_arrow icon plays the generated WAV.
        play_btn = QPushButton()
        play_btn.setToolTip("Play this part's audio")
        play_btn.setFixedSize(36, 36)
        play_btn.setIcon(IconRegistry.icon(
            "play_arrow", size=36, color=Palette.TEXT_PRIMARY))
        play_btn.setIconSize(QSize(32, 32))
        play_btn.setStyleSheet(btn_style)
        play_btn.setEnabled(not running and job.status == JobStatus.COMPLETED
                            and bool(job.output_path))
        play_btn.clicked.connect(
            lambda _checked=False, p=job.output_path:
            self.play_requested.emit(p) if p else None)
        action_layout.addWidget(play_btn)

        # Stop playback button — stop icon stops any currently playing audio.
        stop_play_btn = QPushButton()
        stop_play_btn.setToolTip("Stop playback")
        stop_play_btn.setFixedSize(36, 36)
        stop_play_btn.setIcon(IconRegistry.icon(
            "stop", size=36, color=Palette.TEXT_PRIMARY))
        stop_play_btn.setIconSize(QSize(32, 32))
        stop_play_btn.setStyleSheet(btn_style)
        stop_play_btn.clicked.connect(self.stop_playback_requested.emit)
        action_layout.addWidget(stop_play_btn)

        # Regen button — refresh icon regenerates this single job.
        regen_btn = QPushButton()
        regen_btn.setToolTip(
            "Regenerate ONLY this part.\n"
            "Queue position and output filename are preserved.")
        regen_btn.setFixedSize(36, 36)
        regen_btn.setIcon(IconRegistry.icon(
            "refresh", size=36, color=Palette.ACCENT_TEXT))
        regen_btn.setIconSize(QSize(32, 32))
        # Accent style for the Regen button (primary action).
        regen_btn.setStyleSheet(
            "QPushButton {{"
            "  background-color: {accent};"
            "  color: {accent_text};"
            "  border: 1px solid {accent};"
            "  border-radius: 4px;"
            "  padding: 2px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent_hover};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                accent=Palette.ACCENT,
                accent_text=Palette.ACCENT_TEXT,
                accent_hover=Palette.ACCENT_HOVER,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED,
                border=Palette.BORDER))
        can_regen = (not running
                     and job.status in (JobStatus.COMPLETED,
                                        JobStatus.FAILED))
        regen_btn.setEnabled(can_regen)
        regen_btn.clicked.connect(
            lambda _checked=False, idx=idx: self._on_regen(idx))
        action_layout.addWidget(regen_btn)
        return action_widget

    @staticmethod
    def _status_color(status: JobStatus) -> QColor:
        """Map a JobStatus to its canonical Palette color.

        Retained for backwards compatibility and used by the status-pill
        builder as the single source of truth for status → color mapping.
        """
        try:
            if status == JobStatus.COMPLETED:
                return QColor(Palette.SUCCESS)
            if status == JobStatus.FAILED:
                return QColor(Palette.ERROR)
            if status == JobStatus.GENERATING:
                return QColor(Palette.WARNING)
            if status == JobStatus.SKIPPED:
                return QColor(Palette.ERROR)
            if status == JobStatus.PENDING:
                return QColor(Palette.TEXT_SECONDARY)
        except Exception:
            pass
        return QColor(Palette.TEXT_PRIMARY)

    def _update_buttons(self) -> None:
        running = self._manager.is_running
        paused = self._manager.is_paused
        self._start_btn.setEnabled(not running or paused)
        self._pause_btn.setEnabled(running and not paused)
        self._stop_btn.setEnabled(running)
        # Job editing is disabled while running.
        editable = not running
        for btn in (self._add_btn, self._edit_btn, self._remove_btn,
                    self._dup_btn, self._up_btn, self._down_btn,
                    self._save_btn, self._load_btn, self._clear_btn):
            btn.setEnabled(editable)
        # Concatenate is enabled when not running AND at least 2 COMPLETED
        # jobs exist (concatenating 0 or 1 part is pointless).
        completed_count = sum(
            1 for j in self._manager.jobs if j.status == JobStatus.COMPLETED)
        self._concat_btn.setEnabled(not running and completed_count >= 2)

    def _update_summary(self) -> None:
        """Populate the QUEUE SUMMARY sidebar widgets.

        Replaces the old single multi-line HTML summary label with the
        new sidebar layout: progress headline + thin progress bar + four
        mono-font stat lines (Generated Audio / RTF / Wall Time / State).

        Counts (total / completed / failed / skipped / audio total) are
        computed from the manager's CURRENT job list so the sidebar
        always reflects what the user sees in the table — even before a
        batch has been started (the old code read from
        ``manager.summary`` which is only populated during a run, so a
        freshly-loaded queue showed "Queue is empty."). Run-level
        statistics (RTF, wall time) still come from ``manager.summary``
        because they only make sense in the context of a finished run.

        Method signature unchanged.
        """
        jobs = self._manager.jobs
        total = len(jobs)
        completed = sum(1 for j in jobs if j.status == JobStatus.COMPLETED)
        failed    = sum(1 for j in jobs if j.status == JobStatus.FAILED)
        skipped   = sum(1 for j in jobs if j.status == JobStatus.SKIPPED)
        audio_total = sum(j.output_duration for j in jobs
                          if j.status == JobStatus.COMPLETED)

        if total == 0:
            self._progress_text.setText("Idle")
            self._progress.setValue(0)
            self._audio_label.setText("Generated Audio    \u2014")
            self._rtf_label.setText("Real Time Factor    \u2014")
            self._wall_label.setText("Wall Time    \u2014")
            self._state_label.setText("State    Idle")
            return

        # Paused takes precedence over Running (visual improvement: the
        # mock shows "Paused" when paused, even if the batch loop is
        # still technically running underneath).
        if self._manager.is_paused:
            state = "Paused"
        elif self._manager.is_running:
            state = "Running"
        elif (completed + failed + skipped) == total:
            state = "Finished"
        else:
            state = "Idle"

        done = completed + failed + skipped
        self._progress_text.setText(
            "Progress    {done}/{total} completed".format(
                done=done, total=total))
        self._progress.setValue(int(round((done / total) * 100)))
        self._audio_label.setText(
            "Generated Audio    {0:.2f}s".format(audio_total))

        # RTF + wall time come from BatchSummary (only meaningful after a
        # run; show an em dash when no run data is available yet).
        s = self._manager.summary
        if s.total_wall_seconds > 0:
            self._rtf_label.setText(
                "Real Time Factor    {0:.2f} RTF".format(s.realtime_factor))
            self._wall_label.setText(
                "Wall Time    {0:.1f}s".format(s.total_wall_seconds))
        else:
            self._rtf_label.setText("Real Time Factor    \u2014")
            self._wall_label.setText("Wall Time    \u2014")
        self._state_label.setText("State    {0}".format(state))

    # ------------------------------------------------------------------
    # Slot handlers
    # ------------------------------------------------------------------
    def _selected_row(self) -> Optional[int]:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return None
        return rows[0].row()

    def _on_add(self) -> None:
        job = BatchJob(
            name="New Job",
            prompt="",
            parameters=GenerationParameters(),
        )
        dlg = JobEditDialog(job, self._voices, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            dlg.apply_to_job()
            self._manager.add_job(job)
            self._refresh_table()

    def _on_edit(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        jobs = self._manager.jobs
        if idx >= len(jobs):
            return
        # Edit a *copy* so the user can cancel without side-effects.
        original = jobs[idx]
        import dataclasses
        # Deep-ish copy via dict round-trip
        from engine.batch_manager import BatchJob as _BJ
        clone = _BJ.from_dict(original.to_dict())
        dlg = JobEditDialog(clone, self._voices, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            dlg.apply_to_job()
            # Replace the original in-place
            self._manager.remove_job(idx)
            self._manager._jobs.insert(idx, clone)  # noqa: SLF001
            self._refresh_table()

    def _on_remove(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        self._manager.remove_job(idx)
        self._refresh_table()

    def _on_duplicate(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        self._manager.duplicate_job(idx)
        self._refresh_table()

    def _on_move_up(self) -> None:
        idx = self._selected_row()
        if idx is None or idx == 0:
            return
        self._manager.move_job(idx, idx - 1)
        self._refresh_table()
        self._table.selectRow(idx - 1)

    def _on_move_down(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        jobs = self._manager.jobs
        if idx >= len(jobs) - 1:
            return
        self._manager.move_job(idx, idx + 1)
        self._refresh_table()
        self._table.selectRow(idx + 1)

    def _on_clear(self) -> None:
        if not self._manager.jobs:
            return
        reply = QMessageBox.question(
            self, "Clear Queue",
            "Remove all jobs from the queue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self._manager.clear_all()
            self._refresh_table()

    def _on_save_queue(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Batch Queue",
            "batch_queue.yaml",
            "YAML Files (*.yaml *.yml);;JSON Files (*.json);;All Files (*)")
        if not path:
            return
        try:
            self._manager.save_to_file(path)
            QMessageBox.information(self, "Saved",
                                    "Batch queue saved to:\n{0}".format(path))
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed",
                                 "Could not save the queue: {0}".format(exc))

    def _on_load_queue(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Batch Queue",
            "", "YAML Files (*.yaml *.yml);;JSON Files (*.json);;All Files (*)")
        if not path:
            return
        try:
            n = self._manager.load_from_file(path, replace=True)
            QMessageBox.information(self, "Loaded",
                                    "Loaded {0} jobs from:\n{1}".format(n, path))
        except Exception as exc:
            QMessageBox.critical(self, "Load Failed",
                                 "Could not load the queue: {0}".format(exc))
        self._refresh_table()

    def _on_start(self) -> None:
        if not self._manager.jobs:
            QMessageBox.information(self, "Empty Queue",
                                    "Add at least one job before starting.")
            return
        ok = self._manager.start()
        if not ok:
            QMessageBox.information(self, "Already Running",
                                    "The batch is already running.")
            return
        # Force immediate button refresh — don't wait for the
        # marshal_to_ui callback (which can be delayed).
        self._update_buttons()
        self._refresh_table()
        self._update_summary()

    def _on_regen(self, idx: int) -> None:
        """Regenerate a single job in-place.

        P3.27B: the actual reset + versioned-filename allocation is
        delegated to MainWindow via the ``regen_requested`` signal:
        Generate Long parts (part_index set) get a NEW VERSIONED output
        file (the previous version is preserved on disk — a pathological
        outlier regeneration can no longer destroy the previous good
        audio), while manual batch jobs keep the legacy
        overwrite-in-place contract. Queue position is preserved either
        way, so concatenation order is unaffected.
        """
        if self._manager.is_running:
            QMessageBox.warning(
                self, "Batch Running",
                "Stop the current batch before regenerating a single item.")
            return
        jobs = self._manager.jobs
        if idx < 0 or idx >= len(jobs):
            return
        job = jobs[idx]
        is_part = getattr(job, "part_index", None) is not None
        if is_part:
            message = (
                "Regenerate ONLY this part?\n\n"
                "  Part: {0}\n"
                "  Current output: {1}\n\n"
                "A NEW VERSIONED file will be created (e.g. v02); the\n"
                "previous version's audio is kept on disk. Queue position\n"
                "is preserved, so concatenation order is not affected.\n"
                "Other parts are NOT re-generated.".format(
                    job.name or job.prompt[:40],
                    job.output_filename or "(auto)"))
        else:
            message = (
                "Regenerate ONLY this item?\n\n"
                "  Item: {0}\n"
                "  Output: {1}\n\n"
                "The output file will be overwritten in place. Queue position\n"
                "is preserved, so concatenation order is not affected. Other\n"
                "items are NOT re-generated.".format(
                    job.name or job.prompt[:40],
                    job.output_filename or "(auto)"))
        reply = QMessageBox.question(
            self, "Regenerate Part", message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Yes)
        if reply != QMessageBox.StandardButton.Yes:
            return
        # P3.27B: MainWindow allocates the next version (Generate Long
        # parts) and performs the reset + start.
        self.regen_requested.emit(idx)

    def _on_pause(self) -> None:
        self._manager.pause()
        # Force immediate button refresh.
        self._update_buttons()

    def _on_stop(self) -> None:
        """Stop the batch and immediately update the UI (do not wait for
        the next marshal_to_ui callback - the user wants visual feedback
        the instant they click Stop)."""
        self._manager.stop()
        # Immediate refresh so SKIPPED rows appear at once.
        self._refresh_table()
        self._update_buttons()
        self._update_summary()

    def _on_concatenate(self) -> None:
        """Concatenate all COMPLETED parts into a single WAV.

        Collects the output paths of every COMPLETED job IN QUEUE ORDER
        and emits concatenate_requested(paths). The MainWindow handler
        does the actual concatenation via the engine's AudioManager and
        loads the result into the waveform player.

        Using the queue order directly guarantees the concatenation
        sequence is always correct, regardless of regen operations —
        regen preserves both the queue position and the output filename,
        so the list order IS the final audio order.
        """
        if self._manager.is_running:
            QMessageBox.warning(
                self, "Batch Running",
                "Stop the batch before concatenating.")
            return
        # Collect COMPLETED job output paths in queue order.
        paths = []
        for job in self._manager.jobs:
            if job.status == JobStatus.COMPLETED and job.output_path:
                # Resolve to absolute path for the engine's AudioManager.
                full = job.output_path
                if not os.path.isabs(full):
                    # The engine resolves relative paths against APP_ROOT,
                    # so pass the relative path as-is — the MainWindow
                    # handler will resolve it.
                    pass
                paths.append(full)
        if len(paths) < 2:
            QMessageBox.information(
                self, "Nothing to Concatenate",
                "Need at least 2 completed parts to concatenate.\n"
                "Current completed: {0}".format(len(paths)))
            return
        # Emit so MainWindow can do the actual work (it has the engine).
        self.concatenate_requested.emit(paths)

    # ------------------------------------------------------------------
    # Close handling
    # ------------------------------------------------------------------
    def closeEvent(self, event) -> None:
        # Save the dialog size so it persists across reopens.
        self._save_geometry()
        # Stop the batch (mark PENDING as SKIPPED) when the dialog closes
        # so we don't leave orphaned jobs running in the background.
        if self._manager.is_running:
            self._manager.stop()
        super().closeEvent(event)

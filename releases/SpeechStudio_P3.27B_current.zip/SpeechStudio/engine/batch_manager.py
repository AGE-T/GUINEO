"""
SpeechStudio Engine - Batch Manager
====================================

Manages queueing, sequencing, and tracking of multiple generation jobs.

Key responsibilities:
    - Hold an ordered list of BatchJob objects (the queue).
    - Drive the engine through them one at a time with a small delay
      between jobs.
    - Recover from transient "already running" errors by retrying after
      a short timeout.
    - Marshal status updates back to the UI thread via a single
      ``marshal_to_ui`` callable (the UI side sets it to
      ``QTimer.singleShot(0, fn)``).
    - Persist the queue to YAML and reload it.

The BatchManager is engine-agnostic: it accepts a callable
``submit_fn(request) -> Future`` and a callable
``cancel_fn() -> bool`` rather than importing the Engine directly.  This
keeps the dependency arrow one-way (engine -> batch_manager) and makes
testing trivial.

AI Development Rules section 11:
    Long-running operations never execute on the UI thread.  All callbacks
    fired by the BatchManager are marshalled through ``marshal_to_ui`` so
    the UI never touches batch state from a worker thread.
"""

from __future__ import annotations
import enum
import threading
import time
import os
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from engine.models import GenerationRequest, GenerationParameters, GenerationResult
from engine.logger import get_logger

logger = get_logger("batch")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _ts() -> str:
    """Return a timestamp + thread-name prefix used in batch log messages."""
    return "{0} [{1}]".format(
        time.strftime("%Y-%m-%d %H:%M:%S"),
        threading.current_thread().name,
    )


# ---------------------------------------------------------------------------
# Job status enum
# ---------------------------------------------------------------------------
class JobStatus(enum.Enum):
    PENDING = "pending"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

    def __str__(self) -> str:
        return self.value


# ---------------------------------------------------------------------------
# BatchJob
# ---------------------------------------------------------------------------
@dataclass
class BatchJob:
    """A single queued generation.

    Attributes:
        name: human-readable label.
        prompt: the full prompt text (may include Higgs tokens).
        voice_id: voice profile id, or None.
        output_filename: desired output filename, or None (= auto).
        parameters: full GenerationParameters dataclass.
        status: current JobStatus.
        error: human-readable error message, or None.
        output_path: relative path of the saved WAV (set on success).
        output_duration: duration of the saved audio (seconds).
        generation_time: wall-clock time the model took (seconds).
        started_at, finished_at: epoch seconds (or None).
    """

    name: str = ""
    prompt: str = ""
    voice_id: Optional[str] = None
    output_filename: Optional[str] = None
    parameters: GenerationParameters = field(default_factory=GenerationParameters)
    project: str = "Default"
    status: JobStatus = JobStatus.PENDING
    error: Optional[str] = None
    output_path: Optional[str] = None
    output_duration: float = 0.0
    generation_time: float = 0.0
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    # Multi-speaker dialogue: the speaker label (e.g. "CAPTAIN") this job
    # belongs to. Empty/None for single-speaker narration. This is the
    # authoritative source for dialogue detection (not a string heuristic).
    speaker: Optional[str] = None
    # C2 FIX: Scene/Character context fields so they survive the
    # BatchJob → GenerationRequest → Engine → Result → AudioAsset/History
    # chain. Previously these were dropped in to_request(), causing every
    # Generate Long HistoryEntry to have scene_id=None, character_id=None.
    scene_id: Optional[str] = None
    scene_name: Optional[str] = None
    character_id: Optional[str] = None
    # P3.27B: Long Generation part provenance + expected duration (from
    # the splitter's SplitPart.estimated_duration) + the output-guard
    # verdict captured from the GenerationResult on completion. part_index
    # also marks a job as a Generate Long part for versioned regeneration
    # (manual batch jobs keep the legacy overwrite-in-place behaviour).
    part_index: Optional[int] = None
    part_version: Optional[int] = None
    expected_duration: Optional[float] = None
    anomaly: Optional[Dict[str, Any]] = None

    # ------------------------------------------------------------------
    # (De)serialisation
    # ------------------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "prompt": self.prompt,
            "voice_id": self.voice_id,
            "output_filename": self.output_filename,
            "parameters": self.parameters.to_dict(),
            "status": self.status.value,
            "error": self.error,
            "output_path": self.output_path,
            "output_duration": self.output_duration,
            "generation_time": self.generation_time,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "speaker": self.speaker,
            "project": self.project,
            # C2 FIX: persist scene/character context
            "scene_id": self.scene_id,
            "scene_name": self.scene_name,
            "character_id": self.character_id,
            # P3.27B: part provenance + output-guard verdict
            "part_index": self.part_index,
            "part_version": self.part_version,
            "expected_duration": self.expected_duration,
            "anomaly": self.anomaly,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchJob":
        params_data = data.get("parameters", {})
        if isinstance(params_data, GenerationParameters):
            params = params_data
        else:
            params = GenerationParameters.from_dict(params_data or {})
        try:
            status = JobStatus(data.get("status", "pending"))
        except ValueError:
            status = JobStatus.PENDING
        return cls(
            name=str(data.get("name", "")),
            prompt=str(data.get("prompt", "")),
            voice_id=data.get("voice_id"),
            output_filename=data.get("output_filename"),
            parameters=params,
            status=status,
            error=data.get("error"),
            output_path=data.get("output_path"),
            output_duration=float(data.get("output_duration", 0.0) or 0.0),
            generation_time=float(data.get("generation_time", 0.0) or 0.0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            speaker=data.get("speaker"),
            project=str(data.get("project", "Default")),
            # C2 FIX: restore scene/character context
            scene_id=data.get("scene_id"),
            scene_name=data.get("scene_name"),
            character_id=data.get("character_id"),
            # P3.27B: restore part provenance + anomaly (tolerant defaults)
            part_index=data.get("part_index"),
            part_version=data.get("part_version"),
            expected_duration=data.get("expected_duration"),
            anomaly=data.get("anomaly"),
        )

    def to_request(self) -> GenerationRequest:
        """Build a fresh GenerationRequest from this job's settings.

        The ``status``/``output_*`` fields are NOT included: a fresh
        GenerationRequest is purely an input to the Engine.

        C2 FIX: now forwards speaker, scene_id, scene_name, character_id
        so they survive into the GenerationResult → AudioAsset / HistoryEntry.

        P3.27B: also forwards part_index/part_version/expected_duration so
        the output guard can compare the generated duration against the
        text-based estimate and History can record part provenance.
        """
        return GenerationRequest(
            text=self.prompt,
            voice_id=self.voice_id,
            parameters=self.parameters,
            output_filename=self.output_filename,
            project=self.project,
            speaker=self.speaker,
            scene_id=self.scene_id,
            scene_name=self.scene_name,
            character_id=self.character_id,
            part_index=self.part_index,
            part_version=self.part_version,
            expected_duration=self.expected_duration,
        )


# ---------------------------------------------------------------------------
# BatchSummary
# ---------------------------------------------------------------------------
@dataclass
class BatchSummary:
    """Aggregate statistics for a finished (or stopped) batch run."""

    total: int = 0
    completed: int = 0
    failed: int = 0
    skipped: int = 0
    total_audio_seconds: float = 0.0
    total_wall_seconds: float = 0.0
    started_at: Optional[float] = None
    finished_at: Optional[float] = None

    @property
    def is_finished(self) -> bool:
        return (self.completed + self.failed + self.skipped) >= self.total \
            and self.total > 0

    @property
    def duration_seconds(self) -> float:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return 0.0

    @property
    def realtime_factor(self) -> float:
        if self.total_audio_seconds <= 0:
            return 0.0
        return (self.duration_seconds / self.total_audio_seconds
                if self.duration_seconds > 0 else 0.0)


# ---------------------------------------------------------------------------
# BatchManager
# ---------------------------------------------------------------------------
class BatchManager:
    """Coordinates sequential execution of multiple generation jobs.

    The manager is fully thread-safe: the UI thread reads ``jobs`` and
    calls ``start``/``pause``/``stop``; the engine worker fires future
    callbacks from its own thread.  All UI-facing callbacks are
    marshalled through ``marshal_to_ui`` so the UI never touches batch
    state directly from a worker thread.
    """

    # Inter-job delay (milliseconds) - prevents back-to-back GPU stress.
    INTER_JOB_DELAY_MS = 500
    # Retry delay when the engine reports "already running".
    RETRY_DELAY_MS = 300
    # Maximum retry attempts before a job is marked FAILED.
    MAX_RETRIES = 10

    def __init__(
        self,
        submit_fn: Callable[[GenerationRequest], Any],
        cancel_fn: Optional[Callable[[], bool]] = None,
        marshal_to_ui: Optional[Callable[[Callable[[], None]], None]] = None,
    ):
        self._submit_fn = submit_fn
        self._cancel_fn = cancel_fn
        self.marshal_to_ui = marshal_to_ui or (lambda fn: fn())

        self._jobs: List[BatchJob] = []
        self._lock = threading.RLock()
        self._running = False
        self._paused = False
        self._stop_requested = False
        self._current_index: Optional[int] = None
        self._summary: BatchSummary = BatchSummary()
        self._retry_counts: Dict[int, int] = {}

    # ------------------------------------------------------------------
    # Properties (read-only snapshots for the UI)
    # ------------------------------------------------------------------
    @property
    def jobs(self) -> List[BatchJob]:
        with self._lock:
            return list(self._jobs)

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._running

    @property
    def is_paused(self) -> bool:
        with self._lock:
            return self._paused

    @property
    def current_index(self) -> Optional[int]:
        with self._lock:
            return self._current_index

    @property
    def summary(self) -> BatchSummary:
        with self._lock:
            return self._summary

    # ------------------------------------------------------------------
    # Queue manipulation (called from the UI thread)
    # ------------------------------------------------------------------
    def add_job(self, job: BatchJob) -> int:
        """Append ``job`` to the queue.  Returns its new index."""
        with self._lock:
            self._jobs.append(job)
            return len(self._jobs) - 1

    def remove_job(self, index: int) -> None:
        with self._lock:
            if 0 <= index < len(self._jobs):
                del self._jobs[index]

    def move_job(self, src: int, dst: int) -> None:
        with self._lock:
            if 0 <= src < len(self._jobs) and 0 <= dst < len(self._jobs):
                job = self._jobs.pop(src)
                self._jobs.insert(dst, job)

    def duplicate_job(self, index: int) -> Optional[int]:
        with self._lock:
            if 0 <= index < len(self._jobs):
                src = self._jobs[index]
                clone = BatchJob(
                    name="{0} (copy)".format(src.name),
                    prompt=src.prompt,
                    voice_id=src.voice_id,
                    output_filename=src.output_filename,
                    parameters=GenerationParameters.from_dict(
                        src.parameters.to_dict()),
                    # P3.23: preserve the scene/speaker/character context so
                    # the duplicated part keeps the same History lineage as
                    # the original (design record §22).
                    project=src.project,
                    speaker=src.speaker,
                    scene_id=src.scene_id,
                    scene_name=src.scene_name,
                    character_id=src.character_id,
                )
                self._jobs.insert(index + 1, clone)
                return index + 1
            return None

    def clear_finished(self) -> None:
        """Remove all COMPLETED/FAILED/SKIPPED jobs."""
        with self._lock:
            self._jobs = [
                j for j in self._jobs
                if j.status in (JobStatus.PENDING, JobStatus.GENERATING)
            ]

    def clear_all(self) -> None:
        with self._lock:
            self._jobs.clear()
            self._retry_counts.clear()

    def regen_job(self, index: int) -> bool:
        """Reset a single job to PENDING so it will be re-processed.

        CRITICAL for concatenation order: this method preserves the job's
        position in the queue and its ``output_filename``. The regenerated
        audio overwrites the same file, so when the batch finishes and
        concatenation runs, the part ordering is unchanged.

        Use :meth:`start` with ``reset_failed=False`` afterwards to process
        ONLY the reset job(s) without touching other FAILED/SKIPPED jobs.

        Args:
            index: the job's position in the queue.

        Returns:
            True if the job was reset, False if the index is invalid, the
            job is currently GENERATING, or already PENDING.
        """
        with self._lock:
            if index < 0 or index >= len(self._jobs):
                return False
            job = self._jobs[index]
            if job.status == JobStatus.GENERATING:
                return False  # cannot regen a job that's currently running
            if job.status == JobStatus.PENDING:
                return False  # already pending, nothing to do
            # Reset to PENDING — but KEEP output_filename and position!
            job.status = JobStatus.PENDING
            job.error = None
            job.output_path = None
            job.output_duration = 0.0
            job.generation_time = 0.0
            job.started_at = None
            job.finished_at = None
            # P3.27B: also clear the previous run's output-guard verdict so
            # the regenerated part starts from a clean state (the verdict is
            # re-captured from the new GenerationResult on completion).
            job.anomaly = None
            logger.info("regen_job: reset job %d '%s' to PENDING "
                        "(output_filename preserved: %s)",
                        index, job.name, job.output_filename)
            return True

    # ------------------------------------------------------------------
    # YAML persistence
    # ------------------------------------------------------------------
    def save_to_file(self, path: str) -> str:
        """Persist the job queue to ``path`` as YAML (or JSON fallback).

        Returns the absolute path that was written.
        """
        with self._lock:
            payload = {
                "schema_version": 1,
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "jobs": [j.to_dict() for j in self._jobs],
            }
        try:
            import yaml  # type: ignore
            text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
            ext = ".yaml"
        except ImportError:
            text = json.dumps(payload, indent=2, ensure_ascii=False)
            ext = ""

        if not path.endswith((".yaml", ".yml", ".json")):
            path = path + ext
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return path

    def load_from_file(self, path: str, replace: bool = True) -> int:
        """Load jobs from ``path``.  Returns the number of jobs loaded.

        ``status`` is always reset to PENDING when loading (a saved
        COMPLETED job is not re-executed by ``start`` unless the user
        resets it).
        """
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()

        if path.endswith(".json"):
            import json as _json
            data = _json.loads(text)
        else:
            try:
                import yaml  # type: ignore
                data = yaml.safe_load(text)
            except ImportError:
                import json as _json
                data = _json.loads(text)

        jobs_data = data.get("jobs", []) if isinstance(data, dict) else []
        jobs: List[BatchJob] = []
        for jd in jobs_data:
            if not isinstance(jd, dict):
                continue
            job = BatchJob.from_dict(jd)
            # Reset transient state on load.
            job.status = JobStatus.PENDING
            job.error = None
            job.output_path = None
            job.output_duration = 0.0
            job.generation_time = 0.0
            job.started_at = None
            job.finished_at = None
            jobs.append(job)

        with self._lock:
            if replace:
                self._jobs = jobs
            else:
                self._jobs.extend(jobs)
            self._retry_counts.clear()
        return len(jobs)

    # ------------------------------------------------------------------
    # Execution control
    # ------------------------------------------------------------------
    def start(self, reset_failed: bool = True) -> bool:
        """Begin processing the queue.  Returns False if already running.

        Args:
            reset_failed: if True (default), reset all SKIPPED/FAILED jobs
                back to PENDING so a full re-start is possible. Set to False
                when regenerating specific jobs via :meth:`regen_job` so only
                the explicitly-reset jobs are re-processed.
        """
        with self._lock:
            if self._running:
                return False
            # Reset SKIPPED/FAILED back to PENDING so a re-start is possible.
            if reset_failed:
                for j in self._jobs:
                    if j.status in (JobStatus.SKIPPED, JobStatus.FAILED):
                        j.status = JobStatus.PENDING
                        j.error = None
            self._running = True
            self._paused = False
            self._stop_requested = False
            self._summary = BatchSummary(
                total=sum(1 for j in self._jobs),
                started_at=time.time(),
            )
            pending_count = sum(1 for j in self._jobs if j.status == JobStatus.PENDING)
            logger.info("Batch START: %d jobs (%d pending)", len(self._jobs), pending_count)
        # Kick off the first job from the calling (UI) thread.  Subsequent
        # jobs are scheduled via marshal_to_ui.
        self._process_next()
        return True

    def pause(self) -> None:
        with self._lock:
            self._paused = True

    def resume(self) -> None:
        with self._lock:
            self._paused = False
            if self._running and self._current_index is None:
                # Restart the queue if we paused between jobs.
                self.marshal_to_ui(self._process_next)

    def stop(self) -> None:
        """Immediately mark all PENDING jobs as SKIPPED and stop the queue.

        Any job currently GENERATING is left to finish on its own (Python
        cannot safely interrupt a CUDA generation); the next job will not
        be scheduled.
        """
        with self._lock:
            self._stop_requested = True
            self._paused = False
            for j in self._jobs:
                if j.status == JobStatus.PENDING:
                    j.status = JobStatus.SKIPPED
                    j.error = "Skipped: batch stopped by user."
            if self._cancel_fn is not None:
                try:
                    self._cancel_fn()
                except Exception:
                    pass
            # Update summary immediately so the UI reflects the stop.
            self._recompute_summary_locked()
            self.marshal_to_ui(self._emit_changed)

    # ------------------------------------------------------------------
    # Internal: processing loop
    # ------------------------------------------------------------------
    def _process_next(self) -> None:
        """Find the next PENDING job and submit it.  Called on the UI thread
        (via marshal_to_ui) so it is safe to touch Qt-free engine state.
        """
        logger.info("_process_next: entry (thread=%s)", threading.current_thread().name)
        with self._lock:
            if self._stop_requested:
                logger.info("_process_next: stop_requested -> finish_batch")
                self._finish_batch()
                return
            if self._paused:
                logger.info("_process_next: paused -> return")
                return

            next_idx: Optional[int] = None
            for i, j in enumerate(self._jobs):
                if j.status == JobStatus.PENDING:
                    next_idx = i
                    break

            if next_idx is None:
                logger.info("_process_next: no PENDING jobs -> finish_batch")
                self._finish_batch()
                return

            job = self._jobs[next_idx]
            job.status = JobStatus.GENERATING
            job.started_at = time.time()
            job.error = None
            self._current_index = next_idx
            logger.info("_process_next: starting job %d '%s'", next_idx, job.name)
            self.marshal_to_ui(self._emit_changed)

        # Build the request outside the lock (the Engine may take a
        # moment to accept it).
        request = job.to_request()

        try:
            future = self._submit_fn(request)
            logger.info("_process_next: submit_fn returned future for job %d", next_idx)
            # The Engine returns a Future; attach our completion callback.
            future.add_done_callback(self._on_job_done)
        except RuntimeError as exc:
            # Engine reports "already running" - retry after a short delay.
            if "already running" in str(exc).lower():
                retries = self._retry_counts.get(next_idx, 0)
                logger.warning("_process_next: RuntimeError 'already running' for job %d (retry %d/%d)",
                               next_idx, retries + 1, self.MAX_RETRIES)
                if retries < self.MAX_RETRIES:
                    self._retry_counts[next_idx] = retries + 1
                    # Revert the job to PENDING so a future _process_next
                    # pass picks it up again.
                    with self._lock:
                        job.status = JobStatus.PENDING
                        job.started_at = None
                        self._current_index = None
                    # Schedule a retry on the UI thread.
                    try:
                        # Use Qt's QTimer if available, else fall back to
                        # marshal_to_ui (which on the UI side can be
                        # QTimer.singleShot).
                        from PySide6.QtCore import QTimer
                        QTimer.singleShot(self.RETRY_DELAY_MS,
                                          self._process_next)
                    except ImportError:
                        self.marshal_to_ui(self._process_next)
                    return
                else:
                    # Too many retries - mark as FAILED.
                    with self._lock:
                        job.status = JobStatus.FAILED
                        job.error = "Engine was busy after {0} retries.".format(
                            self.MAX_RETRIES)
                        job.finished_at = time.time()
                        self._current_index = None
                        self._recompute_summary_locked()
                    self._post_job_ui()
                    return
            else:
                # Some other RuntimeError - treat as failure.
                with self._lock:
                    job.status = JobStatus.FAILED
                    job.error = str(exc)
                    job.finished_at = time.time()
                    self._current_index = None
                    self._recompute_summary_locked()
                self._post_job_ui()
                return

    def _on_job_done(self, future) -> None:
        """Future-done callback (runs on the worker thread).

        We process the result directly here (only touching batch state
        protected by self._lock) and then marshal ONLY the UI update
        + next-job scheduling to the UI thread.
        """
        logger.info("_on_job_done: called on thread=%s", threading.current_thread().name)
        # Capture the result before marshalling.
        result: Optional[GenerationResult] = None
        error: Optional[str] = None
        try:
            result = future.result()
            logger.info("_on_job_done: future.result() success=%s",
                        result.success if result else "None")
        except Exception as exc:
            error = str(exc)
            logger.error("_on_job_done: future.result() raised: %s", exc)

        # Find the job and update its state directly (thread-safe via _lock).
        with self._lock:
            idx = self._current_index
            if idx is None or idx >= len(self._jobs):
                logger.warning("_on_job_done: _current_index is None — batch stopped?")
                return
            job = self._jobs[idx]
            job.finished_at = time.time()
            if error is not None:
                job.status = JobStatus.FAILED
                job.error = error
            elif result is None or not result.success:
                job.status = JobStatus.FAILED
                if result is not None and result.errors:
                    job.error = "; ".join(
                        e.get("message", str(e)) for e in result.errors)
                else:
                    job.error = "Generation failed."
            else:
                job.status = JobStatus.COMPLETED
                job.output_path = result.output_path
                job.output_duration = result.output_duration
                job.generation_time = result.generation_time
                # P3.27B: capture the output-guard verdict (None = normal)
                # so the Batch dialog can flag pathological outputs.
                job.anomaly = getattr(result, "output_anomaly", None)
                job.part_version = getattr(result, "part_version", None) \
                    if getattr(result, "part_version", None) is not None \
                    else job.part_version
            self._current_index = None
            self._recompute_summary_locked()
            logger.info("_on_job_done: job '%s' -> %s", job.name, job.status.value)

        # Marshal the UI update + next-job scheduling to the UI thread.
        # This is the ONLY part that needs to run on the UI thread.
        logger.info("_on_job_done: marshalling UI update + _after_job to UI thread")
        self.marshal_to_ui(self._post_job_ui)

    def _post_job_ui(self) -> None:
        """Run on the UI thread after a job completes: update UI + schedule next."""
        self._emit_changed()
        self._after_job()

    def _after_job(self) -> None:
        """Wait a short delay (INTER_JOB_DELAY_MS) then process the next job."""
        logger.info("_after_job: scheduling _process_next in %dms", self.INTER_JOB_DELAY_MS)
        try:
            from PySide6.QtCore import QTimer
            QTimer.singleShot(self.INTER_JOB_DELAY_MS, self._process_next)
        except ImportError:
            # Without Qt we can't schedule a delay - process immediately.
            self.marshal_to_ui(self._process_next)

    def _finish_batch(self) -> None:
        """Mark the batch as finished and emit a final changed event."""
        logger.info("_finish_batch: called")
        with self._lock:
            self._running = False
            self._current_index = None
            self._summary.finished_at = time.time()
            self._recompute_summary_locked()
            logger.info("_finish_batch: completed=%d failed=%d skipped=%d",
                        self._summary.completed, self._summary.failed,
                        self._summary.skipped)
            summary_snapshot = self._summary
        self.marshal_to_ui(self._emit_changed)
        # Fire the batch-completed callback (if registered) with a snapshot
        # of the final summary. Used by the Long Narration flow to trigger
        # concatenation of all parts into one WAV.
        cb = self._on_batch_completed
        if cb is not None:
            try:
                cb(summary_snapshot)
            except Exception as exc:
                logger.warning("on_batch_completed callback raised: %s", exc)

    # ------------------------------------------------------------------
    # Summary + events
    # ------------------------------------------------------------------
    def _recompute_summary_locked(self) -> None:
        completed = sum(1 for j in self._jobs if j.status == JobStatus.COMPLETED)
        failed = sum(1 for j in self._jobs if j.status == JobStatus.FAILED)
        skipped = sum(1 for j in self._jobs if j.status == JobStatus.SKIPPED)
        total_audio = sum(j.output_duration for j in self._jobs
                          if j.status == JobStatus.COMPLETED)
        total_wall = sum(j.generation_time for j in self._jobs
                         if j.status == JobStatus.COMPLETED)
        started = self._summary.started_at
        self._summary = BatchSummary(
            total=len(self._jobs),
            completed=completed,
            failed=failed,
            skipped=skipped,
            total_audio_seconds=total_audio,
            total_wall_seconds=total_wall,
            started_at=started,
            finished_at=time.time(),
        )

    def _emit_changed(self) -> None:
        """Notify listeners that the queue state changed.

        The BatchManager does not own a Qt signal (to keep it Qt-free),
        but it does invoke any ``on_changed`` callback registered via
        :meth:`set_on_changed`.
        """
        cb = self._on_changed
        if cb is not None:
            try:
                cb(self)
            except Exception:
                pass

    _on_changed: Optional[Callable[["BatchManager"], None]] = None

    def set_on_changed(self, cb: Optional[Callable[["BatchManager"], None]]) -> None:
        self._on_changed = cb

    # Optional one-shot callback fired when the ENTIRE batch finishes
    # (all jobs processed). Used by the Long Narration flow to concatenate
    # all parts into a single WAV after generation completes.
    _on_batch_completed: Optional[Callable[["BatchSummary"], None]] = None

    def set_on_batch_completed(
        self, cb: Optional[Callable[["BatchSummary"], None]]) -> None:
        """Register a callback fired once when the whole batch finishes.

        The callback receives a :class:`BatchSummary` snapshot.
        """
        self._on_batch_completed = cb

"""
SpeechStudio Model Loading Dialog.

Shows a modal dialog while the model loads into VRAM, with a progress
message and a spinner. The user can cancel the load.
"""

from __future__ import annotations

from PySide6.QtCore import QEventLoop, Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QApplication, QDialog, QVBoxLayout, QLabel, QProgressBar,
    QPushButton, QWidget,
)
from ui.theme import Palette


class ModelLoadDialog(QDialog):
    """Modal dialog shown while the model is loading.

    Displays a spinner animation (simulated with a progress bar) and
    status messages. The load happens on a worker thread; this dialog
    polls the ModelManager status to update the progress.
    """

    load_cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Loading Model")
        self.setModal(True)
        # P3.25 FIX: 180px was too short for the content (title + status +
        # progress + timer + Cancel under the theme QSS paddings) — the
        # layout squeezed the Cancel button to 15px, erasing its label.
        # 220px fits every item at its size hint.
        self.setFixedSize(400, 220)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowCloseButtonHint)
        # P3.25 FIX (white/blank loading window): the app-wide QSS styles
        # QDialog backgrounds as TRANSPARENT (the main window's dark look
        # comes from the ambient background layers behind it — a separate
        # top-level dialog has no such backdrop). Without an explicit
        # background the dialog body fell back to the platform default.
        # Set the dark surface explicitly, exactly like the (visually
        # verified) AssembleDialog does.
        self.setStyleSheet("background-color: {0};".format(Palette.BG_BASE))
        self._build_ui()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._poll_status)
        self._elapsed = 0

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        self._title = QLabel("Loading Higgs Audio V3 Model")
        self._title.setStyleSheet("font-size: 16px; font-weight: bold; color: %s;" % Palette.TEXT_PRIMARY)
        layout.addWidget(self._title)

        self._status = QLabel("Initializing...")
        self._status.setStyleSheet("color: %s;" % Palette.TEXT_SECONDARY)
        self._status.setWordWrap(True)
        layout.addWidget(self._status)

        self._progress = QProgressBar()
        self._progress.setRange(0, 0)  # indeterminate (busy indicator)
        self._progress.setTextVisible(False)
        self._progress.setFixedHeight(8)
        layout.addWidget(self._progress)

        self._timer_label = QLabel("")
        self._timer_label.setStyleSheet("color: %s;" % Palette.TEXT_DISABLED)
        self._timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._timer_label)

        self._cancel_btn = QPushButton("Cancel")
        self._cancel_btn.clicked.connect(self._on_cancel)
        layout.addWidget(self._cancel_btn, alignment=Qt.AlignmentFlag.AlignCenter)

    def _on_cancel(self) -> None:
        self.load_cancelled.emit()
        self.reject()

    def start(self) -> None:
        """Start polling, show the dialog AND paint it synchronously.

        P3.25 FIX (white/blank loading window): ``show()`` only MAPS the
        window — the actual paint is deferred to the event loop. The
        model-load worker thread starts ``import torch`` immediately
        after the caller submits the load job; on Windows that import
        holds the GIL in long C-extension stretches, so the GUI thread's
        event loop cannot process the dialog's expose/paint events for
        many seconds. The user then sees a mapped-but-unpainted window:
        a white, content-free rectangle with only the OS title bar.

        Forcing the paint here — while the GUI thread still owns the GIL
        and BEFORE the caller submits the load job — guarantees the dark
        themed dialog (title, status, progress bar, Cancel) is on screen
        before any GIL starvation can begin.
        """
        self._elapsed = 0
        self._timer.start(500)  # poll every 500ms
        self.show()
        # Flush pending layout/expose events (but NOT user input — no
        # re-entrancy from clicks), then paint synchronously into the
        # backing store. This is the standard Qt splash-screen pattern.
        QApplication.processEvents(
            QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents)
        self.repaint()

    def stop(self) -> None:
        """Stop polling and close the dialog."""
        self._timer.stop()
        self.accept()

    def _poll_status(self) -> None:
        self._elapsed += 0.5
        mins = int(self._elapsed) // 60
        secs = int(self._elapsed) % 60
        self._timer_label.setText("Elapsed: {0:02d}:{1:02d}".format(mins, secs))

    def set_status(self, message: str) -> None:
        self._status.setText(message)

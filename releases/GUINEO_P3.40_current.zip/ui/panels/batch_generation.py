"""
SpeechStudio Batch Generation Dialog.

Provides:
    - JobEditDialog   : modal dialog for editing a single BatchJob.
    - BatchGenerationDialog : non-modal dialog that drives the
                              BatchManager and shows a live job table.

Architecture:
    The dialog is a thin Qt view over the engine's BatchManager.  All
    queueing, retry, and inter-job pacing happens in the BatchManager;
    the dialog only:
        - reads ``manager.jobs`` to refresh the table,
        - calls ``manager.start()`` / ``pause()`` / ``stop()`` on button clicks,
        - connects ``manager.set_on_changed`` to ``self._refresh_table``,
        - wires the marshal_to_ui callback to ``QTimer.singleShot(0, fn)``.
"""

from __future__ import annotations
import os
from typing import Optional, List

from PySide6.QtCore import (
    Qt, QTimer, Signal, QObject, QSize, QPoint, QPointF, QRectF,
)
from PySide6.QtGui import (
    QColor, QFont, QPainter, QPen, QBrush, QIcon, QPixmap,
)
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton, QLabel,
    QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QFileDialog, QMessageBox, QAbstractItemView,
    QSizePolicy, QDialogButtonBox, QWidget, QProgressBar, QFrame,
)

from ui.theme import Palette
from ui.icon_registry import IconRegistry
from engine.models import GenerationParameters, VoiceProfile
from engine.batch_manager import BatchJob, BatchManager, JobStatus


def _safe_int(value) -> int:
    """Tolerant int coercion for model-supplied version numbers."""
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _fit_button_height(btn: QPushButton, minimum: int = 24) -> None:
    """P3.35 §29/§30: metrics-aware compact button height.

    The application's global QPushButton stylesheet pads 7px vertically
    + a 1px border; a hardcoded 24px widget is TALLER-requested than its
    content box, so the label's bottom was clipped (the reported "None"
    button). Deriving the height from the widget's own sizeHint (which
    already includes the stylesheet padding + font metrics) keeps the
    compact look while guaranteeing the full glyph box fits and stays
    vertically centered at any font/DPI.
    """
    try:
        hint = btn.sizeHint().height()
    except Exception:
        hint = minimum
    btn.setFixedHeight(max(minimum, hint))


def _popup_menu_above(menu, btn):
    """P3.30(b/c): execute ``menu`` synchronously, anchored ABOVE ``btn``.

    The previous ``menu.exec()`` (no position) opened the menu at the
    cursor — on Windows it repeatedly appeared frameless at the screen's
    top-left corner. Anchoring to the button is deterministic: the menu
    opens just above the button (there is ample space in the sidebar),
    falling back to just below when the screen edge doesn't allow above.
    Returns the chosen action (or None).
    """
    menu.adjustSize()
    size = menu.sizeHint()
    btn_top_left = btn.mapToGlobal(QPoint(0, 0))
    pos = QPoint(btn_top_left.x(),
                 btn_top_left.y() - size.height() - 6)
    screen = btn.screen()
    if screen is not None:
        avail = screen.availableGeometry()
        if pos.y() < avail.top():
            pos.setY(btn_top_left.y() + btn.height() + 6)
        if pos.x() + size.width() > avail.right() + 1:
            pos.setX(max(avail.left(), avail.right() + 1 - size.width()))
    return menu.exec(pos)


# ---------------------------------------------------------------------------
# Job edit dialog
# ---------------------------------------------------------------------------
class JobEditDialog(QDialog):
    """Modal dialog for editing a single BatchJob.

    Includes a seed field (QLineEdit, empty = random, integer = specific seed).
    """

    def __init__(self, job: BatchJob, voices: List[VoiceProfile], parent=None):
        super().__init__(parent)
        self._job = job
        self._voices = voices
        self.setWindowTitle("Edit Batch Job")
        self.setMinimumWidth(500)
        self._build_ui()
        self._load_from_job()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        grid = QGridLayout()
        grid.setSpacing(6)
        row = 0

        # Name
        grid.addWidget(QLabel("Name:"), row, 0)
        self._name = QLineEdit()
        self._name.setPlaceholderText("Job name (optional)")
        grid.addWidget(self._name, row, 1)
        row += 1

        # Prompt
        grid.addWidget(QLabel("Prompt:"), row, 0, alignment=Qt.Alignment.AlignTop)
        self._prompt = QLineEdit()
        self._prompt.setPlaceholderText("Prompt text (may include Higgs tokens)")
        grid.addWidget(self._prompt, row, 1)
        row += 1

        # Voice
        grid.addWidget(QLabel("Voice:"), row, 0)
        self._voice = QComboBox()
        self._voice.addItem("(No voice)", None)
        for v in self._voices:
            label = v.name
            if v.duration > 0:
                label += " ({0:.1f}s)".format(v.duration)
            self._voice.addItem(label, v.id)
        grid.addWidget(self._voice, row, 1)
        row += 1

        # Output filename
        grid.addWidget(QLabel("Output Filename:"), row, 0)
        self._output_filename = QLineEdit()
        self._output_filename.setPlaceholderText("auto (timestamp) or my_audio.wav")
        grid.addWidget(self._output_filename, row, 1)
        row += 1

        # Sampling parameters
        grid.addWidget(QLabel("Temperature:"), row, 0)
        self._temperature = QDoubleSpinBox()
        self._temperature.setRange(0.1, 2.0)
        self._temperature.setSingleStep(0.05)
        self._temperature.setDecimals(2)
        grid.addWidget(self._temperature, row, 1)
        row += 1

        grid.addWidget(QLabel("Top P:"), row, 0)
        self._top_p = QDoubleSpinBox()
        self._top_p.setRange(0.1, 1.0)
        self._top_p.setSingleStep(0.05)
        self._top_p.setDecimals(2)
        grid.addWidget(self._top_p, row, 1)
        row += 1

        grid.addWidget(QLabel("Top K:"), row, 0)
        self._top_k = QSpinBox()
        self._top_k.setRange(1, 500)
        self._top_k.setSingleStep(10)
        grid.addWidget(self._top_k, row, 1)
        row += 1

        grid.addWidget(QLabel("Max Tokens:"), row, 0)
        self._max_tokens = QSpinBox()
        self._max_tokens.setRange(128, 8192)
        self._max_tokens.setSingleStep(128)
        grid.addWidget(self._max_tokens, row, 1)
        row += 1

        grid.addWidget(QLabel("Seed:"), row, 0)
        self._seed = QLineEdit()
        self._seed.setPlaceholderText("empty = random, or integer for reproducible")
        self._seed.setValidator(None)  # accept empty
        grid.addWidget(self._seed, row, 1)
        row += 1

        grid.addWidget(QLabel("Append Silence (s):"), row, 0)
        self._silence = QDoubleSpinBox()
        self._silence.setRange(0.0, 5.0)
        self._silence.setSingleStep(0.1)
        self._silence.setDecimals(1)
        grid.addWidget(self._silence, row, 1)
        row += 1

        self._normalize = QCheckBox("Normalize Output (-18 LUFS)")
        grid.addWidget(self._normalize, row, 1)
        row += 1

        layout.addLayout(grid)

        # Button box
        bb = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

    def _load_from_job(self) -> None:
        j = self._job
        self._name.setText(j.name or "")
        self._prompt.setText(j.prompt or "")
        # Voice
        for i in range(self._voice.count()):
            if self._voice.itemData(i) == j.voice_id:
                self._voice.setCurrentIndex(i)
                break
        self._output_filename.setText(j.output_filename or "")
        p = j.parameters
        self._temperature.setValue(p.temperature)
        self._top_p.setValue(p.top_p)
        self._top_k.setValue(p.top_k)
        self._max_tokens.setValue(p.max_new_tokens)
        if p.seed is not None:
            self._seed.setText(str(p.seed))
        else:
            self._seed.setText("")
        self._silence.setValue(p.append_silence)
        self._normalize.setChecked(p.normalize_output)

    def apply_to_job(self) -> BatchJob:
        """Write the dialog's values back into the BatchJob and return it."""
        j = self._job
        j.name = self._name.text().strip()
        j.prompt = self._prompt.text()
        j.voice_id = self._voice.currentData()
        fname = self._output_filename.text().strip()
        j.output_filename = fname if fname else None
        seed_text = self._seed.text().strip()
        seed = int(seed_text) if seed_text else None
        j.parameters = GenerationParameters(
            temperature=float(self._temperature.value()),
            top_p=float(self._top_p.value()),
            top_k=int(self._top_k.value()),
            max_new_tokens=int(self._max_tokens.value()),
            seed=seed,
            append_silence=float(self._silence.value()),
            normalize_output=self._normalize.isChecked(),
            auto_play=False,  # never auto-play during batch
        )
        return j


# ---------------------------------------------------------------------------
# AnimatedHourglass — small painted widget for the "Generating" status pill
# ---------------------------------------------------------------------------
class AnimatedHourglass(QWidget):
    """Small QWidget that paints a spinning hourglass using QPainter.

    Used in the status pill of GENERATING jobs to give the user a clear
    visual signal that the engine is actively working. The animation is
    driven by an internal QTimer; call ``start()`` to begin spinning and
    ``stop()`` to halt. The widget is parented to its table cell, so when
    the cell widget is replaced (next _refresh_table call) Qt destroys
    the widget and its timer together — no manual cleanup is required.

    Color: ``Palette.WARNING`` (amber) — matches the mock's amber spinner
    but comes from the theme system, not a hardcoded value.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._advance)
        # 22x22 fits comfortably inside a 48px table row.
        self.setFixedSize(22, 22)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def start(self) -> None:
        """Begin the spin animation (idempotent)."""
        if not self._timer.isActive():
            self._timer.start(45)  # ~22 FPS — smooth and cheap.
        self.show()

    def stop(self) -> None:
        """Halt the spin animation and reset the angle."""
        self._timer.stop()
        self._angle = 0
        self.update()
        self.hide()

    def _advance(self) -> None:
        self._angle = (self._angle + 8) % 360
        self.update()

    def paintEvent(self, event):
        """Paint the hourglass glyph rotated by ``self._angle`` degrees.

        The shape is two horizontal caps plus an X for the glass walls,
        with two sand triangles (top-full, bottom-empty-or-filling) and
        a thin falling stream — same geometry as the standalone mock.
        """
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.translate(self.width() / 2.0, self.height() / 2.0)
        p.rotate(self._angle)

        color = QColor(Palette.WARNING)
        pen = QPen(color, 1.8)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        # Hourglass frame (top + bottom caps + X glass walls).
        p.drawLine(-6, -7, 6, -7)
        p.drawLine(-6, 7, 6, 7)
        p.drawLine(-6, -7, 6, 7)
        p.drawLine(6, -7, -6, 7)

        # Sand (top triangle + bottom triangle + falling stream).
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(color))
        p.drawPolygon([
            QPointF(-4.0, -5.0),
            QPointF(4.0, -5.0),
            QPointF(0.0, -1.0),
        ])
        p.drawPolygon([
            QPointF(-4.0, 5.0),
            QPointF(4.0, 5.0),
            QPointF(0.0, 1.0),
        ])
        p.drawRect(QRectF(-0.65, -1.0, 1.3, 2.0))
        p.end()


# ---------------------------------------------------------------------------
# Batch generation dialog
# ---------------------------------------------------------------------------
class _UiMarshaler(QObject):
    """Thread-safe UI marshaller using a Qt signal.

    QTimer.singleShot(0, fn) from a worker thread DOES NOT WORK because
    the worker thread has no Qt event loop.  A Qt signal, however, is
    automatically marshalled to the receiver's thread (the UI thread)
    when emitted from a different thread.

    Usage:
        marshaler = _UiMarshaler()
        marshaler.call.connect(fn)  # on UI thread
        marshaler.call.emit(fn)     # from any thread — fn runs on UI thread
    """
    call = Signal(object)  # carries a callable

    def __init__(self, parent=None):
        super().__init__(parent)
        self.call.connect(self._on_call)

    def _on_call(self, fn):
        fn()

    def marshal(self, fn):
        """Can be called from any thread.  fn will run on the UI thread."""
        self.call.emit(fn)


class BatchGenerationDialog(QDialog):
    """Non-modal-style dialog that drives a BatchManager.

    The dialog owns a BatchManager instance (passed in from MainWindow)
    and exposes a table of jobs with add/edit/remove/move/duplicate
    actions plus start/pause/stop controls and a live summary.
    """

    # Emitted when the user clicks "Concatenate". The MainWindow connects
    # this to its concatenation handler, which has access to the engine
    # and the waveform player. The argument is the list of COMPLETED
    # job output paths (absolute) in queue order.
    concatenate_requested = Signal(list)

    # Emitted when the user clicks the per-row "Play" button.
    # The argument is the output_path of the job to play (relative to APP_ROOT).
    play_requested = Signal(str)

    # Emitted when the user clicks the per-row "Stop" playback button.
    stop_playback_requested = Signal()

    # P3.27B: emitted when the user confirms regeneration of a single
    # part. MainWindow owns the versioned-filename allocation (it knows
    # the engine's outputs dir), so the dialog no longer resets the job
    # itself — for Generate Long parts the handler allocates a NEW
    # version (never overwriting the previous file) before resetting the
    # job and starting the batch. Manual jobs keep the legacy behaviour.
    regen_requested = Signal(int)

    # P3.28 §13: emitted when the user clicks "Combine Scene" (scene
    # mode only). MainWindow resolves the per-slot audio, allocates the
    # next Scene Combined version, concatenates, and appends the
    # lineage-tracked entry to Scene.combined_outputs.
    combine_scene_requested = Signal()

    # P3.28 §15/Rec 16: per-slot version selection. Args:
    # (slot_id, asset_id) — asset_id "" clears the selection (latest).
    use_version_requested = Signal(str, str)

    # P3.28 §15/Rec 16: explicit Scene output selection. Args:
    # (kind, entry_id) — kind "scene_combined"|"asset"; empty kind/id
    # clears the selection.
    select_output_requested = Signal(str, str)

    # P3.28 §11–§12: selective generation — args: the list of CHECKED
    # row indices. MainWindow allocates fresh versions for already-
    # covered checked slots, marks unchecked pending jobs SKIPPED, and
    # starts the SAME pipeline for exactly the checked rows.
    generate_selected_requested = Signal(list)

    # P3.28 §17: batch audio export (copy-only). Args: (scope,
    # checked_indices) — scope "selected"|"parts"|"combined"|"everything".
    export_audio_requested = Signal(str, list)

    def __init__(self, manager: BatchManager, voices: List[VoiceProfile],
                 parent=None, scene=None, project=None, app_root: str = "",
                 review_mode: bool = False, settings_manager=None):
        super().__init__(parent)
        self._manager = manager
        self._voices = voices
        # P3.28 scene context (None = manual Batch Queue window — all
        # P3.28 provenance UI is hidden and behaviour is unchanged).
        self._scene = scene
        self._project = project
        self._app_root = app_root or os.getcwd()
        self._review_mode = bool(review_mode) and scene is not None
        # P3.35: optional SHARED SettingsManager (MainWindow passes its
        # own instance so window geometry / column state land in the
        # app's settings namespace — never in the project file). When
        # omitted (legacy direct constructions) the app-root settings
        # folder is used, exactly as before.
        self._settings_manager = settings_manager
        # User check states for the selective-generation column — set
        # ONCE at open (defaults per P3.28 §11: not-generated slots
        # checked, already-generated slots unchecked) and preserved
        # across _refresh_table rebuilds.
        self._check_states: dict = {}
        self._init_check_defaults()
        # P3.35 §5: the two workflows must be visually distinguishable
        # IMMEDIATELY — scene mode names the Scene, manual mode is the
        # honest "Batch Queue" (never the identical old "Batch
        # Generation" title that made it look like a broken twin).
        if scene is not None:
            self.setWindowTitle("Batch Generation \u2014 {0}".format(
                scene.name or "Scene"))
        else:
            self.setWindowTitle("Batch Queue")
        # P3.18: default size bumped from 900x600 to 1100x680 to give the
        # new two-panel layout (table + QUEUE SUMMARY sidebar) comfortable
        # breathing room. The user's saved geometry (settings.json) still
        # takes precedence via _restore_geometry().
        self.resize(1100, 680)
        # P3.35 §22: debounced save on live resize (close/hide still save
        # unconditionally — the timer covers destroy-without-close paths
        # and gives "resize → saved" its literal reading).
        self._geo_save_timer = QTimer(self)
        self._geo_save_timer.setSingleShot(True)
        self._geo_save_timer.setInterval(600)
        self._geo_save_timer.timeout.connect(self._save_geometry)
        # P3.35 §11: mode-switch close flag — close_without_stopping_batch()
        # sets it so the single-live-instance hand-over NEVER stops a
        # running batch (the replacement dialog keeps showing progress).
        self._close_preserve_batch = False
        self._ui_state_saved = False

        # Restore saved window size from settings (if any).
        self._restore_geometry()

        # Wire the manager so all callbacks marshal into the UI thread.
        self._connect_manager()
        self._build_ui()
        self._refresh_table()
        self._update_buttons()
        # P3.28: initial fill of the scene-derived surfaces (coverage
        # header, GENERATE CHECKED label, combined outputs section).
        if self._scene is not None:
            self._update_coverage_header()
            self._update_start_button()
            self._refresh_combined_section()

    @property
    def is_scene_mode(self) -> bool:
        """P3.35 §3: mode identity for the single-live-instance policy."""
        return self._scene is not None

    @property
    def scene(self):
        """The Scene bound to this dialog (None in manual Batch Queue mode)."""
        return self._scene

    def _init_check_defaults(self) -> None:
        """P3.28 §11 default selection: ONLY not-generated slots checked.

        Regenerating costs minutes of GPU per part and existing audio is
        never invalid (§0 product rule), so pre-checking generated slots
        would invite accidental mass re-spend. The user can select
        already-generated slots explicitly (partial regeneration — §12).
        """
        if self._scene is None or not self._manager:
            return
        try:
            from engine.audio_provenance import is_slot_covered
            from engine.batch_manager import JobStatus
            for idx, job in enumerate(self._manager.jobs):
                slot_id = getattr(job, "slot_id", None)
                if slot_id and self._scene is not None:
                    covered = is_slot_covered(self._scene, slot_id)
                else:
                    covered = (job.status == JobStatus.COMPLETED)
                # not-generated → checked; already-generated → unchecked
                self._check_states[idx] = not covered
        except Exception:
            pass

    def refresh_scene_context(self) -> None:
        """P3.28: refresh every scene-derived surface (coverage header,
        per-row generated cells, combined outputs section, buttons).

        Called after batch completion, version/output selection, Scene
        Combine, and job completion (via _on_manager_changed).
        """
        if self._scene is None:
            return
        self._update_coverage_header()
        self._update_start_button()
        self._refresh_table()

    def _update_coverage_header(self) -> None:
        """P3.28 §5/Rec 12: the coverage header line above the table."""
        if self._scene is None or not hasattr(self, "_coverage_label"):
            return
        from engine.audio_provenance import (
            coverage_counts, scene_coverage_state, SCENE_STATE_LABELS,
        )
        covered, total = coverage_counts(self._scene)
        state = scene_coverage_state(self._scene)
        run_hint = ""
        for job in self._manager.jobs:
            run_hint = getattr(job, "generation_run", None) or ""
            if run_hint:
                break
        text = "{0}  —  coverage: {1} ({2}/{3})".format(
            self._scene.name or "Scene",
            SCENE_STATE_LABELS.get(state, state.upper()), covered, total)
        if run_hint:
            text += "  —  run {0}".format(run_hint)
        self._coverage_label.setText(text)

    def _update_start_button(self) -> None:
        """P3.28: the primary button's label reflects the checked set.

        Scene mode: "GENERATE CHECKED (N)" (selective generation — §11/§12).
        Legacy manual mode: unchanged "START BATCH".
        """
        if not hasattr(self, "_start_btn"):
            return
        if self._scene is None:
            self._start_btn.setText("START BATCH")
            return
        checked = sum(1 for v in self._check_states.values() if v)
        self._start_btn.setText(
            "GENERATE CHECKED ({0})".format(checked) if checked
            else "GENERATE CHECKED")

    def _settings(self):
        """P3.35: the ONE settings channel for this dialog.

        Prefers the SHARED SettingsManager injected by MainWindow (so
        geometry / column state follow the app's settings directory,
        e.g. a test's isolated app root); falls back to the app-root
        settings folder exactly as P3.25 established.
        """
        if self._settings_manager is not None:
            return self._settings_manager
        try:
            from engine.settings_manager import SettingsManager
            _root = os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))))
            return SettingsManager.instance(os.path.join(_root, "settings"))
        except Exception:
            return None

    def _restore_geometry(self) -> None:
        """Restore the saved dialog size from settings.json.

        P3.25 (audit SS-H04): reads via the SHARED SettingsManager — no
        raw independent file reads. P3.35 §22: both modes share ONE
        geometry key (``window/batch_dialog``) ON PURPOSE — the two
        workflows use the same two-panel architecture, and a size the
        user chose for one is a fine default for the other.
        """
        sm = self._settings()
        if sm is None:
            return
        try:
            geo = sm.get("window", "batch_dialog", {}) or {}
            if geo:
                w = geo.get("width", 900)
                h = geo.get("height", 600)
                self.resize(int(w), int(h))
        except Exception:
            pass

    def _save_geometry(self) -> None:
        """Save the current dialog size to settings.json.

        P3.25 (audit SS-H04): the dialog previously performed a RAW
        read-modify-write of settings.json — an independent fourth writer
        that bypassed the SettingsManager merge/atomicity discipline. It
        now writes through the SHARED SettingsManager (atomic,
        merge-on-write, coherent with every other component).
        """
        sm = self._settings()
        if sm is None:
            return
        try:
            sm.set("window", "batch_dialog", {
                "width": self.width(),
                "height": self.height(),
            })
        except Exception:
            pass

    def resizeEvent(self, event) -> None:
        """P3.35 §22: persist the user's resize (debounced) — the saved
        geometry survives close/reopen/restart via SettingsManager."""
        super().resizeEvent(event)
        if self._geo_save_timer is not None:
            self._geo_save_timer.start()

    # ------------------------------------------------------------------
    # P3.35 §23-27: per-mode column configuration persistence
    # ------------------------------------------------------------------
    def _column_state_key(self) -> str:
        """Column state is persisted PER MODE (different table schemas:
        scene mode = 7 columns, manual queue = 5). One shared blob would
        produce invalid/missing mappings for the other mode."""
        return ("batch_generation_scene_columns" if self._scene_mode
                else "batch_queue_columns")

    def _save_column_state(self) -> None:
        """Persist widths + order + visibility via the native Qt header
        state (QHeaderView.saveState) — plus a title-keyed width map used
        as the schema-evolution fallback (a stored state whose column
        count no longer matches is never applied wholesale)."""
        sm = self._settings()
        if sm is None:
            return
        try:
            header = self._table.horizontalHeader()
            titles = [self._table.horizontalHeaderItem(i).text()
                      for i in range(self._table.columnCount())]
            widths = {}
            for i, title in enumerate(titles):
                if title:
                    widths[title] = int(header.sectionSize(i))
            import base64
            blob = base64.b64encode(bytes(header.saveState())).decode("ascii")
            sm.set("window", self._column_state_key(), {
                "version": 1,
                "columns": titles,
                "state": blob,
                "widths": widths,
            })
        except Exception:
            pass

    def _restore_column_state(self) -> None:
        """Restore the saved column configuration for THIS mode.

        Migration policy (P3.35 §27): the native state blob is applied
        ONLY when the stored schema (column titles) matches the current
        table exactly. On a schema mismatch (obsolete or new columns)
        only the title-keyed WIDTHS are re-applied — obsolete titles are
        ignored safely, new columns keep their default position /
        visibility / width, and a corrupt blob can never crash the open.
        """
        sm = self._settings()
        if sm is None:
            return
        try:
            data = sm.get("window", self._column_state_key(), None)
        except Exception:
            return
        if not isinstance(data, dict):
            return
        header = self._table.horizontalHeader()
        titles = [self._table.horizontalHeaderItem(i).text()
                  for i in range(self._table.columnCount())]
        try:
            saved_titles = [str(t) for t in (data.get("columns") or [])]
            blob = str(data.get("state") or "")
            if blob and saved_titles == titles:
                from PySide6.QtCore import QByteArray
                raw = QByteArray.fromBase64(blob.encode("ascii"))
                if not raw.isEmpty() and header.restoreState(raw):
                    return  # exact-schema restore (widths+order+visibility)
            # Schema-evolution fallback: compatible widths by title only.
            widths = data.get("widths")
            if isinstance(widths, dict):
                for i, title in enumerate(titles):
                    if title and title in widths:
                        try:
                            header.resizeSection(i, int(widths[title]))
                        except (TypeError, ValueError):
                            continue
        except Exception:
            pass

    def _on_header_context_menu(self, pos) -> None:
        """P3.35 §26: right-click header menu — checkable show/hide per
        column (the native Qt table idiom, not a new management UX)."""
        from PySide6.QtWidgets import QMenu
        header = self._table.horizontalHeader()
        menu = QMenu(self)
        menu.setWindowTitle("Columns")
        for col in range(self._table.columnCount()):
            item = self._table.horizontalHeaderItem(col)
            label = (item.text() if item and item.text()
                     else "Column {0}".format(col + 1))
            act = menu.addAction(label)
            act.setCheckable(True)
            act.setChecked(not header.isSectionHidden(col))
            act.toggled.connect(
                lambda visible, _c=col: header.setSectionHidden(_c, not visible))
        menu.exec(header.viewport().mapToGlobal(pos))

    def hideEvent(self, event) -> None:
        """P3.35 §22/§28: persist user customizations as soon as the
        dialog leaves the screen (covers paths that bypass closeEvent)."""
        if not self._ui_state_saved:
            self._save_geometry()
            self._save_column_state()
        super().hideEvent(event)

    # ------------------------------------------------------------------
    # Manager wiring
    # ------------------------------------------------------------------
    def _connect_manager(self) -> None:
        """Configure the BatchManager to marshal callbacks to the UI thread
        via a Qt signal (thread-safe, unlike QTimer.singleShot).

        P3.35 §4 (callback safety): the manager's slots are SINGLE-slot,
        so this dialog remembers the callbacks it replaces and restores
        them on close (see ``_release_manager``). The single-live-instance
        policy means the previous owner is normally already released, but
        restoring (instead of clearing) keeps the hand-over safe for any
        future caller that installs its own callbacks.
        """
        self._marshaler = _UiMarshaler(self)
        self._on_changed_cb = lambda _m: self._on_manager_changed()
        # Store the bound method ONCE: attribute access creates a NEW
        # bound-method object each time, so ``is`` comparisons against
        # ``self._marshaler.marshal`` would never match (release must
        # compare with == / the stored reference).
        self._marshal_cb = self._marshaler.marshal
        self._prev_on_changed = getattr(self._manager, "_on_changed", None)
        self._prev_marshal = getattr(self._manager, "marshal_to_ui", None)
        self._manager.marshal_to_ui = self._marshal_cb
        self._manager.set_on_changed(self._on_changed_cb)
        # Death safety: if this dialog is destroyed WITHOUT a closeEvent
        # (e.g. parent teardown), never leave the manager calling a dead
        # dialog. The closure captures only the manager + our callbacks —
        # it does not keep the dialog alive.
        _mgr, _on_cb = self._manager, self._on_changed_cb

        def _on_destroyed(*_args):
            try:
                if _mgr._on_changed is _on_cb:
                    _mgr.set_on_changed(None)
                if getattr(_mgr, "marshal_to_ui", None) == _marshal_cb:
                    _mgr.marshal_to_ui = None
            except Exception:
                pass
        self.destroyed.connect(_on_destroyed)

    def _release_manager(self) -> None:
        """P3.35 §4: give the shared manager's callbacks back.

        Called from closeEvent. Only restores when the manager still
        points at THIS dialog's callbacks — a newer owner (single-slot
        takeover) is never clobbered, so there is no callback theft in
        either direction.
        """
        try:
            if (getattr(self._manager, "_on_changed", None)
                    is self._on_changed_cb):
                self._manager.set_on_changed(self._prev_on_changed)
            if (getattr(self._manager, "marshal_to_ui", None)
                    == self._marshal_cb):
                self._manager.marshal_to_ui = self._prev_marshal
        except Exception:
            pass

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        """Build the two-panel layout (P3.18 visual redesign).

        Left panel  (~70%): toolbar rows + job table (7 columns in scene
                            mode, 5 in the manual Batch Queue).
        Right panel (~30%): "QUEUE SUMMARY" sidebar with progress bar,
                            stat lines, Merge Completed Parts (manual
                            mode) / Combine Scene + Export Audio (scene
                            mode), START/GENERATE, Pause/Stop.

        All colors come from :class:`ui.theme.Palette` — no mock hex values.
        All icons come from :class:`ui.icon_registry.IconRegistry`.
        """
        # Top-level horizontal split: left = table, right = summary sidebar.
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        # ---------------------------------------------------------------
        # LEFT PANEL — toolbar rows + coverage header + 7-column job table
        #        + Scene combined outputs section (P3.28)
        # ---------------------------------------------------------------
        left = QVBoxLayout()
        left.setSpacing(8)

        # P3.28 §5/Rec 12: coverage header (scene mode only) —
        # "SCENE 03 — coverage: PARTIAL (3/4) — run {scene8}-r004" plus
        # All/None quick-select for the per-row checkboxes.
        if self._scene is not None:
            header_row = QHBoxLayout()
            self._coverage_label = QLabel("")
            self._coverage_label.setStyleSheet(
                "color: {accent}; font-size: 12px; font-weight: 700;"
                .format(accent=Palette.ACCENT))
            header_row.addWidget(self._coverage_label, 1)
            self._sel_all_btn = QPushButton("All")
            # P3.35 §29: metrics-aware height — the old fixed 24px clipped
            # the label bottom (global button QSS pads 7px + 1px border).
            _fit_button_height(self._sel_all_btn)
            self._sel_all_btn.setToolTip(
                "Check every part (generate everything)")
            self._sel_all_btn.clicked.connect(self._on_select_all)
            header_row.addWidget(self._sel_all_btn)
            self._sel_none_btn = QPushButton("None")
            # P3.35 §29: the reported clipped "None" button — same root
            # cause as "All" (shared geometry), same metrics-aware fix.
            _fit_button_height(self._sel_none_btn)
            self._sel_none_btn.setToolTip("Uncheck every part")
            self._sel_none_btn.clicked.connect(self._on_select_none)
            header_row.addWidget(self._sel_none_btn)
            left.addLayout(header_row)

        # Toolbar row 1: Add / Edit / Duplicate / Remove ... Up / Down
        job_row = QHBoxLayout()
        job_row.setSpacing(4)
        self._add_btn = QPushButton("+ Add")
        self._add_btn.clicked.connect(self._on_add)
        job_row.addWidget(self._add_btn)

        self._edit_btn = QPushButton("Edit...")
        self._edit_btn.clicked.connect(self._on_edit)
        job_row.addWidget(self._edit_btn)

        self._dup_btn = QPushButton("Duplicate")
        self._dup_btn.clicked.connect(self._on_duplicate)
        job_row.addWidget(self._dup_btn)

        self._remove_btn = QPushButton("- Remove")
        self._remove_btn.clicked.connect(self._on_remove)
        job_row.addWidget(self._remove_btn)

        job_row.addStretch()

        self._up_btn = QPushButton("\u2191 Up")
        self._up_btn.clicked.connect(self._on_move_up)
        job_row.addWidget(self._up_btn)

        self._down_btn = QPushButton("\u2193 Down")
        self._down_btn.clicked.connect(self._on_move_down)
        job_row.addWidget(self._down_btn)

        left.addLayout(job_row)

        # Toolbar row 2: Save / Load / Clear
        file_row = QHBoxLayout()
        file_row.setSpacing(4)
        self._save_btn = QPushButton("Save Queue...")
        self._save_btn.clicked.connect(self._on_save_queue)
        file_row.addWidget(self._save_btn)

        self._load_btn = QPushButton("Load Queue...")
        self._load_btn.clicked.connect(self._on_load_queue)
        file_row.addWidget(self._load_btn)

        self._clear_btn = QPushButton("Clear")
        self._clear_btn.clicked.connect(self._on_clear)
        file_row.addWidget(self._clear_btn)

        file_row.addStretch()
        left.addLayout(file_row)

        # 7 columns (P3.28): #, [✓], File Name, Generated, Status,
        # Duration, Actions — SCENE MODE. In the LEGACY manual window the
        # original P3.18 five-column layout is kept EXACTLY (#, File Name,
        # Status, Duration, Actions at the original indices) so existing
        # behaviour and tests are untouched; the checkbox and Generated
        # columns exist only in scene mode.
        self._scene_mode = self._scene is not None
        if self._scene_mode:
            self._col_num, self._col_check, self._col_name = 0, 1, 2
            self._col_gen, self._col_status = 3, 4
            self._col_dur, self._col_act = 5, 6
            self._table = QTableWidget(0, 7)
            self._table.setHorizontalHeaderLabels(
                ["#", "", "File Name", "Generated", "Status", "Duration",
                 "Actions"])
        else:
            self._col_num, self._col_name = 0, 1
            self._col_status, self._col_dur, self._col_act = 2, 3, 4
            self._table = QTableWidget(0, 5)
            self._table.setHorizontalHeaderLabels(
                ["#", "File Name", "Status", "Duration", "Actions"])
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setShowGrid(False)
        # P3.21: Rounded corners on the table container to match the
        # modern card aesthetic. The QTableWidget itself doesn't support
        # border-radius, but we can style the viewport + header.
        #
        # P3.40 (row rendering audit) — TWO consolidation rules:
        #
        # (1) ONE selection treatment. The APP-level stylesheet
        #     (ui.theme generate_qss) styles selected table cells with
        #     ``border-left: 2px solid {accent}`` (Modern Dark accent
        #     #d0bcff). Because a widget stylesheet only overrides the
        #     PROPERTIES it explicitly declares, that rule used to cascade
        #     into this table and paint a bright 2px purple vertical line
        #     at EVERY cell boundary of the selected row (one per column,
        #     full row height — runtime-verified). This stylesheet now
        #     explicitly resets every per-cell border (including
        #     border-left) on ``::item`` AND on ``::item:selected`` so the
        #     ONLY selection treatment is the single translucent purple
        #     row fill below. ``::item:focus`` (declared BEFORE
        #     ``::item:selected`` so the fill still wins on the current
        #     cell) suppresses any native focus border around the current
        #     cell — no second indicator.
        # (2) Cell-widget geometry. ``::item`` padding insets every
        #     setCellWidget() into the item's CONTENT rect. With the old
        #     ``padding: 6px`` + 1px border-bottom, the action widget got
        #     48 - 6 - 6 - 1 = 35px of height for 4+36+4 = 44px of fixed
        #     buttons — the buttons overflowed 5px past the widget bottom
        #     and were clipped (icons cut, row looked bottom-heavy).
        #     Vertical padding is now 0: content height = 48 - 1 = 47px,
        #     which fits the 44px button band with symmetric clearance.
        #     Delegate-painted text (#/Name/Duration) is unaffected — it
        #     is vertically centred by item alignment, not by padding.
        self._table.setStyleSheet("""
            QTableWidget {
                background-color: rgba(36, 36, 36, 150);
                border: 1px solid #333333;
                border-radius: 8px;
                outline: none;
                gridline-color: transparent;
                font-size: 13px;
            }
            QTableWidget::item {
                border: none;
                border-bottom: 1px solid #333333;
                padding: 0px 6px;
            }
            QTableWidget::item:focus {
                border: none;
                outline: none;
            }
            QTableWidget::item:selected {
                background: rgba(139, 92, 246, 35);
                color: #F5F5F5;
                border: none;
                border-bottom: 1px solid #333333;
            }
            QHeaderView::section {
                background: rgba(32, 31, 31, 235);
                color: #A0A0A0;
                border: none;
                border-bottom: 1px solid #333333;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 8px;
                font-size: 11px;
                font-weight: 700;
            }
        """)
        header = self._table.horizontalHeader()
        header.setMinimumSectionSize(40)
        header.setStretchLastSection(False)
        # Column resize modes — Fixed keeps the pill column tidy; the Name
        # column stretches to fill whatever horizontal space the table gets.
        # P3.35 §23-26: the user-resizable columns are Interactive (Fixed
        # mode made column RESIZING impossible — the "lost" column
        # configuration), sections are movable (drag to reorder) and the
        # header has a checkable show/hide context menu. The whole state
        # (widths + order + visibility) persists per mode via
        # QHeaderView.saveState/restoreState.
        if self._scene_mode:
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)      # #
            header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)      # check
            header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)    # Name / Segment
            header.setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)  # Generated
            header.setSectionResizeMode(4, QHeaderView.ResizeMode.Interactive)  # Status (pills)
            header.setSectionResizeMode(5, QHeaderView.ResizeMode.Interactive)  # Duration
            header.setSectionResizeMode(6, QHeaderView.ResizeMode.Interactive)  # Actions
            header.resizeSection(0, 40)    # #
            header.resizeSection(1, 36)    # checkbox
            header.resizeSection(3, 190)   # Generated + versions ▾
            header.resizeSection(4, 130)   # Status (icon + pill)
            header.resizeSection(5, 80)    # Duration
            header.resizeSection(6, 140)   # Actions (3 × 36px + margins + spacing)
            # P3.40: derived MINIMUM width for the Actions column =
            #   3 buttons × 36 + 2 spacing × 4 + 2 margins × 4
            #   + 2 × 6px horizontal ::item padding = 124px.
            # The 140px default keeps the full button row comfortably
            # visible; shrinking below 124 clips buttons horizontally.
        else:
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)      # #
            header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)    # Name / Segment
            header.setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)  # Status (pills)
            header.setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)  # Duration
            header.setSectionResizeMode(4, QHeaderView.ResizeMode.Interactive)  # Actions
            header.resizeSection(0, 40)    # #
            header.resizeSection(2, 130)   # Status (icon + pill)
            header.resizeSection(3, 80)    # Duration
            header.resizeSection(4, 140)   # Actions (3 × 36px + 4px margins + 4px spacing)
            # P3.40: see the scene-mode note above — 124px derived minimum
            # (3×36 buttons + 8 spacing + 8 margins + 12 ::item padding).
        # P3.35 §23-27: restore the user's saved column configuration for
        # THIS mode (widths + order + visibility), then enable the native
        # reorder + hide/show interactions. Everything persists on close.
        self._restore_column_state()
        header.setSectionsMovable(True)
        header.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu)
        header.customContextMenuRequested.connect(
            self._on_header_context_menu)
        # Row height 48px accommodates the pill widget + the action buttons.
        # P3.40: the ``::item`` box (0 vertical padding + 1px border-bottom)
        # leaves 47px of content height per cell — the 4+36+4 = 44px action
        # button band fits fully INSIDE the row (no bottom clipping).
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(48)
        self._table.verticalHeader().setMinimumSectionSize(48)
        left.addWidget(self._table, 1)

        # ---------------------------------------------------------------
        # P3.28 §13: SCENE COMBINED OUTPUTS section (scene mode only) —
        # versioned, lineage-tracked combined outputs with STALE badges
        # and "Use as Scene output" selection. One row per COMBINED
        # OUTPUT (never per version asset — Rec 22: no widget per file).
        # ---------------------------------------------------------------
        if self._scene is not None:
            combined_group = QFrame()
            combined_group.setObjectName("SceneCombinedGroup")
            combined_group.setStyleSheet(
                "QFrame#SceneCombinedGroup {{"
                "  background-color: {bg_surface};"
                "  border: 1px solid {border};"
                "  border-radius: 8px;"
                "}}".format(bg_surface=Palette.BG_SURFACE,
                            border=Palette.BORDER))
            cg_layout = QVBoxLayout(combined_group)
            cg_layout.setContentsMargins(10, 8, 10, 8)
            cg_layout.setSpacing(4)
            cg_header = QLabel("SCENE COMBINED OUTPUTS")
            cg_header.setStyleSheet(
                "color: {muted}; font-size: 10px; font-weight: 700;"
                " letter-spacing: 1px;".format(muted=Palette.TEXT_SECONDARY))
            cg_layout.addWidget(cg_header)
            self._resolved_output_label = QLabel("")
            self._resolved_output_label.setStyleSheet(
                "color: {text}; font-size: 11px;".format(
                    text=Palette.TEXT_PRIMARY))
            self._resolved_output_label.setWordWrap(True)
            cg_layout.addWidget(self._resolved_output_label)
            self._combined_rows_layout = QVBoxLayout()
            self._combined_rows_layout.setSpacing(2)
            cg_layout.addLayout(self._combined_rows_layout)
            self._combined_group = combined_group
            left.addWidget(combined_group)

        layout.addLayout(left, 7)  # ~70% of horizontal space

        # ---------------------------------------------------------------
        # RIGHT PANEL — "QUEUE SUMMARY" sidebar
        # ---------------------------------------------------------------
        side = QFrame()
        side.setObjectName("BatchQueueSidePanel")
        side.setMinimumWidth(280)
        side.setMaximumWidth(360)
        side.setStyleSheet(
            "QFrame#BatchQueueSidePanel {{"
            "  background-color: {bg_surface};"
            "  border: 1px solid {border};"
            "  border-radius: 8px;"
            "}}".format(bg_surface=Palette.BG_SURFACE, border=Palette.BORDER))
        sl = QVBoxLayout(side)
        sl.setContentsMargins(16, 16, 16, 16)
        sl.setSpacing(12)

        # --- QUEUE SUMMARY section header ---
        section_label = QLabel("QUEUE SUMMARY")
        section_label.setStyleSheet(
            "QLabel {{"
            "  color: {muted};"
            "  font-size: 11px;"
            "  font-weight: 700;"
            "  letter-spacing: 1px;"
            "}}".format(muted=Palette.TEXT_SECONDARY))
        sl.addWidget(section_label)

        # --- Summary card: progress text + progress bar + 4 stat lines ---
        self._summary_card = QFrame()
        self._summary_card.setObjectName("BatchSummaryCard")
        self._summary_card.setStyleSheet(
            "QFrame#BatchSummaryCard {{"
            "  background-color: {bg_raised};"
            "  border: 1px solid {border};"
            "  border-radius: 6px;"
            "}}".format(bg_raised=Palette.BG_RAISED, border=Palette.BORDER))
        sc = QVBoxLayout(self._summary_card)
        sc.setContentsMargins(12, 12, 12, 12)
        sc.setSpacing(8)

        # Progress headline ("Progress    1/5 completed")
        self._progress_text = QLabel("Idle")
        self._progress_text.setStyleSheet(
            "color: {accent};"
            " font-family: 'JetBrains Mono','Consolas','Courier New',monospace;"
            " font-size: 12px;".format(accent=Palette.ACCENT))
        sc.addWidget(self._progress_text)

        # Thin progress bar — accent-colored chunk on a muted groove.
        self._progress = QProgressBar()
        self._progress.setTextVisible(False)
        self._progress.setFixedHeight(6)
        self._progress.setRange(0, 100)
        self._progress.setValue(0)
        self._progress.setStyleSheet(
            "QProgressBar {{"
            "  background-color: {bg_surface};"
            "  border: none;"
            "  border-radius: 3px;"
            "}}"
            "QProgressBar::chunk {{"
            "  background-color: {accent};"
            "  border-radius: 3px;"
            "}}".format(bg_surface=Palette.BG_SURFACE, accent=Palette.ACCENT))
        sc.addWidget(self._progress)

        # Stat lines (mono font, muted color, label + value).
        self._audio_label = self._make_summary_line("Generated Audio")
        self._rtf_label    = self._make_summary_line("Real Time Factor")
        self._wall_label   = self._make_summary_line("Wall Time")
        self._state_label  = self._make_summary_line("State")
        for w in (self._audio_label, self._rtf_label,
                  self._wall_label, self._state_label):
            sc.addWidget(w)

        sl.addWidget(self._summary_card)

        sl.addStretch(1)

        # --- Combine Scene button (P3.28 §13; scene mode only) ---
        # Combines the RESOLVED audio of every expected slot (selected
        # version per slot, else latest) into a VERSIONED, lineage-tracked
        # Scene Combined output: {Proj}_{Scene}_Combined_v01_{scene8}.wav.
        # Older combined outputs remain; nothing is rebuilt automatically.
        if self._scene is not None:
            self._combine_btn = QPushButton("Combine Scene")
            self._combine_btn.setToolTip(
                "Combine the generated slot outputs of this Scene into a\n"
                "VERSIONED combined WAV (e.g. Combined_v01) with full\n"
                "per-slot lineage. Older combined outputs are kept.\n"
                "\n"
                "Project Assembly consumes the Scene's resolved output\n"
                "(latest non-stale combined output by default).")
            self._combine_btn.clicked.connect(
                self.combine_scene_requested.emit)
            self._combine_btn.setStyleSheet(self._tool_button_style())
            sl.addWidget(self._combine_btn)

        # --- Merge Completed Parts button (manual Batch Queue only) ---
        # P3.35 §9: Concatenate is NOT a Scene-level operation — in scene
        # mode the equivalent is the versioned, lineage-tracked "Combine
        # Scene" above, so the manual merge utility lives ONLY in the
        # manual queue (previously labelled "Concatenate"; renamed per the
        # accepted COMBINE_VS_CONCATENATE design to state exactly what it
        # does and what it does NOT touch).
        if self._scene is None:
            self._concat_btn = QPushButton("Merge Completed Parts")
            self._concat_btn.setToolTip(
                "Merge the completed jobs in this queue in queue order into "
                "one audio file.\nThis output is not linked to a Scene and "
                "does not affect Project Assembly.")
            self._concat_btn.clicked.connect(self._on_concatenate)
            self._concat_btn.setStyleSheet(self._tool_button_style())
            sl.addWidget(self._concat_btn)

        # --- Export Audio button (P3.28 §17; scene mode only) ---
        # Copy-only export of the provenance-named files (never a second
        # naming system): scope menu + destination picker in MainWindow.
        if self._scene is not None:
            self._export_btn = QPushButton("Export Audio...")
            self._export_btn.setToolTip(
                "Copy generated audio files to a folder you choose.\n"
                "\n"
                "Scopes: selected rows / all generated parts / Scene\n"
                "combined outputs / everything in this batch.\n"
                "Files keep their provenance filenames; collisions are\n"
                "never overwritten silently.")
            self._export_btn.clicked.connect(self._on_export_audio)
            self._export_btn.setStyleSheet(self._tool_button_style())
            sl.addWidget(self._export_btn)

        # --- START BATCH / GENERATE CHECKED button (primary CTA) ---
        # Mock used an orange gradient; this app uses Palette.ACCENT (the
        # theme's primary CTA color) per the "no hardcoded mock colors"
        # constraint. The gradient (ACCENT -> ACCENT_PRESSED) gives the
        # same visual emphasis as the mock's orange gradient.
        # P3.28: in scene mode this button becomes GENERATE CHECKED —
        # selective generation of exactly the checked rows (§11/§12).
        self._start_btn = QPushButton("START BATCH")
        if self._scene is not None:
            self._start_btn.setText("GENERATE CHECKED")
        self._start_btn.clicked.connect(self._on_start)
        self._start_btn.setStyleSheet(
            "QPushButton {{"
            "  background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            "    stop:0 {accent}, stop:1 {accent_pressed});"
            "  color: {accent_text};"
            "  border: none;"
            "  border-radius: 5px;"
            "  padding: 10px 14px;"
            "  font-size: 13px;"
            "  font-weight: 700;"
            "  letter-spacing: 0.5px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent_hover};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                accent=Palette.ACCENT,
                accent_hover=Palette.ACCENT_HOVER,
                accent_pressed=Palette.ACCENT_PRESSED,
                accent_text=Palette.ACCENT_TEXT,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED,
                border=Palette.BORDER))
        sl.addWidget(self._start_btn)

        # --- Pause + Stop side by side ---
        run_row = QHBoxLayout()
        run_row.setSpacing(6)
        self._pause_btn = QPushButton("Pause")
        self._pause_btn.clicked.connect(self._on_pause)
        self._pause_btn.setEnabled(False)
        self._pause_btn.setStyleSheet(self._tool_button_style())
        run_row.addWidget(self._pause_btn)

        self._stop_btn = QPushButton("Stop")
        self._stop_btn.clicked.connect(self._on_stop)
        self._stop_btn.setEnabled(False)
        self._stop_btn.setStyleSheet(self._tool_button_style(danger=True))
        run_row.addWidget(self._stop_btn)
        sl.addLayout(run_row)

        layout.addWidget(side, 3)  # ~30% of horizontal space

    # ------------------------------------------------------------------
    # Style helpers (P3.18 — extracted for reuse across _build_ui)
    # ------------------------------------------------------------------
    @staticmethod
    def _make_summary_line(label: str) -> QLabel:
        """Create a mono-font stat-line label.

        The text format is ``"<label>    <value>"`` (filled in by
        :meth:`_update_summary`). The muted color + JetBrains Mono font
        matches the mock's summaryCard lines.
        """
        lbl = QLabel(label)
        lbl.setStyleSheet(
            "color: {muted};"
            " font-family: 'JetBrains Mono','Consolas','Courier New',monospace;"
            " font-size: 11px;".format(muted=Palette.TEXT_SECONDARY))
        return lbl

    @staticmethod
    def _tool_button_style(danger: bool = False) -> str:
        """Standard toolbutton QSS for the sidebar buttons.

        ``danger=True`` tints the text + hover border with Palette.ERROR
        (used for the Stop button, matching the mock's red Stop).
        """
        color = Palette.ERROR if danger else Palette.TEXT_PRIMARY
        hover = Palette.ERROR if danger else Palette.ACCENT
        return (
            "QPushButton {{"
            "  background-color: {bg_raised};"
            "  color: {color};"
            "  border: 1px solid {border};"
            "  border-radius: 5px;"
            "  padding: 7px 12px;"
            "  font-size: 12px;"
            "}}"
            "QPushButton:hover {{"
            "  border-color: {hover};"
            "  background-color: {bg_surface_alt};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                bg_raised=Palette.BG_RAISED,
                bg_surface=Palette.BG_SURFACE,
                bg_surface_alt=Palette.BG_SURFACE_ALT,
                color=color,
                border=Palette.BORDER,
                hover=hover,
                text_disabled=Palette.TEXT_DISABLED))

    @staticmethod
    def _tint_bg(color_hex: str) -> str:
        """Blend a status color toward Palette.BG_BASE for a soft pill bg.

        The result is a dark tinted background that lets the colored pill
        text pop without using a hardcoded hex value (the mock used
        #10251E for green, #2A2112 for amber, etc. — we derive similar
        values from the active theme palette).
        """
        try:
            c = QColor(color_hex)
            bg = QColor(Palette.BG_BASE)
            # 18% color + 82% bg — dark enough to read as a "tint", bright
            # enough to distinguish from the surrounding BG_SURFACE row.
            r = int(c.red()   * 0.18 + bg.red()   * 0.82)
            g = int(c.green() * 0.18 + bg.green() * 0.82)
            b = int(c.blue()  * 0.18 + bg.blue()  * 0.82)
            return QColor(r, g, b).name()
        except Exception:
            return Palette.BG_RAISED

    @staticmethod
    def _pill_style(color: str) -> str:
        """QSS for a colored status pill (rounded bg + colored text)."""
        bg = BatchGenerationDialog._tint_bg(color)
        return (
            "QLabel {{"
            "  color: {color};"
            "  background-color: {bg};"
            "  border-radius: 10px;"
            "  padding: 3px 8px;"
            "  font-size: 11px;"
            "  font-weight: 700;"
            "}}".format(color=color, bg=bg))

    # ------------------------------------------------------------------
    # Refresh helpers
    # ------------------------------------------------------------------
    def _on_manager_changed(self) -> None:
        self._refresh_table()
        self._update_buttons()
        self._update_summary()
        # P3.28: scene-derived surfaces (coverage header, generated
        # cells, combined outputs) follow every queue change.
        if self._scene is not None:
            self._update_coverage_header()
            self._update_start_button()
            self._refresh_combined_section()

    def _refresh_table(self) -> None:
        """Rebuild the table from the manager's current job list.

        P3.18 visual redesign: pill-based Status column. P3.28: two new
        scene-mode columns — the per-row selection checkbox (column 1,
        §11/§12) and the DERIVED generated state with the lazy version
        popover (column 3, §4/Rec 22: "✓ Generated · N versions ▾" —
        one row per slot, NEVER a widget per version).
        """
        jobs = self._manager.jobs
        self._table.setRowCount(len(jobs))
        running = self._manager.is_running
        for i, job in enumerate(jobs):
            # Row height 48px accommodates the pill widget + action buttons
            # (P3.40: 47px usable content after the 1px ::item border-bottom;
            # the 44px action-button band fits fully — no clipping).
            self._table.setRowHeight(i, 48)

            # Column 0 — "#" (zero-padded like the mock: 01, 02, ...)
            num_item = QTableWidgetItem("{0:02d}".format(i + 1))
            num_item.setTextAlignment(Qt.Alignment.AlignCenter)
            num_item.setForeground(QColor(Palette.TEXT_SECONDARY))
            self._table.setItem(i, self._col_num, num_item)

            # "[✓]" selection checkbox (scene mode only).
            # Preserved across rebuilds via _check_states (user choices
            # are never reset by a refresh).
            if self._scene_mode:
                self._table.setCellWidget(
                    i, self._col_check, self._build_check_widget(i, job,
                                                                  running))

            # "Name / Segment" — show the output filename
            # (the actual generated file name), falling back to job.name
            # or truncated prompt if no filename is available yet.
            if job.output_path:
                display_name = os.path.basename(job.output_path)
            elif job.output_filename:
                display_name = job.output_filename
            else:
                display_name = job.name or job.prompt[:40]
            name_item = QTableWidgetItem(display_name)
            if job.status == JobStatus.SKIPPED:
                # De-emphasize skipped rows at a glance.
                name_item.setForeground(QColor(Palette.TEXT_DISABLED))
            self._table.setItem(i, self._col_name, name_item)

            # "Generated" (derived state + versions ▾) — scene mode only.
            if self._scene_mode:
                self._table.setCellWidget(
                    i, self._col_gen, self._build_generated_widget(job))

            # "Status" (colored pill widget with icon).
            self._table.setCellWidget(
                i, self._col_status, self._build_status_widget(job))

            # Column 5 — "Duration" (output audio length, right-aligned).
            # P3.27B: an output-guard anomaly (e.g. a runaway generation
            # with a long silent tail) appends a visible ⚠ marker — the
            # audio is NEVER discarded; the user can keep, inspect (Play)
            # or regenerate the part (task §17).
            anomaly = getattr(job, "anomaly", None)
            if job.output_duration > 0:
                dur_text = "{0:.2f}s".format(job.output_duration)
                if anomaly:
                    dur_text += " \u26a0"   # ⚠ warning marker
            else:
                dur_text = "\u2014"  # em dash for "no duration yet"
            dur_item = QTableWidgetItem(dur_text)
            dur_item.setTextAlignment(
                Qt.Alignment.AlignRight | Qt.Alignment.AlignVCenter)
            if anomaly:
                dur_item.setForeground(QColor(Palette.WARNING))
                dur_item.setToolTip(self._anomaly_tooltip(job, anomaly))
            else:
                dur_item.setForeground(QColor(Palette.TEXT_SECONDARY))
            self._table.setItem(i, self._col_dur, dur_item)

            # "Actions" (Play + Stop + Regen per-row buttons).
            self._table.setCellWidget(
                i, self._col_act, self._build_action_widget(job, i, running))

    # ------------------------------------------------------------------
    # P3.28 row-widget builders: selection checkbox + generated state
    # ------------------------------------------------------------------
    def _build_check_widget(self, idx: int, job: BatchJob,
                            running: bool) -> QWidget:
        """Column 1 — the per-row selective-generation checkbox.

        Default state comes from _init_check_defaults (§11: only
        not-generated slots checked); user toggles are stored in
        _check_states and survive table rebuilds. Disabled while the
        batch runs.
        """
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.setAlignment(Qt.Alignment.AlignCenter)
        checkbox = QCheckBox()
        checkbox.setChecked(bool(self._check_states.get(idx, False)))
        checkbox.setEnabled(not running)
        checkbox.setToolTip(
            "Include this part in the next generation.\n"
            "Checking an already-generated part regenerates it as a NEW\n"
            "VERSION — the existing audio is never overwritten.")

        def _on_toggle(checked, _idx=idx):
            self._check_states[_idx] = bool(checked)
            self._update_start_button()

        checkbox.toggled.connect(_on_toggle)
        layout.addWidget(checkbox)
        return widget

    def _build_generated_widget(self, job: BatchJob) -> QWidget:
        """Column 3 — the DERIVED generated state + lazy version popover.

        "✓ Generated · N versions ▾" or "— Not generated" (P3.28 §4).
        The ▾ button opens a lazily-built QMenu listing each version
        (v01 · 12.4s · filename) with a "Use" action — never a widget
        per version (§24/Rec 22). No slot provenance (manual job) → "—".
        """
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(6, 0, 6, 0)
        layout.setSpacing(4)
        # P3.40: explicit vertical centring (never rely on layout defaults).
        layout.setAlignment(Qt.Alignment.AlignVCenter)
        slot_id = getattr(job, "slot_id", None)
        if not slot_id or self._scene is None:
            label = QLabel("\u2014")
            label.setStyleSheet("color: {0};".format(Palette.TEXT_DISABLED))
            layout.addWidget(label)
            layout.addStretch()
            return widget
        from engine.audio_provenance import (
            slot_versions, resolved_asset_for_slot, block_slot_id,
        )
        versions = slot_versions(self._scene, slot_id)
        resolved = resolved_asset_for_slot(self._scene, slot_id)
        if not versions:
            label = QLabel("\u2014 Not generated")
            label.setStyleSheet("color: {0};".format(Palette.TEXT_DISABLED))
            layout.addWidget(label)
            layout.addStretch()
            return widget
        # ✓ Generated · N versions ▾
        state_label = QLabel("\u2713 Generated")
        state_label.setStyleSheet(
            "color: {0}; font-weight: 700;".format(Palette.SUCCESS))
        layout.addWidget(state_label)
        versions_btn = QPushButton(
            "\u00b7 {0} version{1} \u25be".format(
                len(versions), "" if len(versions) == 1 else "s"))
        versions_btn.setFlat(True)
        versions_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        versions_btn.setStyleSheet(
            "QPushButton {{ color: {accent}; border: none;"
            " padding: 3px 8px; font-size: 12px; font-weight: 600; }}"
            "QPushButton:hover {{ color: {hover}; }}".format(
                accent=Palette.ACCENT, hover=Palette.ACCENT_HOVER))
        versions_btn.clicked.connect(
            lambda _checked=False, _slot=slot_id, _btn=versions_btn:
            self._show_versions_menu(_slot, _btn))
        layout.addWidget(versions_btn)
        # Per-slot resolved version badge (explicit selection marker).
        selected = (self._scene.selected_block_audio or {}).get(slot_id)
        if selected and resolved is not None:
            try:
                v = int(resolved.get("part_version") or 0)
            except (TypeError, ValueError):
                v = 0
            badge = QLabel("\u00b7 v{0:02d} selected".format(v))
            badge.setStyleSheet("color: {0};".format(Palette.WARNING))
            badge.setToolTip(
                "An explicitly selected version feeds Combine and the\n"
                "version list (an explicit user action — never automatic).")
            layout.addWidget(badge)
        layout.addStretch()
        return widget

    def _show_versions_menu(self, slot_id: str, anchor_btn=None) -> None:
        """Lazy version popover for a slot (P3.28 §4/Rec 22).

        One menu entry per version: "v01 · 12.4s · filename" with a
        "Use" action; plus "Latest (default)" to clear an explicit
        selection. Choosing emits use_version_requested(slot_id,
        asset_id) — MainWindow owns the Scene mutation.

        P3.30(c): the menu is anchored ABOVE the "· N versions ▾" button
        (previously ``menu.exec()`` without a position — frameless
        top-left corner popup on Windows).
        """
        from PySide6.QtWidgets import QMenu
        from engine.audio_provenance import (
            slot_versions, resolved_asset_for_slot,
        )
        versions = slot_versions(self._scene, slot_id)
        resolved = resolved_asset_for_slot(self._scene, slot_id)
        resolved_id = resolved.get("id") if resolved else None
        menu = QMenu(self)
        menu.setWindowTitle("Versions")
        for entry in versions:
            try:
                v = int(entry.get("part_version") or 0)
            except (TypeError, ValueError):
                v = 0
            label = "v{0:02d} \u00b7 {1:.1f}s \u00b7 {2}".format(
                v, float(entry.get("duration") or 0.0),
                os.path.basename(str(entry.get("output_path") or "")))
            action = menu.addAction(label)
            if entry.get("id") == resolved_id:
                action.setText("\u2713 " + label + "   (in use)")
            asset_id = entry.get("id") or ""
            action.triggered.connect(
                lambda _checked=False, _s=slot_id, _a=asset_id:
                self.use_version_requested.emit(_s, _a))
        menu.addSeparator()
        clear_action = menu.addAction("Latest version (default)")
        clear_action.triggered.connect(
            lambda _checked=False, _s=slot_id:
            self.use_version_requested.emit(_s, ""))
        anchor = anchor_btn or self
        _popup_menu_above(menu, anchor)

    # ------------------------------------------------------------------
    # P3.28: Scene combined outputs section (§13–§15)
    # ------------------------------------------------------------------
    def _refresh_combined_section(self) -> None:
        """Rebuild the SCENE COMBINED OUTPUTS section (scene mode only).

        Shows the Scene's resolved output (the ONE thing Project
        Assembly consumes — §15) and one row per combined output with
        STALE badges and "Use as Scene output" selection.
        """
        if (self._scene is None
                or not hasattr(self, "_combined_rows_layout")):
            return
        from engine.audio_provenance import (
            resolve_scene_output, is_scene_combined_stale,
            KIND_SCENE_COMBINED, KIND_ASSET,
        )
        # --- resolved output line ---
        resolution = resolve_scene_output(self._scene, self._app_root)
        if resolution.get("requires_review"):
            res_html = (
                "<span style='color:{warn};'>Scene output: REVIEW "
                "REQUIRED — {reason}</span>").format(
                    warn=Palette.WARNING,
                    reason=resolution.get("reason", ""))
        else:
            color = (Palette.WARNING if resolution.get("stale")
                     else Palette.SUCCESS)
            stale_note = (" \u00b7 STALE"
                          if resolution.get("stale") else "")
            res_html = (
                "Scene output: <b>{label}</b>{stale}"
                " <span style='color:{muted};'>({path})</span>").format(
                    label=resolution.get("label", ""),
                    stale=("<span style='color:{0};'>".format(color)
                           + stale_note + "</span>") if stale_note else "",
                    muted=Palette.TEXT_SECONDARY,
                    path=os.path.basename(
                        str(resolution.get("rel_path") or "")))
        self._resolved_output_label.setText(res_html)
        # --- combined output rows (newest first; ONE row per output) ---
        while self._combined_rows_layout.count():
            item = self._combined_rows_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        entries = [e for e in (self._scene.combined_outputs or [])
                   if isinstance(e, dict)]
        entries.sort(key=lambda e: _safe_int(e.get("version")),
                     reverse=True)
        selected = (self._scene.selected_output or {})
        for entry in entries:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(6)
            try:
                v = int(entry.get("version") or 0)
            except (TypeError, ValueError):
                v = 0
            stale, reasons = is_scene_combined_stale(
                self._scene, entry, self._app_root)
            text = "Combined v{0:02d} \u00b7 {1:.1f}s".format(
                v, float(entry.get("duration") or 0.0))
            label = QLabel(text)
            label.setStyleSheet("color: {0}; font-size: 11px;".format(
                Palette.TEXT_PRIMARY))
            row_layout.addWidget(label)
            if stale:
                stale_badge = QLabel("STALE")
                stale_badge.setStyleSheet(
                    "color: {0}; background-color: {1}; border-radius: 7px;"
                    " padding: 1px 6px; font-size: 10px; font-weight: 700;"
                    .format(Palette.WARNING,
                            self._tint_bg(Palette.WARNING)))
                stale_badge.setToolTip("\n".join(reasons) or "stale")
                row_layout.addWidget(stale_badge)
            is_selected = (selected.get("kind") == KIND_SCENE_COMBINED
                           and selected.get("id") == entry.get("id"))
            use_btn = QPushButton(
                "\u2713 selected" if is_selected else "Use as output")
            use_btn.setMinimumHeight(28)
            use_btn.setStyleSheet(
                "QPushButton {{ color: {accent}; border: 1px solid"
                " {border}; border-radius: 4px; padding: 4px 10px;"
                " font-size: 12px; background-color: {bg}; }}"
                "QPushButton:hover {{ border-color: {accent}; }}"
                "QPushButton:disabled {{ color: {success};"
                " border-color: {success}; background-color: {tint}; }}"
                .format(accent=Palette.ACCENT, border=Palette.BORDER,
                        bg=Palette.BG_RAISED,
                        success=Palette.SUCCESS,
                        tint=self._tint_bg(Palette.SUCCESS)))
            use_btn.setEnabled(not is_selected)
            use_btn.setToolTip(
                "Make this combined output the Scene's explicit output\n"
                "for Project Assembly (an explicit user selection — a\n"
                "STALE one requires confirmation and is clearly flagged).")
            entry_id = entry.get("id") or ""
            use_btn.clicked.connect(
                lambda _checked=False, _id=entry_id:
                self.select_output_requested.emit(KIND_SCENE_COMBINED, _id))
            row_layout.addWidget(use_btn)
            row_layout.addStretch()
            self._combined_rows_layout.addWidget(row)
        if not entries:
            empty = QLabel("No combined outputs yet — press Combine Scene.")
            empty.setStyleSheet("color: {0}; font-size: 11px;".format(
                Palette.TEXT_DISABLED))
            self._combined_rows_layout.addWidget(empty)
        # "Clear selection" row when an explicit selection exists.
        if selected:
            clear_row = QWidget()
            clear_layout = QHBoxLayout(clear_row)
            clear_layout.setContentsMargins(0, 0, 0, 0)
            clear_btn = QPushButton("\u00d7 Clear explicit selection "
                                    "(use automatic resolution)")
            clear_btn.setFlat(True)
            clear_btn.setStyleSheet(
                "color: {0}; padding: 4px 6px; font-size: 12px;".format(
                    Palette.TEXT_SECONDARY))
            clear_btn.clicked.connect(
                lambda _checked=False:
                self.select_output_requested.emit("", ""))
            clear_layout.addWidget(clear_btn)
            clear_layout.addStretch()
            self._combined_rows_layout.addWidget(clear_row)

    def _on_select_all(self) -> None:
        """Check every part (generate everything)."""
        for idx in range(len(self._manager.jobs)):
            self._check_states[idx] = True
        self._refresh_table()
        self._update_start_button()

    def _on_select_none(self) -> None:
        """Uncheck every part."""
        for idx in range(len(self._manager.jobs)):
            self._check_states[idx] = False
        self._refresh_table()
        self._update_start_button()

    def _on_export_audio(self) -> None:
        """P3.28 §17: Export Audio… scope menu (copy-only export).

        P3.30(b): the scope menu is anchored ABOVE the Export Audio
        button (previously ``menu.exec()`` without a position — frameless
        top-left corner popup on Windows).
        """
        from PySide6.QtWidgets import QMenu
        menu = QMenu(self)
        checked = [idx for idx, val in self._check_states.items() if val]
        act_sel = menu.addAction(
            "Selected rows ({0})".format(len(checked)))
        act_parts = menu.addAction("All generated parts")
        act_combined = menu.addAction("Scene combined outputs")
        act_every = menu.addAction("Everything in this batch")
        anchor = getattr(self, "_export_btn", None) or self
        chosen = _popup_menu_above(menu, anchor)
        if chosen is act_sel:
            self.export_audio_requested.emit("selected", checked)
        elif chosen is act_parts:
            self.export_audio_requested.emit("parts", [])
        elif chosen is act_combined:
            self.export_audio_requested.emit("combined", [])
        elif chosen is act_every:
            self.export_audio_requested.emit("everything", [])

    # ------------------------------------------------------------------
    # Row-widget builders (P3.18 — extracted from the old _refresh_table)
    # ------------------------------------------------------------------
    def _build_status_widget(self, job: BatchJob) -> QWidget:
        """Build a colored pill widget for the Status column.

        Pill variants (all using Palette colors, not mock hex values):
            COMPLETED  → green pill + check_circle icon ("Done")
            GENERATING → amber pill + AnimatedHourglass      ("Gen")
            PENDING    → gray pill + schedule icon           ("Queued")
            FAILED     → red pill   + error icon             ("Error")
            SKIPPED    → red pill   + stop icon              ("Stopped")

        The widget also carries a tooltip merging the old Output and
        Error columns (so the information is one hover away, without
        cluttering the table).
        """
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(6, 0, 6, 0)
        layout.setSpacing(5)
        layout.setAlignment(Qt.Alignment.AlignCenter)

        status = job.status
        icon_label: Optional[QLabel] = None
        pill_text = "Queued"
        pill_color = Palette.TEXT_SECONDARY

        if status == JobStatus.GENERATING:
            # Animated spinning hourglass replaces the static icon.
            hourglass = AnimatedHourglass()
            hourglass.start()
            layout.addWidget(hourglass)
            pill_text = "Gen"
            pill_color = Palette.WARNING
        elif status == JobStatus.COMPLETED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("check_circle", size=14,
                                  color=Palette.SUCCESS).pixmap(QSize(14, 14)))
            pill_text = "Done"
            pill_color = Palette.SUCCESS
        elif status == JobStatus.FAILED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("error", size=14,
                                  color=Palette.ERROR).pixmap(QSize(14, 14)))
            pill_text = "Error"
            pill_color = Palette.ERROR
        elif status == JobStatus.SKIPPED:
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("stop", size=14,
                                  color=Palette.ERROR).pixmap(QSize(14, 14)))
            pill_text = "Stopped"
            pill_color = Palette.ERROR
        else:  # PENDING → "Queued"
            icon_label = QLabel()
            icon_label.setPixmap(
                IconRegistry.icon("schedule", size=14,
                                  color=Palette.TEXT_SECONDARY
                                  ).pixmap(QSize(14, 14)))
            pill_text = "Queued"
            pill_color = Palette.TEXT_SECONDARY

        if icon_label is not None:
            layout.addWidget(icon_label)

        pill = QLabel(pill_text)
        pill.setStyleSheet(self._pill_style(pill_color))
        layout.addWidget(pill)

        # Merge old Output + Error columns into the pill tooltip.
        tips = []
        if job.error:
            tips.append("Error: " + job.error)
        if job.output_path:
            tips.append("Output: " + os.path.basename(job.output_path))
        # P3.27B: surface the output-guard verdict in the pill tooltip too.
        anomaly = getattr(job, "anomaly", None)
        if anomaly:
            tips.append("Warning: unusually long output — see the "
                        "Duration cell tooltip for details")
        if tips:
            widget.setToolTip("\n".join(tips))
        return widget

    def _anomaly_tooltip(self, job: BatchJob,
                         anomaly: dict) -> str:
        """P3.27B: tooltip text for an anomalous generation output.

        Shows the guard's reasons plus the measured speech/silence
        breakdown, and states explicitly that the audio was kept (the
        user decides: keep / inspect / regenerate).
        """
        analysis = anomaly.get("analysis", {}) if isinstance(anomaly, dict) else {}
        lines = ["Warning: unusually long output"]
        for reason in (anomaly.get("reasons", [])
                       if isinstance(anomaly, dict) else []):
            lines.append("  • " + str(reason))
        if analysis:
            lines.append(
                "Measured: {0:.1f}s total, {1:.1f}s speech, "
                "{2:.1f}s trailing silence".format(
                    float(analysis.get("total_s", 0.0) or 0.0),
                    float(analysis.get("speech_s", 0.0) or 0.0),
                    float(analysis.get("trailing_silence_s", 0.0) or 0.0)))
        lines.append("")
        lines.append("The audio file was kept — nothing was deleted.")
        lines.append("You can keep it, inspect it (Play), or regenerate "
                     "this part (Regen button).")
        return "\n".join(lines)

    def _build_action_widget(self, job: BatchJob, idx: int,
                             running: bool) -> QWidget:
        """Build the per-row Play + Stop + Regen action buttons.

        Extracted verbatim (signal connections preserved) from the old
        ``_refresh_table`` so the new 5-column layout can reuse the
        same logic without touching the slot handlers.
        """
        action_widget = QWidget()
        action_layout = QHBoxLayout(action_widget)
        action_layout.setContentsMargins(4, 4, 4, 4)
        action_layout.setSpacing(4)
        # P3.40: explicit vertical centring of the button band. The cell
        # widget spans the item content rect (48 - 1 = 47px); the fixed
        # 4+36+4 = 44px band is centred with ≈1.5px of extra slack on each
        # side — never top-anchored, never clipped at the bottom.
        action_layout.setAlignment(Qt.Alignment.AlignVCenter)

        # Common button style — icon-only, no text, no font-size.
        # P3.40 geometry: 36px button = 32px icon + 2×1px border + 2×1px
        # padding — the 32px icon fits the button contents rect EXACTLY
        # (the old 2px padding left only 30px of content height).
        btn_style = (
            "QPushButton {{"
            "  background-color: {bg_raised};"
            "  color: {text_primary};"
            "  border: 1px solid {border};"
            "  border-radius: 4px;"
            "  padding: 1px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent};"
            "  color: {accent_text};"
            "  border: 1px solid {accent};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                bg_raised=Palette.BG_RAISED,
                text_primary=Palette.TEXT_PRIMARY,
                border=Palette.BORDER,
                accent=Palette.ACCENT,
                accent_text=Palette.ACCENT_TEXT,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED))

        # Play button — play_arrow icon plays the generated WAV.
        play_btn = QPushButton()
        play_btn.setToolTip("Play this part's audio")
        play_btn.setFixedSize(36, 36)
        play_btn.setIcon(IconRegistry.icon(
            "play_arrow", size=36, color=Palette.TEXT_PRIMARY))
        play_btn.setIconSize(QSize(32, 32))
        play_btn.setStyleSheet(btn_style)
        play_btn.setEnabled(not running and job.status == JobStatus.COMPLETED
                            and bool(job.output_path))
        play_btn.clicked.connect(
            lambda _checked=False, p=job.output_path:
            self.play_requested.emit(p) if p else None)
        action_layout.addWidget(play_btn)

        # Stop playback button — stop icon stops any currently playing audio.
        stop_play_btn = QPushButton()
        stop_play_btn.setToolTip("Stop playback")
        stop_play_btn.setFixedSize(36, 36)
        stop_play_btn.setIcon(IconRegistry.icon(
            "stop", size=36, color=Palette.TEXT_PRIMARY))
        stop_play_btn.setIconSize(QSize(32, 32))
        stop_play_btn.setStyleSheet(btn_style)
        stop_play_btn.clicked.connect(self.stop_playback_requested.emit)
        action_layout.addWidget(stop_play_btn)

        # Regen button — refresh icon regenerates this single job.
        regen_btn = QPushButton()
        regen_btn.setToolTip(
            "Regenerate ONLY this part.\n"
            "Queue position and output filename are preserved.")
        regen_btn.setFixedSize(36, 36)
        regen_btn.setIcon(IconRegistry.icon(
            "refresh", size=36, color=Palette.ACCENT_TEXT))
        regen_btn.setIconSize(QSize(32, 32))
        # Accent style for the Regen button (primary action).
        regen_btn.setStyleSheet(
            "QPushButton {{"
            "  background-color: {accent};"
            "  color: {accent_text};"
            "  border: 1px solid {accent};"
            "  border-radius: 4px;"
            "  padding: 1px;"
            "}}"
            "QPushButton:hover {{"
            "  background-color: {accent_hover};"
            "}}"
            "QPushButton:disabled {{"
            "  background-color: {bg_surface};"
            "  color: {text_disabled};"
            "  border: 1px solid {border};"
            "}}".format(
                accent=Palette.ACCENT,
                accent_text=Palette.ACCENT_TEXT,
                accent_hover=Palette.ACCENT_HOVER,
                bg_surface=Palette.BG_SURFACE,
                text_disabled=Palette.TEXT_DISABLED,
                border=Palette.BORDER))
        can_regen = (not running
                     and job.status in (JobStatus.COMPLETED,
                                        JobStatus.FAILED))
        regen_btn.setEnabled(can_regen)
        regen_btn.clicked.connect(
            lambda _checked=False, idx=idx: self._on_regen(idx))
        action_layout.addWidget(regen_btn)
        return action_widget

    @staticmethod
    def _status_color(status: JobStatus) -> QColor:
        """Map a JobStatus to its canonical Palette color.

        Retained for backwards compatibility and used by the status-pill
        builder as the single source of truth for status → color mapping.
        """
        try:
            if status == JobStatus.COMPLETED:
                return QColor(Palette.SUCCESS)
            if status == JobStatus.FAILED:
                return QColor(Palette.ERROR)
            if status == JobStatus.GENERATING:
                return QColor(Palette.WARNING)
            if status == JobStatus.SKIPPED:
                return QColor(Palette.ERROR)
            if status == JobStatus.PENDING:
                return QColor(Palette.TEXT_SECONDARY)
        except Exception:
            pass
        return QColor(Palette.TEXT_PRIMARY)

    def _update_buttons(self) -> None:
        running = self._manager.is_running
        paused = self._manager.is_paused
        stopping = running and not paused and getattr(
            self._manager, "stop_requested", False)
        self._start_btn.setEnabled(not running or paused)
        self._pause_btn.setEnabled(running and not paused)
        self._stop_btn.setEnabled(running and not stopping)
        # P3.30(d): a visible "Stopping…" state — the queue is ending; a
        # generation already inside the model call must run out (the
        # model API has no mid-call interruption hook), so the button
        # explains the wait instead of looking dead.
        self._stop_btn.setText("Stopping\u2026" if stopping else "Stop")
        # Job editing is disabled while running.
        editable = not running
        for btn in (self._add_btn, self._edit_btn, self._remove_btn,
                    self._dup_btn, self._up_btn, self._down_btn,
                    self._save_btn, self._load_btn, self._clear_btn):
            btn.setEnabled(editable)
        # Merge Completed Parts (manual queue only — scene mode has
        # Combine Scene) is enabled when not running AND at least 2
        # COMPLETED jobs exist (merging 0 or 1 part is pointless).
        completed_count = sum(
            1 for j in self._manager.jobs if j.status == JobStatus.COMPLETED)
        if hasattr(self, "_concat_btn"):
            self._concat_btn.setEnabled(not running and completed_count >= 2)
        # P3.28: Combine Scene + Export Audio (scene mode only) — enabled
        # when the queue is idle. The combine handler blocks with a clear
        # message when slots are uncovered (no silent skipping).
        if self._scene is not None:
            slots = [s for s in (getattr(self._scene, "expected_audio_slots",
                                         None) or []) if isinstance(s, dict)]
            if hasattr(self, "_combine_btn"):
                self._combine_btn.setEnabled(
                    not running and bool(slots))
            if hasattr(self, "_export_btn"):
                self._export_btn.setEnabled(
                    not running and (completed_count >= 1
                                     or bool(self._scene.combined_outputs)))

    def _update_summary(self) -> None:
        """Populate the QUEUE SUMMARY sidebar widgets.

        Replaces the old single multi-line HTML summary label with the
        new sidebar layout: progress headline + thin progress bar + four
        mono-font stat lines (Generated Audio / RTF / Wall Time / State).

        Counts (total / completed / failed / skipped / audio total) are
        computed from the manager's CURRENT job list so the sidebar
        always reflects what the user sees in the table — even before a
        batch has been started (the old code read from
        ``manager.summary`` which is only populated during a run, so a
        freshly-loaded queue showed "Queue is empty."). Run-level
        statistics (RTF, wall time) still come from ``manager.summary``
        because they only make sense in the context of a finished run.

        Method signature unchanged.
        """
        jobs = self._manager.jobs
        total = len(jobs)
        completed = sum(1 for j in jobs if j.status == JobStatus.COMPLETED)
        failed    = sum(1 for j in jobs if j.status == JobStatus.FAILED)
        skipped   = sum(1 for j in jobs if j.status == JobStatus.SKIPPED)
        audio_total = sum(j.output_duration for j in jobs
                          if j.status == JobStatus.COMPLETED)

        if total == 0:
            self._progress_text.setText("Idle")
            self._progress.setValue(0)
            self._audio_label.setText("Generated Audio    \u2014")
            self._rtf_label.setText("Real Time Factor    \u2014")
            self._wall_label.setText("Wall Time    \u2014")
            self._state_label.setText("State    Idle")
            return

        # Paused takes precedence over Running (visual improvement: the
        # mock shows "Paused" when paused, even if the batch loop is
        # still technically running underneath).
        if self._manager.is_paused:
            state = "Paused"
        elif self._manager.is_running:
            state = "Running"
        elif (completed + failed + skipped) == total:
            state = "Finished"
        else:
            state = "Idle"

        done = completed + failed + skipped
        self._progress_text.setText(
            "Progress    {done}/{total} completed".format(
                done=done, total=total))
        self._progress.setValue(int(round((done / total) * 100)))
        self._audio_label.setText(
            "Generated Audio    {0:.2f}s".format(audio_total))

        # RTF + wall time come from BatchSummary (only meaningful after a
        # run; show an em dash when no run data is available yet).
        s = self._manager.summary
        if s.total_wall_seconds > 0:
            self._rtf_label.setText(
                "Real Time Factor    {0:.2f} RTF".format(s.realtime_factor))
            self._wall_label.setText(
                "Wall Time    {0:.1f}s".format(s.total_wall_seconds))
        else:
            self._rtf_label.setText("Real Time Factor    \u2014")
            self._wall_label.setText("Wall Time    \u2014")
        self._state_label.setText("State    {0}".format(state))

    # ------------------------------------------------------------------
    # Slot handlers
    # ------------------------------------------------------------------
    def _selected_row(self) -> Optional[int]:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return None
        return rows[0].row()

    def _on_add(self) -> None:
        job = BatchJob(
            name="New Job",
            prompt="",
            parameters=GenerationParameters(),
        )
        dlg = JobEditDialog(job, self._voices, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            dlg.apply_to_job()
            self._manager.add_job(job)
            self._refresh_table()

    def _on_edit(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        jobs = self._manager.jobs
        if idx >= len(jobs):
            return
        # Edit a *copy* so the user can cancel without side-effects.
        original = jobs[idx]
        import dataclasses
        # Deep-ish copy via dict round-trip
        from engine.batch_manager import BatchJob as _BJ
        clone = _BJ.from_dict(original.to_dict())
        dlg = JobEditDialog(clone, self._voices, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            dlg.apply_to_job()
            # Replace the original in-place
            self._manager.remove_job(idx)
            self._manager._jobs.insert(idx, clone)  # noqa: SLF001
            self._refresh_table()

    def _on_remove(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        self._manager.remove_job(idx)
        self._refresh_table()

    def _on_duplicate(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        self._manager.duplicate_job(idx)
        self._refresh_table()

    def _on_move_up(self) -> None:
        idx = self._selected_row()
        if idx is None or idx == 0:
            return
        self._manager.move_job(idx, idx - 1)
        self._refresh_table()
        self._table.selectRow(idx - 1)

    def _on_move_down(self) -> None:
        idx = self._selected_row()
        if idx is None:
            return
        jobs = self._manager.jobs
        if idx >= len(jobs) - 1:
            return
        self._manager.move_job(idx, idx + 1)
        self._refresh_table()
        self._table.selectRow(idx + 1)

    def _on_clear(self) -> None:
        if not self._manager.jobs:
            return
        reply = QMessageBox.question(
            self, "Clear Queue",
            "Remove all jobs from the queue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self._manager.clear_all()
            self._refresh_table()

    def _on_save_queue(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Batch Queue",
            "batch_queue.yaml",
            "YAML Files (*.yaml *.yml);;JSON Files (*.json);;All Files (*)")
        if not path:
            return
        try:
            self._manager.save_to_file(path)
            QMessageBox.information(self, "Saved",
                                    "Batch queue saved to:\n{0}".format(path))
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed",
                                 "Could not save the queue: {0}".format(exc))

    def _on_load_queue(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Batch Queue",
            "", "YAML Files (*.yaml *.yml);;JSON Files (*.json);;All Files (*)")
        if not path:
            return
        try:
            n = self._manager.load_from_file(path, replace=True)
            QMessageBox.information(self, "Loaded",
                                    "Loaded {0} jobs from:\n{1}".format(n, path))
        except Exception as exc:
            QMessageBox.critical(self, "Load Failed",
                                 "Could not load the queue: {0}".format(exc))
        self._refresh_table()

    def _on_start(self) -> None:
        if not self._manager.jobs:
            QMessageBox.information(self, "Empty Queue",
                                    "Add at least one job before starting.")
            return
        # P3.28 §11–§12: scene mode = SELECTIVE generation — exactly the
        # checked rows. MainWindow allocates fresh versions for covered
        # checked slots, marks unchecked pending jobs SKIPPED, and runs
        # the SAME pipeline. Legacy manual mode = plain START BATCH.
        if self._scene is not None:
            checked = sorted(idx for idx, val in self._check_states.items()
                             if val)
            if not checked:
                QMessageBox.information(
                    self, "Nothing Selected",
                    "No parts are checked.\n\nCheck at least one part to "
                    "generate (use the All button to check every part).")
                return
            self.generate_selected_requested.emit(checked)
            # Force immediate button refresh — don't wait for the
            # marshal_to_ui callback (which can be delayed).
            self._update_buttons()
            self._refresh_table()
            self._update_summary()
            return
        ok = self._manager.start()
        if not ok:
            QMessageBox.information(self, "Already Running",
                                    "The batch is already running.")
            return
        # Force immediate button refresh — don't wait for the
        # marshal_to_ui callback (which can be delayed).
        self._update_buttons()
        self._refresh_table()
        self._update_summary()

    def _on_regen(self, idx: int) -> None:
        """Regenerate a single job in-place.

        P3.27B: the actual reset + versioned-filename allocation is
        delegated to MainWindow via the ``regen_requested`` signal:
        Generate Long parts (part_index set) get a NEW VERSIONED output
        file (the previous version is preserved on disk — a pathological
        outlier regeneration can no longer destroy the previous good
        audio), while manual batch jobs keep the legacy
        overwrite-in-place contract. Queue position is preserved either
        way, so concatenation order is unaffected.
        """
        if self._manager.is_running:
            QMessageBox.warning(
                self, "Batch Running",
                "Stop the current batch before regenerating a single item.")
            return
        jobs = self._manager.jobs
        if idx < 0 or idx >= len(jobs):
            return
        job = jobs[idx]
        is_part = getattr(job, "part_index", None) is not None
        if is_part:
            message = (
                "Regenerate ONLY this part?\n\n"
                "  Part: {0}\n"
                "  Current output: {1}\n\n"
                "A NEW VERSIONED file will be created (e.g. v02); the\n"
                "previous version's audio is kept on disk. Queue position\n"
                "is preserved, so concatenation order is not affected.\n"
                "Other parts are NOT re-generated.".format(
                    job.name or job.prompt[:40],
                    job.output_filename or "(auto)"))
        else:
            message = (
                "Regenerate ONLY this item?\n\n"
                "  Item: {0}\n"
                "  Output: {1}\n\n"
                "The output file will be overwritten in place. Queue position\n"
                "is preserved, so concatenation order is not affected. Other\n"
                "items are NOT re-generated.".format(
                    job.name or job.prompt[:40],
                    job.output_filename or "(auto)"))
        reply = QMessageBox.question(
            self, "Regenerate Part", message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Yes)
        if reply != QMessageBox.StandardButton.Yes:
            return
        # P3.27B: MainWindow allocates the next version (Generate Long
        # parts) and performs the reset + start.
        self.regen_requested.emit(idx)

    def _on_pause(self) -> None:
        self._manager.pause()
        # Force immediate button refresh.
        self._update_buttons()

    def _on_stop(self) -> None:
        """Stop the batch and immediately update the UI (do not wait for
        the next marshal_to_ui callback - the user wants visual feedback
        the instant they click Stop).

        P3.30(d): pending jobs flip to SKIPPED instantly; a queued (not
        yet started) generation is cancelled cooperatively by the
        engine; a generation already inside the model call cannot be
        interrupted (documented model limitation — generate_speech() is
        one blocking native call), finishes, and its audio is KEPT. The
        Stop button shows "Stopping…" until the batch actually ends.
        """
        self._manager.stop()
        # Immediate refresh so SKIPPED rows appear at once.
        self._refresh_table()
        self._update_buttons()
        self._update_summary()

    def _on_concatenate(self) -> None:
        """Concatenate all COMPLETED parts into a single WAV.

        Collects the output paths of every COMPLETED job IN QUEUE ORDER
        and emits concatenate_requested(paths). The MainWindow handler
        does the actual concatenation via the engine's AudioManager and
        loads the result into the waveform player.

        Using the queue order directly guarantees the concatenation
        sequence is always correct, regardless of regen operations —
        regen preserves both the queue position and the output filename,
        so the list order IS the final audio order.
        """
        if self._manager.is_running:
            QMessageBox.warning(
                self, "Batch Running",
                "Stop the batch before concatenating.")
            return
        # Collect COMPLETED job output paths in queue order.
        paths = []
        for job in self._manager.jobs:
            if job.status == JobStatus.COMPLETED and job.output_path:
                # Resolve to absolute path for the engine's AudioManager.
                full = job.output_path
                if not os.path.isabs(full):
                    # The engine resolves relative paths against APP_ROOT,
                    # so pass the relative path as-is — the MainWindow
                    # handler will resolve it.
                    pass
                paths.append(full)
        if len(paths) < 2:
            QMessageBox.information(
                self, "Nothing to Concatenate",
                "Need at least 2 completed parts to concatenate.\n"
                "Current completed: {0}".format(len(paths)))
            return
        # Emit so MainWindow can do the actual work (it has the engine).
        self.concatenate_requested.emit(paths)

    # ------------------------------------------------------------------
    # Close handling
    # ------------------------------------------------------------------
    def close_without_stopping_batch(self) -> None:
        """P3.35 §3/§11: single-live-instance hand-over close.

        Closes this dialog (saving UI state and RELEASING the shared
        manager's callbacks) WITHOUT stopping a running batch — the
        replacement dialog shows the same shared queue and its live
        progress continues seamlessly.
        """
        self._close_preserve_batch = True
        try:
            self.close()
        finally:
            self._close_preserve_batch = False

    def closeEvent(self, event) -> None:
        # Save the dialog size + column configuration so they persist
        # across reopens and application restarts (P3.35 §22-§28).
        self._geo_save_timer.stop()
        self._save_geometry()
        self._save_column_state()
        self._ui_state_saved = True
        # Stop the batch (mark PENDING as SKIPPED) when the USER closes
        # the dialog so we don't leave orphaned jobs running in the
        # background. A mode-switch close (close_without_stopping_batch)
        # keeps the batch alive — the replacement dialog takes over the
        # very same shared queue (P3.35 §3/§11).
        if (not self._close_preserve_batch and self._manager.is_running):
            self._manager.stop()
        # P3.35 §4: give the shared manager's single-slot callbacks back —
        # never leave them pointing at a hidden/closed dialog.
        self._release_manager()
        super().closeEvent(event)

================================================================
  SpeechStudio - Quick Start Guide
================================================================

WHAT THIS IS:
  SpeechStudio is a portable Windows desktop application for local
  speech synthesis using the Higgs Audio V3 TTS model.

  The application manages its own virtual environment, dependencies,
  and model downloads automatically. You never need to open a terminal,
  edit Python files, or activate a virtual environment manually.

  All processing is local. No cloud, no telemetry.

REQUIREMENTS:
  - Windows 10/11 (64-bit)
  - Python 3.11 (exactly) - install from https://www.python.org/
    Make sure "Add Python to PATH" is checked during installation.
  - NVIDIA GPU with CUDA support (for speech generation)
  - ~12 GB free disk space (for the model download)
  - Internet connection (for the first run only)

HOW TO START:
  1. Extract this folder to any location on your computer
     (e.g. C:\SpeechStudio or D:\SpeechStudio)
  2. Double-click launch.bat
  3. Wait for the first-run setup to complete:
     - Creates a virtual environment (venv/)
     - Installs PyTorch, Transformers, PySide6, and other dependencies
     - Downloads the Higgs Audio V3 model (~9 GB, one-time)
  4. The SpeechStudio window will open automatically

FIRST RUN TAKES TIME:
  The first run downloads ~9 GB of model files. This can take
  10-60 minutes depending on your internet connection. The download
  is resumable - if it is interrupted, just run launch.bat again.

SUBSEQUENT RUNS:
  After the first run, launch.bat starts instantly because everything
  is cached locally. No internet connection is needed.

HOW TO UPDATE (IMPORTANT):
  To update SpeechStudio to a new version WITHOUT losing your data:

  1. Download the new SpeechStudio_clean.zip
  2. Place it in the SpeechStudio folder (next to SpeechStudio.py)
  3. Close the SpeechStudio application if it is running
  4. Double-click update.bat

  The update script:
  - Backs up your current source code (to _backup_source_*)
  - Extracts ONLY the .py/.txt/.bat/.md/.yaml source files
  - PRESERVES your personal data:
      * settings/settings.json  (theme, project, volume)
      * settings/history/       (history entries)
      * voices/                 (voice profiles)
      * outputs/                (generated audio)
      * presets/                (saved presets)
      * models/                 (the 9 GB Higgs model)
  - NEVER delete the whole folder and re-extract! Use update.bat.

KEYBOARD SHORTCUTS:
  Ctrl+Enter          Generate speech
  Ctrl+Shift+Enter    Generate Long Narration (splits text, batch)
  Esc                 Stop generation
  Space               Play / Pause playback (when editor not focused)
  Ctrl+N              New Project
  Ctrl+O              Open Project
  Ctrl+S              Save Project info
  Ctrl+L              Voice Library
  Ctrl+H              History
  F11                 Fullscreen

FEATURES:
  Generation:
  - Single generation with full Higgs token support
  - Long Narration: splits text into safe parts, batch-generates
    each with 0.5s trailing silence, then concatenates into one WAV
  - Batch Generation dialog: queue, edit, reorder, save/load queues
  - Per-part Regen button: regenerate a single part in-place
    (queue order and output filename preserved)
  - Manual Concatenate button: merge completed parts into one WAV
    (100ms crossfade between parts)

  Playback (waveform player):
  - Click or drag on the waveform to seek
  - Pause / Resume / Stop transport controls
  - Volume slider (persisted across restarts)
  - Real-time playhead tracking (~20 Hz)

  Projects:
  - Group history entries by project name
  - Project name persists across restarts
  - File menu: New / Open / Save Project

  History:
  - Every generation is stored as a reproducible JSON entry
  - Concatenated audio also gets a history entry
  - Browse, replay, reuse settings, export, delete

  Themes (4):
  - Dark (default), Light, Synthwave, Retro Console
  - Switch via View menu

  Supported Languages:
  - 102 languages (85 production-quality, 17 usable)
  - See Help > Supported Languages for the full list
  - Hungarian is in Tier 1 (production quality)

  Voices:
  - Zero-shot voice cloning from a reference audio clip
  - Import / export voice profiles

TROUBLESHOOTING:
  - If launch.bat says Python is not found:
    Install Python 3.11 from https://www.python.org/downloads/release/python-3119/
    Make sure "Add Python to PATH" is checked.

  - If the download fails:
    Check logs/bootstrap.log for details. The download uses regular
    HTTPS (not the hf-xet protocol) and is resumable. Re-run launch.bat.

  - If you see "Not enough disk space":
    Free up at least 12 GB and run launch.bat again.

  - If the model loads but CUDA is unavailable:
    Install the latest NVIDIA drivers from https://www.nvidia.com/drivers

  - If the Generate button does nothing:
    Wait for the model to finish loading (check the status bar or
    logs/application.log for "Model loaded").

  - If Generate Long freezes at the end:
    Use the manual Concatenate button in the Batch dialog instead
    of expecting auto-concatenation.

PROJECT STRUCTURE:
  launch.bat          <- Double-click this to start
  update.bat          <- Use this to update from a new zip (preserves data)
  bootstrap.py        <- Environment setup (runs automatically)
  SpeechStudio.py     <- Application entry point
  requirements.txt    <- Python dependencies
  engine/             <- Backend (model, prompt builder, audio, batch, etc.)
  ui/                 <- Frontend (PySide6 window, panels, theme)
  spec/               <- Project specifications
  research/           <- Reference documentation
  tools/              <- Verification scripts
  .cache/             <- Hugging Face cache (created on first run)
  venv/               <- Virtual environment (created on first run)
  logs/               <- Application logs
  outputs/            <- Generated WAV files
  voices/             <- Voice profiles
  settings/           <- settings.json + history/ entries
  presets/            <- Saved presets

================================================================
  Support the developer
================================================================
  If SpeechStudio is useful to you, consider supporting continued
  development:

  Ko-fi: https://ko-fi.com/thomashoysgameaudio

================================================================

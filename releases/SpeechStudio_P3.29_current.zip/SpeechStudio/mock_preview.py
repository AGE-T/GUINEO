#!/usr/bin/env python3
"""
SpeechStudio Mock Preview
=========================

Renders the full SpeechStudio UI with mock data — no engine, no model,
no real functionality. Used for visual verification after each build.

Usage:
    python3 mock_preview.py

The script:
1. Creates a QApplication
2. Loads fonts + theme
3. Creates a MainWindow with engine=None
4. Populates all panels with mock data (voices, history, presets, outputs)
5. Sets mock text in the editor
6. Saves a full screenshot to mock_preview.png
7. Keeps the window open for visual inspection
"""

import sys
import os
import time

# Set up paths
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_ROOT)

# Set the Qt platform — use offscreen for CI, or default for interactive
if "--offscreen" in sys.argv:
    os.environ["QT_QPA_PLATFORM"] = "offscreen"

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QFont, QPixmap

# Import font loader + theme
from ui.font_loader import load_fonts
from ui.theme import apply_theme

# Import the MainWindow
from ui.main_window import MainWindow, APP_NAME, APP_VERSION

# Import mock data models
from engine.models import VoiceProfile, GenerationParameters


def create_mock_voices():
    """Create mock voice profiles for the voice library."""
    return [
        VoiceProfile(
            id="voice_captain",
            name="Captain",
            sample_rate=24000,
            channels=1,
            duration=8.5,
            reference_audio_path="voices/captain.wav",
            reference_transcript="Captain's log, star date forty-seven point three.",
        ),
        VoiceProfile(
            id="voice_engineer",
            name="Engineer",
            sample_rate=24000,
            channels=1,
            duration=6.2,
            reference_audio_path="voices/engineer.wav",
            reference_transcript="The engines are running smoothly, sir.",
        ),
        VoiceProfile(
            id="voice_narrator",
            name="Narrator",
            sample_rate=24000,
            channels=1,
            duration=12.0,
            reference_audio_path="voices/narrator.wav",
            reference_transcript="In the depths of space, a single voice echoed through the void.",
        ),
        VoiceProfile(
            id="voice_ai",
            name="AI Assistant",
            sample_rate=24000,
            channels=1,
            duration=4.8,
            reference_audio_path="voices/ai.wav",
            reference_transcript="Hello, how may I assist you today?",
        ),
    ]


def create_mock_history():
    """Create mock history entries."""
    from engine.models import GenerationResult, GenerationParameters
    import time
    entries = []
    for i in range(8):
        result = GenerationResult(
            success=True,
            output_path=f"outputs/output_{i+1:03d}.wav",
            output_duration=3.5 + i * 0.5,
            generation_time=1.2 + i * 0.1,
            parameters=GenerationParameters(),
            prompt=f"Hello world, this is test number {i+1}.",
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - i * 3600)),
        )
        entries.append(result)
    return entries


def create_mock_presets():
    """Create mock presets."""
    from engine.preset_manager import Preset
    return [
        Preset(name="Calm Narration", emotion="Contentment", style="Whispering",
               speed="Slow", pitch="Low", delivery="Expressive Low",
               voice_id="voice_narrator"),
        Preset(name="Energetic Commercial", emotion="Enthusiasm", style="Shouting",
               speed="Fast", pitch="High", delivery="Expressive High",
               voice_id="voice_captain"),
        Preset(name="Dark Monologue", emotion="Sadness", style=None,
               speed="Very Slow", pitch="Low", delivery="Expressive Low",
               voice_id="voice_narrator"),
        Preset(name="AI Assistant", emotion="Contentment", style=None,
               speed="Normal", pitch="Normal", delivery="Normal",
               voice_id="voice_ai"),
    ]


def create_mock_outputs():
    """Create mock output file list."""
    return [
        (f"output_{i+1:03d}.wav", f"outputs/output_{i+1:03d}.wav")
        for i in range(12)
    ]


def create_mock_scenes():
    """Create mock scene list for the sidebar."""
    return [
        {"id": "scene_02", "name": "02 Airlock"},
        {"id": "scene_01", "name": "01 Landing"},
        {"id": "scene_03", "name": "03 Corridor"},
        {"id": "scene_04", "name": "04 Bridge"},
        {"id": "scene_05", "name": "05 Engine Room"},
    ]


def set_mock_editor_text(mw):
    """Set mock text in the editor — multi-speaker dialogue."""
    text = """$CAPTAIN:
All hands, battle stations. This is not a drill.

$ENGINEER:
Shields at forty percent, Captain. We can't take another hit.

$CAPTAIN:
Reroute power from the engines. We need those shields up.

$ENGINEER:
Aye, sir. Rerouting now. Shields at sixty percent and climbing.

$CAPTAIN:
Good. Now let's show them what this ship can do.

$NARRATOR:
The stars streaked past the viewport as the ship accelerated into the void, leaving behind the debris of their encounter."""
    mw._editor.set_text(text)


def populate_mock_data(mw):
    """Populate all panels with mock data."""
    # Set project + scene
    mw._current_project = "Space Outpost"
    mw._current_scene = "Scene 02 — Airlock"
    mw._project_scene_bar.set_project(mw._current_project)
    mw._project_scene_bar.set_scene(mw._current_scene)

    # Populate sidebar scenes
    mw._sidebar.set_scenes(create_mock_scenes())
    mw._sidebar.set_active_scene("scene_02")

    # Populate voices
    voices = create_mock_voices()
    mw._sidebar.update_voices(voices)
    mw._control_panel.populate_voices(voices)

    # Select a voice
    mw._control_panel.set_selected_voice_id("voice_captain")
    voice = next((v for v in voices if v.id == "voice_captain"), None)
    if voice:
        mw._control_panel.set_voice_info(voice)
        mw._status_bar.set_current_voice(voice.name)

    # Populate history
    mw._sidebar.update_history(create_mock_history())

    # Populate outputs
    mw._sidebar.update_outputs(create_mock_outputs())

    # Set mock presets
    if mw._preset_manager:
        mw._preset_manager._presets = create_mock_presets()
        mw._refresh_presets()

    # Set editor text
    set_mock_editor_text(mw)

    # Set some control panel state
    mw._control_panel.set_emotion("Awe")
    mw._control_panel.set_style("Whispering")
    mw._control_panel.set_speed("Slow")
    mw._control_panel.set_pitch("Low")
    mw._control_panel.set_delivery("Expressive High")

    # Update prompt preview
    mw._update_prompt_preview()

    # Update status bar
    pass  # Model not loaded
    mw._status_bar.showMessage("Ready — mock preview mode", 3000)


def main():
    """Run the mock preview."""
    app = QApplication(sys.argv)

    # Load fonts
    load_fonts()

    # Apply theme
    apply_theme(app, "dark")

    # Create the main window with NO engine (mock mode)
    mw = MainWindow(engine=None)
    mw.resize(1440, 900)
    mw.show()

    # Populate mock data after the window is shown
    QTimer.singleShot(200, lambda: populate_mock_data(mw))

    # Save screenshots after data is populated
    def save_screenshots():
        app.processEvents()
        # Full window
        mw.grab().save(os.path.join(APP_ROOT, "mock_preview.png"))
        print(f"Saved: mock_preview.png ({mw.width()}x{mw.height()})")

        # Friendly tab
        mw._control_panel.grab().save(os.path.join(APP_ROOT, "mock_preview_friendly.png"))
        print(f"Saved: mock_preview_friendly.png")

        # Advanced tab
        mw._control_panel._switch_tab(1)
        app.processEvents()
        mw._control_panel.grab().save(os.path.join(APP_ROOT, "mock_preview_advanced.png"))
        print(f"Saved: mock_preview_advanced.png")
        mw._control_panel._switch_tab(0)
        app.processEvents()

        # Sidebar
        mw._sidebar.grab().save(os.path.join(APP_ROOT, "mock_preview_sidebar.png"))
        print(f"Saved: mock_preview_sidebar.png")

        # Top nav
        mw._top_nav.grab().save(os.path.join(APP_ROOT, "mock_preview_topnav.png"))
        print(f"Saved: mock_preview_topnav.png")

        # Editor
        mw._editor.grab().save(os.path.join(APP_ROOT, "mock_preview_editor.png"))
        print(f"Saved: mock_preview_editor.png")

        # Transport
        mw._waveform.grab().save(os.path.join(APP_ROOT, "mock_preview_transport.png"))
        print(f"Saved: mock_preview_transport.png")

        print("\n=== Mock preview screenshots saved ===")
        print("All files in the project root directory.")

        if "--offscreen" in sys.argv:
            app.quit()
        else:
            print("\nWindow is open for visual inspection. Close it to exit.")

    QTimer.singleShot(500, save_screenshots)

    # Run the event loop
    exit_code = app.exec()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()

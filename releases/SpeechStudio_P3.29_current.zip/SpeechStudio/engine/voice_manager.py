"""
SpeechStudio Engine - Voice Manager
====================================

Engine Specification, section 7:
    "VoiceManager is responsible for: Loading voice profiles, Loading
     reference audio, Loading reference transcript, Voice validation,
     Voice import, Voice export, Voice metadata.
     VoiceManager never performs speech generation."

AI Development Rules, section 10:
    "VoiceManager owns: Reference audio, Reference transcript, Voice metadata.
     No other module shall modify voice files directly."

System Specification, section 11:
    "Voice profiles reside inside voices/.
     Each profile contains: Reference audio, Reference transcript, Metadata,
     Optional preview image.
     Each profile exists independently."

Single responsibility: manage voice profile files and reference audio.
Never loads the model, never generates speech, never builds prompts.
"""

from __future__ import annotations
import os
import json
import uuid
import wave
from typing import Dict, List, Optional

from engine.logger import get_logger
from engine.errors import InvalidVoice, ReferenceAudioMissing
from engine.models import VoiceProfile

logger = get_logger("voice_manager")


class VoiceManager:
    """Manages voice profiles and their reference audio.

    Each voice profile is stored as a directory under voices/ containing:
      - profile.json   (metadata)
      - reference.wav  (reference audio, optional during creation)
      - transcript.txt (reference transcript, optional)
    """

    def __init__(self, voices_dir: str):
        self._voices_dir = voices_dir
        os.makedirs(voices_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Profile CRUD
    # ------------------------------------------------------------------
    def list_profiles(self) -> List[VoiceProfile]:
        """Return all voice profiles found in the voices directory."""
        profiles: List[VoiceProfile] = []
        if not os.path.isdir(self._voices_dir):
            return profiles
        for name in sorted(os.listdir(self._voices_dir)):
            profile_dir = os.path.join(self._voices_dir, name)
            if not os.path.isdir(profile_dir):
                continue
            profile = self._load_profile(name)
            if profile is not None:
                profiles.append(profile)
        return profiles

    def get_profile(self, profile_id: str) -> Optional[VoiceProfile]:
        """Load a single profile by id, or None if not found."""
        return self._load_profile(profile_id)

    def create_profile(self, name: str, description: str = "",
                       tags: Optional[List[str]] = None) -> VoiceProfile:
        """Create a new empty voice profile and return it.

        The profile has no reference audio until import_reference is called.
        """
        profile_id = self._make_id(name)
        profile_dir = os.path.join(self._voices_dir, profile_id)
        os.makedirs(profile_dir, exist_ok=True)

        profile = VoiceProfile(
            id=profile_id,
            name=name,
            description=description,
            tags=list(tags) if tags else [],
        )
        self._save_profile(profile)
        logger.info("Voice profile created: %s (%s)", name, profile_id)
        return profile

    def delete_profile(self, profile_id: str) -> bool:
        """Delete a voice profile and all its files."""
        profile_dir = os.path.join(self._voices_dir, profile_id)
        if not os.path.isdir(profile_dir):
            return False
        try:
            import shutil
            shutil.rmtree(profile_dir)
            logger.info("Voice profile deleted: %s", profile_id)
            return True
        except OSError as exc:
            logger.error("Failed to delete profile %s: %s",
                         profile_id, exc)
            return False

    def rename_profile(self, profile_id: str, new_name: str) -> VoiceProfile:
        """Rename a voice profile (keeps the same id and reference audio)."""
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))
        profile.name = new_name
        self._save_profile(profile)
        logger.info("Voice profile renamed: %s -> %s", profile_id, new_name)
        return profile

    # ------------------------------------------------------------------
    # Reference audio
    # ------------------------------------------------------------------
    def import_reference(self, profile_id: str, source_wav_path: str,
                         transcript: str = "") -> VoiceProfile:
        """Import a reference WAV file into a voice profile.

        The WAV is copied into the profile directory as reference.wav.
        If a transcript is provided, it is saved as transcript.txt.
        Audio metadata (sample rate, channels, duration) is detected and
        stored in the profile.
        """
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))

        if not os.path.isfile(source_wav_path):
            raise ReferenceAudioMissing(
                "Reference WAV file not found: {0}".format(source_wav_path),
            )

        dest_wav = os.path.join(self._voices_dir, profile_id, "reference.wav")
        try:
            import shutil
            shutil.copy2(source_wav_path, dest_wav)
        except OSError as exc:
            raise InvalidVoice(
                "Failed to copy reference audio: {0}".format(exc),
            ) from exc

        # Detect audio metadata using the standard wave module.
        sample_rate, channels, duration = self._read_wav_metadata(dest_wav)
        profile.reference_audio_path = os.path.relpath(dest_wav, self._get_app_root())
        profile.sample_rate = sample_rate
        profile.channels = channels
        profile.duration = duration

        if transcript:
            profile.reference_transcript = transcript
            self._save_transcript(profile_id, transcript)

        self._save_profile(profile)
        logger.info("Reference audio imported for %s: %d Hz, %d ch, %.1f s",
                    profile_id, sample_rate, channels, duration)
        return profile

    def set_transcript(self, profile_id: str, transcript: str) -> VoiceProfile:
        """Set or update the reference transcript for a profile."""
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))
        profile.reference_transcript = transcript
        self._save_transcript(profile_id, transcript)
        self._save_profile(profile)
        logger.info("Transcript updated for %s", profile_id)
        return profile

    # ------------------------------------------------------------------
    # P3.23: Avatar + speaker metadata (voice import API drift fix)
    # ------------------------------------------------------------------
    def import_avatar(self, profile_id: str, source_image_path: str) -> VoiceProfile:
        """Copy an avatar/preview image into the profile and record it.

        Previously the UI called Engine.import_voice_avatar() which did
        not exist — the import failed with AttributeError whenever an
        avatar was selected. The image is copied into the profile
        directory and referenced by the profile-safe relative filename
        stored in VoiceProfile.preview_image.

        Only image extensions are accepted (.png/.jpg/.jpeg/.webp/.gif);
        the copy never overwrites the reference audio.
        """
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))
        if not os.path.isfile(source_image_path):
            raise InvalidVoice("Avatar image not found: {0}".format(
                source_image_path))
        ext = os.path.splitext(source_image_path)[1].lower()
        if ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
            raise InvalidVoice(
                "Unsupported avatar image type: {0}".format(ext))
        import shutil
        profile_dir = os.path.join(self._voices_dir, profile_id)
        os.makedirs(profile_dir, exist_ok=True)
        dest = os.path.join(profile_dir, "avatar{0}".format(ext))
        shutil.copyfile(source_image_path, dest)
        profile.preview_image = "avatar{0}".format(ext)
        self._save_profile(profile)
        logger.info("Avatar imported for %s -> %s", profile_id, dest)
        return profile

    def set_speaker_metadata(self, profile_id: str, gender: str = "",
                             age_range: str = "", mood: str = "") -> VoiceProfile:
        """Set the speaker metadata (gender / age range / mood) on a profile.

        Previously the UI called Engine.set_voice_speaker_metadata() which
        did not exist — the whole voice import failed with AttributeError
        whenever any of these fields was filled in.
        """
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))
        if gender:
            profile.gender = str(gender)
        if age_range:
            profile.age_range = str(age_range)
        if mood:
            profile.mood = str(mood)
        self._save_profile(profile)
        logger.info("Speaker metadata updated for %s (gender=%s, age=%s, mood=%s)",
                     profile_id, gender, age_range, mood)
        return profile

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------
    def export_profile(self, profile_id: str, export_dir: str) -> str:
        """Copy a voice profile to an external directory.

        Returns the path to the exported profile directory.
        """
        profile = self.get_profile(profile_id)
        if profile is None:
            raise InvalidVoice("Voice profile not found: {0}".format(profile_id))

        profile_src = os.path.join(self._voices_dir, profile_id)
        export_path = os.path.join(export_dir, profile_id)
        os.makedirs(export_path, exist_ok=True)

        try:
            import shutil
            for fname in os.listdir(profile_src):
                src = os.path.join(profile_src, fname)
                if os.path.isfile(src):
                    shutil.copy2(src, os.path.join(export_path, fname))
            logger.info("Voice profile exported: %s -> %s", profile_id, export_path)
            return export_path
        except OSError as exc:
            raise InvalidVoice(
                "Failed to export voice profile: {0}".format(exc),
            ) from exc

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def validate(self, profile_id: str) -> List[str]:
        """Return a list of validation warnings for a voice profile.

        An empty list means the profile is valid for voice cloning.
        """
        warnings: List[str] = []
        profile = self.get_profile(profile_id)
        if profile is None:
            return ["Voice profile not found."]

        if not profile.reference_audio_path:
            warnings.append("No reference audio file.")
        else:
            full_path = os.path.join(self._get_app_root(),
                                     profile.reference_audio_path)
            if not os.path.isfile(full_path):
                warnings.append("Reference audio file is missing from disk.")
            elif profile.sample_rate <= 0:
                warnings.append("Reference audio sample rate not detected.")

        if not profile.reference_transcript.strip():
            warnings.append("No reference transcript (optional but recommended).")

        if profile.duration > 0 and profile.duration > 30.0:
            warnings.append(
                "Reference audio is {0:.1f}s long; 5-15s is optimal."
                .format(profile.duration)
            )
        return warnings

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _load_profile(self, profile_id: str) -> Optional[VoiceProfile]:
        profile_dir = os.path.join(self._voices_dir, profile_id)
        meta_path = os.path.join(profile_dir, "profile.json")
        if not os.path.isfile(meta_path):
            return None
        try:
            with open(meta_path, "r", encoding="utf-8",
                      errors="replace") as handle:
                data = json.load(handle)
            if not isinstance(data, dict):
                logger.error("Profile %s metadata is not a JSON object.",
                             profile_id)
                return None
            # Ensure paths are relative.
            data["id"] = profile_id
            return VoiceProfile.from_dict(data)
        except Exception as exc:
            # P3.25 (audit SS-M06): broad per-profile catch — a single
            # corrupt profile.json (wrong encoding, wrong types) must
            # never crash list_profiles()/get_profile() and blank the
            # whole voice library.
            logger.error("Failed to load profile %s: %s (%s)",
                         profile_id, exc, type(exc).__name__)
            return None

    def _save_profile(self, profile: VoiceProfile) -> None:
        profile_dir = os.path.join(self._voices_dir, profile.id)
        os.makedirs(profile_dir, exist_ok=True)
        meta_path = os.path.join(profile_dir, "profile.json")
        try:
            with open(meta_path, "w", encoding="utf-8") as handle:
                json.dump(profile.to_dict(), handle, indent=2, ensure_ascii=False)
        except OSError as exc:
            logger.error("Failed to save profile %s: %s",
                         profile.id, exc)
            raise

    def _save_transcript(self, profile_id: str, transcript: str) -> None:
        path = os.path.join(self._voices_dir, profile_id, "transcript.txt")
        try:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(transcript)
        except OSError as exc:
            logger.error("Failed to save transcript: %s", exc)

    @staticmethod
    def _make_id(name: str) -> str:
        """Generate a filename-safe profile id from a display name."""
        import re
        slug = re.sub(r"[^a-zA-Z0-9_-]", "_", name.strip().lower())
        slug = slug.strip("_") or "voice"
        # Append a short unique suffix to avoid collisions.
        return "{0}_{1}".format(slug, uuid.uuid4().hex[:8])

    def _get_app_root(self) -> str:
        """Return the application root.

        self._voices_dir is <app_root>/voices, so the app root is one
        directory level up.
        """
        return os.path.dirname(os.path.abspath(self._voices_dir))

    @staticmethod
    def _read_wav_metadata(wav_path: str):
        """Read sample rate, channels, and duration from a WAV file.

        Uses the standard wave module so no external dependency is needed.
        Returns (sample_rate, channels, duration_seconds).
        """
        try:
            with wave.open(wav_path, "rb") as wav:
                sample_rate = wav.getframerate()
                channels = wav.getnchannels()
                frames = wav.getnframes()
                duration = frames / float(sample_rate) if sample_rate > 0 else 0.0
                return sample_rate, channels, duration
        except Exception as exc:
            logger.warning("voice_manager: could not read WAV metadata: %s", exc)
            return 0, 0, 0.0

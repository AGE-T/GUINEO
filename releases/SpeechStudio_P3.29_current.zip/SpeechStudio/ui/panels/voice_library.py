"""
SpeechStudio Voice Library Dialog.

UI Specification, section 9:
    Voice Profile selector, Import Voice, Export Voice, Create Voice,
    Delete Voice, Reference Audio, Reference Transcript, Voice Information.
    Display: Voice name, Reference duration, Sample rate, Channels, Status.
"""

from __future__ import annotations
from typing import Optional, List

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QListWidget,
    QListWidgetItem, QPushButton, QFileDialog, QInputDialog, QMessageBox,
    QFrame, QSizePolicy,
)

from ui.theme import Palette
from engine.models import VoiceProfile


class VoiceLibraryDialog(QDialog):
    """A dialog window for managing voice profiles.

    Allows creating, importing, exporting, and deleting voice profiles,
    and displays detailed information about each profile.
    """

    voice_selected = Signal(str)  # voice_id

    def __init__(self, engine, parent=None):
        super().__init__(parent)
        self._engine = engine
        self._selected_voice_id: Optional[str] = None
        self.setWindowTitle("Voice Library")
        self.resize(700, 500)
        self.setMinimumSize(600, 400)
        self._build_ui()
        self._refresh()

    def _build_ui(self) -> None:
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # --- Left: voice list ---
        left = QVBoxLayout()
        left.setSpacing(4)

        left.addWidget(QLabel("Voice Profiles:"))

        self._list = QListWidget()
        self._list.setAlternatingRowColors(True)
        self._list.itemClicked.connect(self._on_item_clicked)
        self._list.itemDoubleClicked.connect(self._on_item_double_clicked)
        left.addWidget(self._list, 1)

        # Button row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(4)

        create_btn = QPushButton("Create")
        create_btn.setToolTip("Create a new empty voice profile")
        create_btn.clicked.connect(self._on_create)
        btn_row.addWidget(create_btn)

        import_btn = QPushButton("Import")
        import_btn.setToolTip("Import a WAV file as a new voice profile")
        import_btn.clicked.connect(self._on_import)
        btn_row.addWidget(import_btn)

        export_btn = QPushButton("Export")
        export_btn.setToolTip("Export the selected voice profile to a folder")
        export_btn.clicked.connect(self._on_export)
        btn_row.addWidget(export_btn)

        delete_btn = QPushButton("Delete")
        delete_btn.setToolTip("Delete the selected voice profile")
        delete_btn.setStyleSheet("color: %s;" % Palette.ERROR)
        delete_btn.clicked.connect(self._on_delete)
        btn_row.addWidget(delete_btn)

        left.addLayout(btn_row)
        layout.addLayout(left, 1)

        # --- Right: voice info ---
        right = QVBoxLayout()
        right.setSpacing(4)

        right.addWidget(QLabel("Voice Information:"))

        info_frame = QFrame()
        info_frame.setStyleSheet(
            "QFrame {{ background-color: {0}; border: 1px solid {1}; "
            "border-radius: 6px; padding: 8px; }}".format(
                Palette.BG_SURFACE, Palette.BORDER))
        info_layout = QGridLayout(info_frame)
        info_layout.setContentsMargins(8, 8, 8, 8)
        info_layout.setHorizontalSpacing(8)
        info_layout.setVerticalSpacing(4)

        self._name_label = QLabel("(no voice selected)")
        self._name_label.setStyleSheet("color: %s; font-weight: bold;" % Palette.TEXT_PRIMARY)
        self._duration_label = QLabel("--")
        self._sr_label = QLabel("--")
        self._channels_label = QLabel("--")
        self._status_label = QLabel("--")
        self._transcript_label = QLabel("")
        self._transcript_label.setWordWrap(True)
        self._transcript_label.setStyleSheet("color: %s;" % Palette.TEXT_SECONDARY)

        info_layout.addWidget(self._make_caption("Name:"), 0, 0)
        info_layout.addWidget(self._name_label, 0, 1)
        info_layout.addWidget(self._make_caption("Duration:"), 1, 0)
        info_layout.addWidget(self._duration_label, 1, 1)
        info_layout.addWidget(self._make_caption("Sample Rate:"), 2, 0)
        info_layout.addWidget(self._sr_label, 2, 1)
        info_layout.addWidget(self._make_caption("Channels:"), 3, 0)
        info_layout.addWidget(self._channels_label, 3, 1)
        info_layout.addWidget(self._make_caption("Status:"), 4, 0)
        info_layout.addWidget(self._status_label, 4, 1)
        info_layout.addWidget(self._make_caption("Transcript:"), 5, 0)
        info_layout.addWidget(self._transcript_label, 5, 1)
        info_layout.setColumnStretch(1, 1)
        info_layout.setRowStretch(5, 1)

        right.addWidget(info_frame, 1)

        # Validation warnings
        self._warnings_label = QLabel("")
        self._warnings_label.setWordWrap(True)
        self._warnings_label.setStyleSheet("color: %s;" % Palette.WARNING)
        right.addWidget(self._warnings_label)

        # Select button
        select_btn = QPushButton("Select This Voice")
        select_btn.setProperty("accent", "true")
        select_btn.clicked.connect(self._on_select)
        select_btn.setEnabled(False)
        self._select_btn = select_btn
        right.addWidget(select_btn)

        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        right.addWidget(close_btn)

        layout.addLayout(right, 1)

    def _make_caption(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet("color: %s;" % Palette.TEXT_SECONDARY)
        return label

    # ------------------------------------------------------------------
    # Data refresh
    # ------------------------------------------------------------------
    def _refresh(self) -> None:
        """Reload the voice list from the engine."""
        self._list.clear()
        if self._engine is None:
            return
        voices = self._engine.list_voices()
        for v in voices:
            label = v.name
            if v.duration > 0:
                label += "  ({0:.1f}s, {1} Hz)".format(v.duration, v.sample_rate)
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, v.id)
            self._list.addItem(item)

    def _on_item_clicked(self, item: QListWidgetItem) -> None:
        voice_id = item.data(Qt.ItemDataRole.UserRole)
        self._show_voice_info(voice_id)

    def _on_item_double_clicked(self, item: QListWidgetItem) -> None:
        voice_id = item.data(Qt.ItemDataRole.UserRole)
        self._show_voice_info(voice_id)
        self._on_select()

    def _show_voice_info(self, voice_id: str) -> None:
        self._selected_voice_id = voice_id
        self._select_btn.setEnabled(True)
        if self._engine is None:
            return
        voice = self._engine.get_voice(voice_id)
        if voice is None:
            return

        self._name_label.setText(voice.name)
        if voice.has_reference:
            self._duration_label.setText("{0:.2f} s".format(voice.duration))
            self._sr_label.setText("{0} Hz".format(voice.sample_rate))
            self._channels_label.setText("{0} ({1})".format(
                voice.channels,
                "mono" if voice.channels == 1 else "stereo"))
            self._status_label.setText("Has reference audio")
            self._status_label.setStyleSheet("color: %s;" % Palette.SUCCESS)
        else:
            self._duration_label.setText("--")
            self._sr_label.setText("--")
            self._channels_label.setText("--")
            self._status_label.setText("No reference audio")
            self._status_label.setStyleSheet("color: %s;" % Palette.WARNING)

        transcript = voice.reference_transcript or "(empty)"
        self._transcript_label.setText(transcript[:200])

        # Validation warnings
        warnings = self._engine._voices.validate(voice_id)
        if warnings:
            self._warnings_label.setText("\n".join("- " + w for w in warnings))
        else:
            self._warnings_label.setText("No validation warnings.")

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def _on_create(self) -> None:
        """Create a new empty voice profile."""
        name, ok = QInputDialog.getText(self, "Create Voice", "Voice name:")
        if not ok or not name.strip():
            return
        try:
            self._engine.create_voice(name.strip())
            self._refresh()
        except Exception as exc:
            QMessageBox.critical(self, "Error", "Failed to create voice: {0}".format(exc))

    def _on_import(self) -> None:
        """Import a WAV file as a new voice profile."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Import Reference Voice",
            "", "WAV Files (*.wav);;All Files (*)")
        if not file_path:
            return

        # Ask for a voice name
        import os
        default_name = os.path.splitext(os.path.basename(file_path))[0]
        name, ok = QInputDialog.getText(
            self, "Voice Name", "Name for this voice:", text=default_name)
        if not ok or not name.strip():
            return

        # Ask for an optional transcript
        transcript, ok = QInputDialog.getMultiLineText(
            self, "Reference Transcript",
            "Enter the transcript of the reference audio\n(optional but recommended):",
            "")
        if not ok:
            transcript = ""

        try:
            voice = self._engine.create_voice(name.strip())
            self._engine.import_voice_reference(
                voice.id, file_path, transcript.strip())
            QMessageBox.information(
                self, "Success",
                "Voice '{0}' imported successfully.".format(name.strip()))
            self._refresh()
        except Exception as exc:
            QMessageBox.critical(self, "Error",
                                 "Failed to import voice: {0}".format(exc))

    def _on_export(self) -> None:
        """Export the selected voice profile to a folder."""
        if self._selected_voice_id is None:
            QMessageBox.warning(self, "Export", "Select a voice to export first.")
            return

        export_dir = QFileDialog.getExistingDirectory(
            self, "Select Export Folder")
        if not export_dir:
            return

        try:
            path = self._engine._voices.export_profile(
                self._selected_voice_id, export_dir)
            QMessageBox.information(
                self, "Success",
                "Voice exported to:\n{0}".format(path))
        except Exception as exc:
            QMessageBox.critical(self, "Error",
                                 "Failed to export voice: {0}".format(exc))

    def _on_delete(self) -> None:
        """Delete the selected voice profile."""
        if self._selected_voice_id is None:
            QMessageBox.warning(self, "Delete", "Select a voice to delete first.")
            return

        voice = self._engine.get_voice(self._selected_voice_id)
        if voice is None:
            return

        reply = QMessageBox.question(
            self, "Delete Voice",
            "Are you sure you want to delete '{0}'?\n"
            "This cannot be undone.".format(voice.name),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        try:
            self._engine.delete_voice(self._selected_voice_id)
            self._selected_voice_id = None
            self._select_btn.setEnabled(False)
            self._refresh()
            self._clear_info()
        except Exception as exc:
            QMessageBox.critical(self, "Error",
                                 "Failed to delete voice: {0}".format(exc))

    def _on_select(self) -> None:
        """Select the current voice and close the dialog."""
        if self._selected_voice_id:
            self.voice_selected.emit(self._selected_voice_id)
            self.accept()

    def _clear_info(self) -> None:
        self._name_label.setText("(no voice selected)")
        self._duration_label.setText("--")
        self._sr_label.setText("--")
        self._channels_label.setText("--")
        self._status_label.setText("--")
        self._transcript_label.setText("")
        self._warnings_label.setText("")

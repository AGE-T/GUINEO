"""Voice import dialog (Phase 2.2 redesign).

A proper dialog with fields for:
    - Name
    - WAV file (Browse button)
    - Avatar image (Browse button, optional)
    - Gender (dropdown: Male / Female / Neutral)
    - Age range (dropdown: Child / Teen / 20s / 30s / 40s / 50s / 60s / Old)
    - Mood (free text, e.g. "Calm", "Energetic", "Tired")
    - Reference transcript (multiline, optional)

Replaces the old QInputDialog-based flow in MainWindow._on_import_voice.
"""

from __future__ import annotations
import os
from typing import Optional, Tuple

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QHBoxLayout, QLineEdit,
    QPushButton, QLabel, QComboBox, QTextEdit, QFileDialog,
    QDialogButtonBox, QSizePolicy, QWidget,
)

from ui.theme import Palette
from ui.widgets.avatar import AvatarLabel


# Age range options for the dropdown. Empty string = "unspecified".
AGE_OPTIONS = [
    "",
    "Child",
    "Teen",
    "20s",
    "30s",
    "40s",
    "50s",
    "60s",
    "Old",
]

# Gender options for the dropdown. Empty string = "unspecified".
GENDER_OPTIONS = ["", "Male", "Female", "Neutral"]


class VoiceImportDialog(QDialog):
    """Modal dialog for importing a new voice profile.

    After accept(), call :meth:`values` to get a dict with keys:
        name, wav_path, avatar_path, gender, age_range, mood, transcript.
    """

    def __init__(self, default_name: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Import Voice Profile")
        self.setMinimumWidth(460)
        self._avatar_path = ""
        self._wav_path = ""
        self._build_ui(default_name)

    def _build_ui(self, default_name: str) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Header
        header = QLabel("Import a new voice profile from a reference WAV.")
        header.setStyleSheet("color: {0}; font-size: 12px;".format(Palette.TEXT_SECONDARY))
        header.setWordWrap(True)
        layout.addWidget(header)

        # Form
        form = QFormLayout()
        form.setSpacing(8)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        # Name
        self._name_edit = QLineEdit(default_name)
        self._name_edit.setPlaceholderText("e.g. Captain")
        form.addRow("Name:", self._name_edit)

        # WAV file row (line edit + Browse)
        wav_row = QHBoxLayout()
        wav_row.setSpacing(4)
        self._wav_edit = QLineEdit()
        self._wav_edit.setPlaceholderText("reference.wav")
        self._wav_edit.setReadOnly(True)
        wav_row.addWidget(self._wav_edit, 1)
        wav_browse = QPushButton("Browse...")
        wav_browse.clicked.connect(self._browse_wav)
        wav_row.addWidget(wav_browse)
        wav_container = QWidget()
        wav_container.setLayout(wav_row)
        form.addRow("WAV file:", wav_container)

        # Avatar row (preview + line edit + Browse + Clear)
        avatar_row = QHBoxLayout()
        avatar_row.setSpacing(8)
        self._avatar_preview = AvatarLabel(size=44)
        avatar_row.addWidget(self._avatar_preview)

        # Right column: line edit on top, buttons below.
        avatar_right = QVBoxLayout()
        avatar_right.setSpacing(2)
        self._avatar_edit = QLineEdit()
        self._avatar_edit.setPlaceholderText("avatar.png (optional)")
        self._avatar_edit.setReadOnly(True)
        avatar_right.addWidget(self._avatar_edit)

        avatar_btn_row = QHBoxLayout()
        avatar_btn_row.setSpacing(4)
        avatar_browse = QPushButton("Browse...")
        avatar_browse.clicked.connect(self._browse_avatar)
        avatar_btn_row.addWidget(avatar_browse)
        avatar_clear = QPushButton("Clear")
        avatar_clear.clicked.connect(self._clear_avatar)
        avatar_btn_row.addWidget(avatar_clear)
        avatar_btn_row.addStretch()
        avatar_btns = QWidget()
        avatar_btns.setLayout(avatar_btn_row)
        avatar_right.addWidget(avatar_btns)

        avatar_right_w = QWidget()
        avatar_right_w.setLayout(avatar_right)
        avatar_row.addWidget(avatar_right_w, 1)
        avatar_container = QWidget()
        avatar_container.setLayout(avatar_row)
        form.addRow("Avatar:", avatar_container)

        # Gender
        self._gender_combo = QComboBox()
        self._gender_combo.addItems(GENDER_OPTIONS)
        form.addRow("Gender:", self._gender_combo)

        # Age range
        self._age_combo = QComboBox()
        self._age_combo.addItems(AGE_OPTIONS)
        form.addRow("Age:", self._age_combo)

        # Mood (free text)
        self._mood_edit = QLineEdit()
        self._mood_edit.setPlaceholderText("e.g. Calm, Energetic, Tired")
        form.addRow("Mood:", self._mood_edit)

        layout.addLayout(form)

        # Transcript
        layout.addWidget(QLabel("Reference transcript (optional):"))
        self._transcript_edit = QTextEdit()
        self._transcript_edit.setPlaceholderText(
            "The transcript of the reference audio. Recommended for best voice cloning quality.")
        self._transcript_edit.setMinimumHeight(80)
        self._transcript_edit.setMaximumHeight(140)
        layout.addWidget(self._transcript_edit)

        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Ok)
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    # ------------------------------------------------------------------
    # Browse handlers
    # ------------------------------------------------------------------
    def _browse_wav(self) -> None:
        start_dir = os.path.join(os.getcwd(), "voices")
        if not os.path.isdir(start_dir):
            start_dir = os.getcwd()
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Reference WAV", start_dir,
            "WAV Files (*.wav);;All Files (*)")
        if path:
            self._wav_path = os.path.normpath(path)
            self._wav_edit.setText(self._wav_path)
            # If the name is empty, prefill it from the filename.
            if not self._name_edit.text().strip():
                base = os.path.splitext(os.path.basename(self._wav_path))[0]
                self._name_edit.setText(base)

    def _browse_avatar(self) -> None:
        start_dir = os.path.join(os.getcwd(), "voices")
        if not os.path.isdir(start_dir):
            start_dir = os.getcwd()
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Avatar Image", start_dir,
            "Images (*.png *.jpg *.jpeg *.webp *.bmp *.gif);;All Files (*)")
        if path:
            self._avatar_path = os.path.normpath(path)
            self._avatar_edit.setText(self._avatar_path)
            # Update the preview.
            from engine.models import VoiceProfile
            tmp = VoiceProfile(id="_tmp", name=self._name_edit.text().strip() or "?",
                               preview_image=self._avatar_path)
            self._avatar_preview.set_voice(tmp)

    def _clear_avatar(self) -> None:
        self._avatar_path = ""
        self._avatar_edit.setText("")
        self._avatar_preview.set_voice(None)

    # ------------------------------------------------------------------
    # Accept / validate
    # ------------------------------------------------------------------
    def _on_accept(self) -> None:
        """Validate inputs before accepting."""
        name = self._name_edit.text().strip()
        if not name:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Missing name",
                                "Please enter a name for the voice profile.")
            return
        if not self._wav_path or not os.path.isfile(self._wav_path):
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Missing WAV file",
                                "Please select a reference WAV file.")
            return
        self.accept()

    # ------------------------------------------------------------------
    # Result accessor
    # ------------------------------------------------------------------
    def values(self) -> dict:
        """Return the dialog's values as a dict (call after accept())."""
        return {
            "name": self._name_edit.text().strip(),
            "wav_path": self._wav_path,
            "avatar_path": self._avatar_path,
            "gender": self._gender_combo.currentText(),
            "age_range": self._age_combo.currentText(),
            "mood": self._mood_edit.text().strip(),
            "transcript": self._transcript_edit.toPlainText().strip(),
        }

"""
SpeechStudio Reference Audio Panel.

UI Specification, section 15:
    Reference WAV, Reference Transcript, Trim Reference, Normalize, Refresh.
    Display: Duration, Sample Rate, Channels, File Name, Validation Status.
"""

from __future__ import annotations
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit,
    QTextEdit, QPushButton, QFrame,
)

from ui.theme import Palette
from engine.models import VoiceProfile


class ReferenceAudioPanel(QWidget):
    """Panel showing reference audio info and transcript for a voice profile.

    UI Specification section 15:
        - Reference WAV (file path display)
        - Reference Transcript (editable text area)
        - Trim Reference (button)
        - Normalize (button)
        - Refresh (button)
        - Display: Duration, Sample Rate, Channels, File Name, Validation Status
    """

    transcript_changed = Signal(str)
    trim_requested = Signal()
    normalize_requested = Signal()
    refresh_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_voice: Optional[VoiceProfile] = None
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # --- Metadata grid ---
        info_grid = QGridLayout()
        info_grid.setContentsMargins(0, 0, 0, 0)
        info_grid.setHorizontalSpacing(8)
        info_grid.setVerticalSpacing(2)

        self._file_label = QLabel("(no file)")
        self._file_label.setStyleSheet("color: %s;" % Palette.TEXT_PRIMARY)
        self._duration_label = QLabel("--")
        self._sr_label = QLabel("--")
        self._channels_label = QLabel("--")
        self._status_label = QLabel("No voice selected")
        self._status_label.setStyleSheet("color: %s;" % Palette.TEXT_SECONDARY)

        info_grid.addWidget(self._make_caption("File:"), 0, 0)
        info_grid.addWidget(self._file_label, 0, 1)
        info_grid.addWidget(self._make_caption("Duration:"), 1, 0)
        info_grid.addWidget(self._duration_label, 1, 1)
        info_grid.addWidget(self._make_caption("Sample Rate:"), 2, 0)
        info_grid.addWidget(self._sr_label, 2, 1)
        info_grid.addWidget(self._make_caption("Channels:"), 3, 0)
        info_grid.addWidget(self._channels_label, 3, 1)
        info_grid.addWidget(self._make_caption("Status:"), 4, 0)
        info_grid.addWidget(self._status_label, 4, 1)
        info_grid.setColumnStretch(1, 1)
        layout.addLayout(info_grid)

        # --- Button row ---
        btn_row = QHBoxLayout()
        btn_row.setSpacing(4)

        self._trim_btn = QPushButton("Trim")
        self._trim_btn.setToolTip("Trim silence from the start and end of the reference audio")
        self._trim_btn.setEnabled(False)
        self._trim_btn.clicked.connect(self.trim_requested.emit)
        btn_row.addWidget(self._trim_btn)

        self._normalize_btn = QPushButton("Normalize")
        self._normalize_btn.setToolTip("Normalize the reference audio volume")
        self._normalize_btn.setEnabled(False)
        self._normalize_btn.clicked.connect(self.normalize_requested.emit)
        btn_row.addWidget(self._normalize_btn)

        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.setToolTip("Re-read the reference audio metadata from disk")
        self._refresh_btn.setEnabled(False)
        self._refresh_btn.clicked.connect(self.refresh_requested.emit)
        btn_row.addWidget(self._refresh_btn)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        # --- Transcript editor ---
        layout.addWidget(self._make_caption("Reference Transcript:"))
        self._transcript = QTextEdit()
        self._transcript.setPlaceholderText(
            "Enter the transcript of the reference audio...\n"
            "This text should match what is spoken in the reference WAV."
        )
        self._transcript.setMaximumHeight(100)
        self._transcript.textChanged.connect(self._on_transcript_changed)
        layout.addWidget(self._transcript)

    def _make_caption(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet("color: %s;" % Palette.TEXT_SECONDARY)
        return label

    def _on_transcript_changed(self) -> None:
        self.transcript_changed.emit(self._transcript.toPlainText())

    # ------------------------------------------------------------------
    # Update methods
    # ------------------------------------------------------------------
    def update_voice(self, voice: Optional[VoiceProfile]) -> None:
        """Update the panel with a voice profile's reference audio info."""
        self._current_voice = voice

        if voice is None or not voice.has_reference:
            self._file_label.setText("(no reference audio)")
            self._duration_label.setText("--")
            self._sr_label.setText("--")
            self._channels_label.setText("--")
            self._status_label.setText("No reference audio")
            self._status_label.setStyleSheet("color: %s;" % Palette.WARNING)
            self._transcript.setPlainText(voice.reference_transcript if voice else "")
            self._trim_btn.setEnabled(False)
            self._normalize_btn.setEnabled(False)
            self._refresh_btn.setEnabled(False)
            return

        # Populate metadata
        import os
        fname = os.path.basename(voice.reference_audio_path)
        self._file_label.setText(fname)
        self._file_label.setToolTip(voice.reference_audio_path)
        self._duration_label.setText("{0:.2f} s".format(voice.duration))
        self._sr_label.setText("{0} Hz".format(voice.sample_rate))
        self._channels_label.setText("{0} ({1})".format(
            voice.channels,
            "mono" if voice.channels == 1 else "stereo"))
        self._status_label.setText("Valid")
        self._status_label.setStyleSheet("color: %s;" % Palette.SUCCESS)

        self._transcript.setPlainText(voice.reference_transcript)

        self._trim_btn.setEnabled(True)
        self._normalize_btn.setEnabled(True)
        self._refresh_btn.setEnabled(True)

    def set_validation_warnings(self, warnings: list) -> None:
        """Show validation warnings in the status line."""
        if not warnings:
            self._status_label.setText("Valid")
            self._status_label.setStyleSheet("color: %s;" % Palette.SUCCESS)
        else:
            self._status_label.setText("Warnings: {0}".format(len(warnings)))
            self._status_label.setStyleSheet("color: %s;" % Palette.WARNING)
            self._status_label.setToolTip("\n".join(warnings))

    def get_transcript(self) -> str:
        return self._transcript.toPlainText()

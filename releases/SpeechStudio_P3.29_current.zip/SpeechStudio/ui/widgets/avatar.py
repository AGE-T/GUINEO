"""Rounded avatar widget used in the sidebar and control panel.

Renders a circular avatar image from a voice profile's ``preview_image``
path. If no image is available, falls back to a colored circle with the
voice's first initial — matching the HTML prototype's "rounded-full" avatar
style.

Used by:
    - ui/panels/sidebar.py    — voice list rows
    - ui/panels/control_panel.py — voice card at the top of the panel
"""

from __future__ import annotations
import os
from typing import Optional

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import (
    QPixmap, QPainter, QPainterPath, QColor, QFont, QPen, QBrush,
)
from PySide6.QtWidgets import QLabel

from ui.theme import Palette


# Deterministic colors for fallback initial-avatars. Indexed by the first
# character's lowercase ordinal. All colors are from the HTML prototype's
# speaker palette (blue, purple, orange, green, red, pink, cyan, dark orange).
AVATAR_COLORS = [
    "#3B82F6",  # blue
    "#8B5CF6",  # purple
    "#F59E0B",  # orange
    "#10B981",  # green
    "#EF4444",  # red
    "#EC4899",  # pink
    "#06B6D4",  # cyan
    "#F97316",  # dark orange
]


def _color_for_name(name: str) -> str:
    """Pick a deterministic avatar color from a name."""
    if not name:
        return AVATAR_COLORS[0]
    return AVATAR_COLORS[ord(name[0].lower()) % len(AVATAR_COLORS)]


def make_rounded_pixmap(image_path: str, size: int = 40,
                        fallback_name: str = "") -> Optional[QPixmap]:
    """Load an image and return a circular, size×size QPixmap.

    Returns None if the image cannot be loaded. In that case the caller
    should use :func:`make_initial_pixmap` as a fallback.
    """
    if not image_path or not os.path.isfile(image_path):
        return None
    src = QPixmap(image_path)
    if src.isNull():
        return None

    # Scale to fill the circle (KeepAspectRatioByExpansion crops evenly).
    scaled = src.scaled(
        size, size,
        Qt.AspectRatioMode.KeepAspectRatioByExpansion,
        Qt.TransformationMode.SmoothTransformation,
    )

    # Composite onto a transparent circular mask.
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    painter = QPainter(out)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    path.addEllipse(QRectF(0, 0, size, size))
    painter.setClipPath(path)
    # Center the scaled source in case aspect expansion produced a slightly
    # larger pixmap than requested.
    x = (scaled.width() - size) // 2
    y = (scaled.height() - size) // 2
    painter.drawPixmap(0, 0, scaled, x, y, size, size)
    painter.end()
    return out


def make_initial_pixmap(initial: str, size: int = 40,
                        color: str = "") -> QPixmap:
    """Render a colored circle with a single character (initial) inside.

    Used as a fallback when no avatar image is available.
    """
    if not color:
        color = _color_for_name(initial)
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    painter = QPainter(out)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    # Filled circle background.
    painter.setBrush(QBrush(QColor(color)))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawEllipse(QRectF(0, 0, size, size))

    # Initial character — white, bold, centered.
    painter.setPen(QColor("#FFFFFF"))
    font = QFont("Segoe UI", max(10, size // 3), QFont.Weight.Bold)
    painter.setFont(font)
    char = (initial.strip()[:1] or "?").upper()
    painter.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, char)
    painter.end()
    return out


class AvatarLabel(QLabel):
    """A QLabel that displays a circular avatar.

    Call :meth:`set_voice` with a VoiceProfile (or None) to update the
    avatar. If the profile has a ``preview_image`` that exists on disk,
    the image is rendered as a circle. Otherwise a colored circle with
    the voice name's first initial is shown.
    """

    def __init__(self, size: int = 40, parent=None):
        super().__init__(parent)
        self._size = size
        self.setFixedSize(size, size)
        self._clear()

    def _clear(self) -> None:
        """Show a neutral placeholder (grey circle with '?')."""
        out = QPixmap(self._size, self._size)
        out.fill(Qt.GlobalColor.transparent)
        painter = QPainter(out)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QBrush(QColor(Palette.BG_RAISED)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QRectF(0, 0, self._size, self._size))
        painter.setPen(QColor(Palette.TEXT_SECONDARY))
        font = QFont("Segoe UI", max(10, self._size // 3), QFont.Weight.Bold)
        painter.setFont(font)
        painter.drawText(QRectF(0, 0, self._size, self._size),
                         Qt.AlignmentFlag.AlignCenter, "?")
        painter.end()
        self.setPixmap(out)

    def set_voice(self, voice) -> None:
        """Update the avatar from a VoiceProfile (or None).

        Args:
            voice: a VoiceProfile with optional ``preview_image`` and
                   ``name`` fields, or None to show the placeholder.
        """
        if voice is None:
            self._clear()
            return

        # Resolve the avatar image path (preview_image is relative to the
        # application root — the same convention as reference_audio_path).
        image_path = ""
        if getattr(voice, "preview_image", ""):
            # Try absolute first, then relative to cwd (which is the app
            # root when SpeechStudio is launched).
            preview = voice.preview_image
            if os.path.isabs(preview) and os.path.isfile(preview):
                image_path = preview
            else:
                cwd = os.getcwd()
                candidate = os.path.join(cwd, preview)
                if os.path.isfile(candidate):
                    image_path = candidate

        if image_path:
            pix = make_rounded_pixmap(image_path, self._size, voice.name)
            if pix is not None:
                self.setPixmap(pix)
                return
        # Fallback: colored circle with initial.
        self.setPixmap(make_initial_pixmap(voice.name, self._size))

"""
SpeechStudio — P3.12/P3.17 Scene ID + Human-Friendly Audio Filename Tests
==========================================================================

Tests that every generated audio filename:
  1. Contains the Scene ID (compact suffix for uniqueness)
  2. Contains the Project name (human-readable)
  3. Contains the Scene name (human-readable)
  4. Contains the Part number (zero-padded)
  5. Multi-speaker filenames include the speaker
  6. Same-name Scenes produce distinct filenames
  7. Names are normalized for Windows filesystem compatibility

Run:
    LD_LIBRARY_PATH=/tmp QT_QPA_PLATFORM=offscreen python3 -m pytest tests/test_p3_12_scene_id_filenames.py -v
"""

from __future__ import annotations
import os
import sys
import unittest

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)


class TestSceneIdInFilenames(unittest.TestCase):
    """P3.12/P3.17: Generated audio filenames must contain Scene ID + human-readable names."""

    def test_filename_format_contains_project_scene_part(self):
        """The filename pattern must include Project_Scene_Part format."""
        with open(os.path.join(_ROOT, "ui/main_window.py")) as f:
            src = f.read()
        # P3.17: New format uses proj_name, scene_name, Part_NN
        self.assertIn("proj_name", src, "Filename must use project name")
        self.assertIn("scene_name", src, "Filename must use scene name")
        self.assertIn("Part_{2:02d}", src, "Filename must use Part_NN format")
        # Old format must be gone
        self.assertNotIn('"long_narration_part{0:02d}.wav"', src,
                         "Old format must be removed")

    def test_filename_normalization_exists(self):
        """Filename normalization must exist for Windows compatibility."""
        with open(os.path.join(_ROOT, "ui/main_window.py")) as f:
            src = f.read()
        self.assertIn("_normalize_filename", src)
        self.assertIn(r'[\\/:*?"<>|\s]+', src,
                      "Must replace Windows-invalid characters")

    def test_scene_id_suffix_for_uniqueness(self):
        """Filename must include a compact scene_id suffix for uniqueness."""
        with open(os.path.join(_ROOT, "ui/main_window.py")) as f:
            src = f.read()
        self.assertIn("scene_id_short", src,
                      "Must include compact scene_id suffix")

    def test_scene_a_part1_contains_scene_a_id(self):
        """Scene A → Part 1 filename must contain Scene A's ID (compact)."""
        scene_a_id = "abc123de"
        proj_name = "Eden"
        scene_name = "Ciklonok"
        i = 0
        filename = "{0}_{1}_Part_{2:02d}_{3}.wav".format(
            proj_name, scene_name, i + 1, scene_a_id)
        self.assertIn(scene_a_id, filename)
        self.assertIn(proj_name, filename)
        self.assertIn(scene_name, filename)
        self.assertIn("Part_01", filename)

    def test_scene_b_part1_contains_scene_b_id(self):
        """Scene B → Part 1 filename must contain Scene B's ID."""
        scene_b_id = "xyz789gh"
        proj_name = "Eden"
        scene_name = "Vihar"
        i = 0
        filename = "{0}_{1}_Part_{2:02d}_{3}.wav".format(
            proj_name, scene_name, i + 1, scene_b_id)
        self.assertIn(scene_b_id, filename)
        self.assertIn("Part_01", filename)

    def test_same_name_scenes_produce_distinct_filenames(self):
        """Two Scenes with identical names but different IDs produce distinct filenames."""
        scene1_id = "id_1111"
        scene2_id = "id_2222"
        proj_name = "Eden"
        scene_name = "Scene_01"
        i = 0
        filename1 = "{0}_{1}_Part_{2:02d}_{3}.wav".format(
            proj_name, scene_name, i + 1, scene1_id)
        filename2 = "{0}_{1}_Part_{2:02d}_{3}.wav".format(
            proj_name, scene_name, i + 1, scene2_id)
        self.assertNotEqual(filename1, filename2,
                            "Same-name scenes must produce distinct filenames")

    def test_multi_speaker_filename_contains_speaker(self):
        """Multi-speaker filenames must include the speaker name."""
        proj_name = "Eden"
        scene_name = "Ciklonok"
        scene_id = "abc123de"
        i = 0
        speaker = "Engineer"
        filename = "{0}_{1}_Part_{2:02d}_{3}_{4}.wav".format(
            proj_name, scene_name, i + 1, speaker, scene_id)
        self.assertIn(proj_name, filename)
        self.assertIn(scene_name, filename)
        self.assertIn("Part_01", filename)
        self.assertIn(speaker, filename)
        self.assertIn(scene_id, filename)

    def test_no_scene_fallback(self):
        """When no active scene, filename should still work."""
        proj_name = "Project"
        scene_name = "Scene"
        i = 0
        scene_id_short = ""
        filename = "{0}_{1}_Part_{2:02d}{3}.wav".format(
            proj_name, scene_name, i + 1, scene_id_short)
        self.assertEqual(filename, "Project_Scene_Part_01.wav")

    def test_filename_collision_handling_still_works(self):
        """Filename collision handling (unique suffix) must still work."""
        from engine.project_exporter import _unique_dir
        import tempfile, os, shutil
        tmpdir = tempfile.mkdtemp()
        try:
            base = "Eden_Ciklonok_Part_01_abc123de"
            os.makedirs(os.path.join(tmpdir, base))
            result = _unique_dir(tmpdir, base)
            self.assertTrue(result.endswith("_2"),
                            "Collision should produce _2 suffix: {0}".format(result))
        finally:
            shutil.rmtree(tmpdir)

    def test_audioasset_output_path_consistency(self):
        """AudioAsset.output_path must use the same filename format."""
        from engine.models import AudioAsset
        asset = AudioAsset(
            scene_id="scene_test",
            output_path="outputs/Eden_Ciklonok_Part_01_abc123de.wav",
            duration=2.0,
        )
        self.assertIn("Eden", asset.output_path)
        self.assertIn("Ciklonok", asset.output_path)
        self.assertIn("Part_01", asset.output_path)

    def test_history_entry_output_path_consistency(self):
        """HistoryEntry.output_path must use the same filename format."""
        from engine.history_manager import HistoryManager
        from engine.models import GenerationResult
        import tempfile, shutil
        tmpdir = tempfile.mkdtemp()
        try:
            hm = HistoryManager(tmpdir)
            r = GenerationResult(
                success=True,
                output_path="outputs/Eden_Ciklonok_Part_01_abc123de.wav",
                prompt="test",
                generation_time=1.0,
                output_duration=2.0,
            )
            r.timestamp = "20240101_120000"
            r.project = "Eden"
            entry_id = hm.add(r)
            entry = hm.get_entry(entry_id)
            self.assertIn("Eden", entry.output_path)
            self.assertIn("Part_01", entry.output_path)
        finally:
            shutil.rmtree(tmpdir)

    def test_windows_unsafe_chars_normalized(self):
        """Windows-unsafe characters must be normalized in filenames."""
        import re
        def _normalize(name):
            safe = re.sub(r'[\\/:*?"<>|\s]+', '_', name.strip())
            safe = re.sub(r'_+', '_', safe)
            safe = safe.strip('_.')
            return safe or "untitled"

        # Test various unsafe names
        self.assertEqual(_normalize("My Book: Part 1"), "My_Book_Part_1")
        self.assertEqual(_normalize("Chapter 03 / Storm"), "Chapter_03_Storm")
        self.assertEqual(_normalize('Test"Quote'), "Test_Quote")
        self.assertEqual(_normalize("  spaces  "), "spaces")
        self.assertEqual(_normalize(""), "untitled")


if __name__ == "__main__":
    unittest.main(verbosity=2)

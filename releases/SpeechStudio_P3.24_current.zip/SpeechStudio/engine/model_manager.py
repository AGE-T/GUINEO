"""
SpeechStudio Engine - Model Manager
====================================

Engine Specification, section 5:
    "ModelManager responsibilities: Load tokenizer, Load model, Unload model,
     Warmup model, Report model status, Report CUDA information.
     The ModelManager owns the only model instance."

Generation Engine Specification, section 4 (Model Lifecycle):
    "The model shall be loaded once during application startup.
     The model shall remain in GPU memory until the application exits.
     The model shall never be reloaded between generations.
     The tokenizer shall be loaded once."

AI Development Rules, section 8:
    "Exactly one model instance exists. Exactly one tokenizer exists.
     The model is loaded once. The tokenizer is loaded once.
     The model remains resident until application shutdown."

Generation Engine Specification, section 2:
    "The Generation Engine is the only component allowed to communicate
     with the Transformers model."

Memory Ownership (Engine Specification section 20):
    "ModelManager owns: Model, Tokenizer."

Single responsibility: own and manage the model + tokenizer lifecycle.
Never builds prompts, never manages voices, never writes audio files.
"""

from __future__ import annotations
import os
import threading
from typing import Optional, Tuple

from engine.logger import get_logger
from engine.errors import (
    ModelNotLoaded, ModelLoadFailed, CudaUnavailable, TokenizerMissing,
)
from engine.models import ModelStatus
from engine.events import EventBus, EventType, Event

logger = get_logger("model_manager")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
# Generation Engine Specification section 5: supported backend.
MODEL_ID = "multimodalart/higgs-audio-v3-tts-4b-transformers"
DEFAULT_MODEL_DTYPE = "bfloat16"  # bf16 recommended per the Transformers port README
HIGGS_SAMPLE_RATE = 24000  # Output is mono 24 kHz (verified from model card).

# Maps the settings string to the torch dtype object.
_DTYPE_MAP = {
    "bfloat16": "torch.bfloat16",
    "float16": "torch.float16",
    "float32": "torch.float32",
}


class ModelManager:
    """Owns the single model and tokenizer instance.

    Enforces the single-instance rule: the model is loaded once and stays
    resident until unload() is called at shutdown. All Transformers imports
    are lazy so the engine can be imported before torch is installed.

    The model is loaded from a local directory (models/higgs-audio-v3/)
    that was populated by bootstrap.py. This avoids Windows symlink issues
    with the HuggingFace cache system.

    Thread safety: load() and unload() are guarded by a lock so concurrent
    calls from the UI thread and worker threads cannot corrupt state.
    """

    def __init__(self, event_bus: EventBus, model_path: str,
                 settings_manager=None):
        """Initialise the ModelManager.

        Args:
            event_bus: the engine event bus for status notifications.
            model_path: path to the local directory containing the model
                        files (populated by bootstrap.py).
            settings_manager: optional SettingsManager for model_precision.
        """
        self._event_bus = event_bus
        self._model_path = model_path
        self._settings = settings_manager
        self._lock = threading.RLock()

        # The single model and tokenizer instances (None until loaded).
        self._model = None
        self._tokenizer = None
        self._device = None       # "cuda" or "cpu"
        self._loading = False

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def load(self, use_cuda: bool = True) -> ModelStatus:
        """Load the model and tokenizer into memory.

        This is a potentially long operation (10-60 seconds depending on
        hardware). It should be called on a worker thread, not the UI
        thread (AI Development Rules section 11).

        Args:
            use_cuda: if True, prefer CUDA; fall back to CPU if unavailable.

        Returns:
            The current ModelStatus after loading.
        """
        with self._lock:
            if self._model is not None and self._tokenizer is not None:
                logger.info("Model already loaded; skipping.")
                return self.status()

            # Verify the model path exists.
            import os
            if not os.path.isdir(self._model_path):
                self._loading = False
                raise ModelLoadFailed(
                    "Model directory not found: {0}. Run launch.bat to download the model.".format(
                        self._model_path),
                    "Run launch.bat so bootstrap can download the model.",
                )

            config_file = os.path.join(self._model_path, "config.json")
            if not os.path.isfile(config_file):
                self._loading = False
                raise ModelLoadFailed(
                    "config.json not found in {0}. The model download may be incomplete.".format(
                        self._model_path),
                    "Re-run launch.bat to complete the model download.",
                )

            self._loading = True
            self._event_bus.emit(Event(EventType.ENGINE_STATUS_CHANGED,
                                       self.status()))

            try:
                # --- Lazy imports ---
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer

                # --- CUDA check ---
                if use_cuda and torch.cuda.is_available():
                    self._device = "cuda"
                    gpu_name = torch.cuda.get_device_name(0)
                    logger.info("CUDA available. GPU: %s", gpu_name)
                elif use_cuda:
                    logger.warning("CUDA requested but unavailable; falling back to CPU.")
                    self._device = "cpu"
                else:
                    self._device = "cpu"

                # --- Load tokenizer ---
                # Load from the local directory (populated by bootstrap).
                logger.info("Loading tokenizer from %s ...", self._model_path)
                self._tokenizer = AutoTokenizer.from_pretrained(
                    self._model_path,
                    trust_remote_code=True,
                )
                logger.info("Tokenizer loaded.")

                # --- Load model ---
                # Per the Transformers port README:
                #   model = AutoModelForCausalLM.from_pretrained(
                #       repo, trust_remote_code=True, dtype=torch.bfloat16
                #   ).to("cuda").eval()
                #
                # Note: transformers 5.x accepts both 'dtype' and 'torch_dtype'.
                # We try 'torch_dtype' first (more widely compatible) and fall
                # back to 'dtype'.
                precision_str = self._get_precision_setting()
                dtype = self._resolve_dtype(torch, precision_str)

                logger.info("Loading model from %s (precision=%s, device=%s) ...",
                            self._model_path, precision_str, self._device)

                try:
                    logger.info("Calling from_pretrained(dtype=%s) ...", precision_str)
                    self._model = AutoModelForCausalLM.from_pretrained(
                        self._model_path,
                        trust_remote_code=True,
                        dtype=dtype,
                    )
                    logger.info("from_pretrained returned successfully.")
                except TypeError:
                    logger.info("dtype not accepted; trying torch_dtype parameter...")
                    self._model = AutoModelForCausalLM.from_pretrained(
                        self._model_path,
                        trust_remote_code=True,
                        torch_dtype=dtype,
                    )
                    logger.info("from_pretrained (torch_dtype) returned successfully.")
                except Exception as exc:
                    logger.exception("from_pretrained FAILED: %s", exc)
                    raise

                self._model = self._model.to(self._device)
                self._model.eval()
                logger.info("Model loaded (dtype=%s) and moved to %s.",
                            precision_str, self._device)

                self._loading = False
                self._event_bus.emit(Event(EventType.MODEL_LOADED, self.status()))
                return self.status()

            except Exception as exc:
                self._loading = False
                logger.exception("Model load failed: %s", exc)
                # Clean up partial state.
                self._model = None
                self._tokenizer = None
                raise ModelLoadFailed(
                    "Failed to load the model: {0}".format(exc),
                ) from exc

    def warmup(self) -> None:
        """Run a minimal generation to warm up the model (CUDA kernels).

        Per System Specification section 4 startup sequence: "Model Warmup".
        This should be called after load() and before the first real
        generation. It is optional but recommended for consistent timing.
        """
        with self._lock:
            if self._model is None or self._tokenizer is None:
                raise ModelNotLoaded("Cannot warmup: model is not loaded.")

            logger.info("Warming up model with a short test generation ...")
            try:
                # Run a very short generation to initialise CUDA kernels.
                _ = self._model.generate_speech(
                    "Warmup.",
                    self._tokenizer,
                    max_new_tokens=128,
                )
                logger.info("Model warmup complete.")
            except Exception as exc:
                logger.warning("model_manager: Warmup failed (non-fatal): %s", exc)

    # ------------------------------------------------------------------
    # Unloading
    # ------------------------------------------------------------------
    def unload(self) -> None:
        """Release the model and tokenizer from memory.

        Called during application shutdown (System Specification section 19).
        """
        with self._lock:
            if self._model is None and self._tokenizer is None:
                return
            logger.info("Unloading model and tokenizer ...")
            self._model = None
            self._tokenizer = None
            self._device = None

            # Attempt to free GPU memory.
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except ImportError:
                pass

            self._event_bus.emit(Event(EventType.MODEL_UNLOADED))
            logger.info("Model and tokenizer unloaded.")

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------
    def status(self) -> ModelStatus:
        """Return a snapshot of the current model/tokenizer/CUDA state."""
        with self._lock:
            precision = self._get_precision_setting()
            status = ModelStatus(
                model_loaded=self._model is not None,
                tokenizer_loaded=self._tokenizer is not None,
                loading=self._loading,
                model_id=MODEL_ID,
                dtype=precision,
            )
            try:
                import torch
                status.cuda_available = torch.cuda.is_available()
                if status.cuda_available:
                    status.gpu_name = torch.cuda.get_device_name(0)
                    status.gpu_count = torch.cuda.device_count()
                    props = torch.cuda.get_device_properties(0)
                    status.vram_total_mb = props.total_memory / (1024 * 1024)
                    if self._device == "cuda":
                        status.vram_used_mb = (
                            torch.cuda.memory_allocated(0) / (1024 * 1024)
                        )
            except ImportError:
                status.cuda_available = False
            return status

    # ------------------------------------------------------------------
    # Access (read-only - used by GenerationManager)
    # ------------------------------------------------------------------
    def get_model_and_tokenizer(self) -> Tuple:
        """Return (model, tokenizer), raising if not loaded.

        Only the GenerationManager should call this - it is the only other
        component that needs to touch the model, and it only calls
        generate_speech(), never modifying model state.
        """
        with self._lock:
            if self._model is None or self._tokenizer is None:
                raise ModelNotLoaded(
                    "The model is not loaded yet.",
                    "Wait for the model to finish loading, then try again.",
                )
            return self._model, self._tokenizer

    @property
    def is_loaded(self) -> bool:
        with self._lock:
            return self._model is not None and self._tokenizer is not None

    @property
    def device(self) -> Optional[str]:
        with self._lock:
            return self._device

    @property
    def sample_rate(self) -> int:
        """Return the model's output sample rate (24 kHz for Higgs V3)."""
        return HIGGS_SAMPLE_RATE

    # ------------------------------------------------------------------
    # Precision helpers
    # ------------------------------------------------------------------
    def _get_precision_setting(self) -> str:
        """Read the model_precision setting from SettingsManager."""
        if self._settings is None:
            return DEFAULT_MODEL_DTYPE
        try:
            precision = self._settings.get("performance", "model_precision",
                                           DEFAULT_MODEL_DTYPE)
            if precision not in _DTYPE_MAP:
                logger.warning("Unknown model_precision '%s', using default '%s'",
                               precision, DEFAULT_MODEL_DTYPE)
                return DEFAULT_MODEL_DTYPE
            return precision
        except Exception:
            return DEFAULT_MODEL_DTYPE

    @staticmethod
    def _resolve_dtype(torch_module, precision_str: str):
        """Map a precision string to the corresponding torch dtype object."""
        if precision_str == "float16":
            return torch_module.float16
        elif precision_str == "float32":
            return torch_module.float32
        else:
            return torch_module.bfloat16

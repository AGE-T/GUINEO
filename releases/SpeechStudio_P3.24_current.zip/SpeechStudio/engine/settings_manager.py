"""
SpeechStudio Engine - Settings Manager
=======================================

Engine Specification, section 12:
    "SettingsManager stores: Application settings, Generation defaults,
     Voice defaults, Window layout, Audio preferences.
     Settings are persisted as JSON."

System Specification, section 10:
    "SpeechStudio stores configuration inside the project directory.
     Configuration files shall use JSON format."

AI Development Rules, section 19:
    "Every user configurable option shall be editable through the graphical
     interface. Users shall never edit Python files to change application
     behaviour. Settings are stored as JSON."

Single responsibility: load and save settings.json. Nothing else.
"""

from __future__ import annotations
import os
import json
from typing import Any, Dict, Optional

from engine.logger import get_logger
from engine.models import GenerationParameters

logger = get_logger("settings_manager")


# ---------------------------------------------------------------------------
# Default settings
# ---------------------------------------------------------------------------
# Applied when no settings file exists yet. Every key here has a default so
# the application always has a valid settings state on first launch.
DEFAULT_SETTINGS: Dict[str, Any] = {
    "application": {
        "theme": "modern-dark",
        "developer_mode": False,
        "check_for_model_on_startup": True,
        "current_project": "Default",
        "current_scene": "Untitled",
        "playback_volume": 1.0,
        # First-run flag: False until the demo text has been inserted once.
        # Used by MainWindow to insert the Hungarian demo text on the very
        # first application startup (and only then).
        "first_run_completed": False,
        # Multi-speaker dialogue: maps speaker labels to voice profile IDs.
        # Updated automatically by the LongNarrationDialog (no manual editing).
        # Persists across dialog reopens so the user doesn't have to reassign
        # voices every time they open the Narration dialog.
        "speaker_voice_map": {},
    },
    "generation": GenerationParameters().to_dict(),
    "voice": {
        "default_voice_id": None,
        "auto_validate_reference": True,
    },
    "window": {
        "width": 1280,
        "height": 800,
        "sidebar_width": 440,
        "control_panel_width": 440,
        "sidebar_collapsed": False,
        "control_panel_collapsed": False,
    },
    "audio": {
        "output_directory": "outputs",
        "default_format": "wav",
        "auto_play": True,
        "volume": 1.0,
        # Dialogue concatenation settings (used by concatenate_with_silence).
        "concatenate_silence_ms": 300,
        "concatenate_randomize": True,
    },
    "performance": {
        "keep_model_loaded": True,
        "release_tensors_after_generation": True,
        "model_precision": "bfloat16",
    },
}


class SettingsManager:
    """Loads and saves application settings as JSON.

    The settings file lives at settings/settings.json inside the project
    directory (System Specification section 10). All paths are relative.

    P3.23 FIX (audit: settings split brain / cross-instance overwrite):
    Multiple SettingsManager instances exist in the app (MainWindow,
    Engine, SpeechStudio startup). Previously each instance cached the
    WHOLE file in memory and _save() rewrote the whole file from its own
    cache — so a second instance's save silently reverted keys written
    by the first (proven by the audit: theme reverted to dark). This
    manager now tracks which keys THIS instance has modified (the dirty
    set) and _save() merges ONLY those keys on top of a fresh re-read of
    the disk file — concurrent writes by other instances are preserved.

    Residual limitation (documented, not silently ignored): values READ
    by an instance remain cached until that instance next saves; the
    authoritative state is always on disk. A single shared instance
    remains the recommended future architecture.
    """

    def __init__(self, settings_dir: str):
        self._settings_dir = settings_dir
        self._file_path = os.path.join(settings_dir, "settings.json")
        self._settings: Dict[str, Any] = {}
        # (section, key) tuples set via set() since the last successful
        # save; whole sections set via set_section() are tracked as
        # (section, None).
        self._dirty: set = set()
        self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def _load(self) -> None:
        """Load settings from disk, merging with defaults."""
        if not os.path.isfile(self._file_path):
            logger.info("No settings file found; using defaults.")
            self._settings = _deep_copy(DEFAULT_SETTINGS)
            self._save()
            return
        try:
            with open(self._file_path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            self._settings = _deep_merge(DEFAULT_SETTINGS, loaded)
            logger.info("Settings loaded from %s", self._file_path)
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Failed to load settings: %s", exc)
            logger.info("Falling back to defaults.")
            self._settings = _deep_copy(DEFAULT_SETTINGS)

    def _save(self) -> None:
        """Persist settings to disk (merge-on-write).

        P3.23: re-reads the CURRENT disk file (if any) and merges only
        this instance's dirty keys on top, so concurrent writes made by
        other SettingsManager instances (Engine / startup reader) are
        never silently reverted. After a successful write the in-memory
        cache is refreshed to the merged state.
        """
        os.makedirs(self._settings_dir, exist_ok=True)
        try:
            # 1. Fresh read of the disk state (defaults if unreadable).
            disk: Dict[str, Any] = {}
            if os.path.isfile(self._file_path):
                try:
                    with open(self._file_path, "r", encoding="utf-8") as handle:
                        disk = json.load(handle)
                except (json.JSONDecodeError, OSError) as exc:
                    logger.warning(
                        "Could not re-read settings before save: %s", exc)
                    disk = {}
            merged = _deep_merge(DEFAULT_SETTINGS, disk) \
                if disk else _deep_copy(DEFAULT_SETTINGS)

            # 2. Apply ONLY this instance's modifications.
            for section, key in self._dirty:
                if key is None:
                    # Whole-section replacement (set_section).
                    merged[section] = _deep_copy(
                        self._settings.get(section, {}))
                else:
                    if section not in merged or not isinstance(
                            merged.get(section), dict):
                        merged[section] = {}
                    if section in self._settings and key in \
                            self._settings.get(section, {}):
                        merged[section][key] = _deep_copy(
                            self._settings[section][key])

            # 3. Write the merged state.
            with open(self._file_path, "w", encoding="utf-8") as handle:
                json.dump(merged, handle, indent=2, ensure_ascii=False)

            # 4. Refresh the in-memory cache (now consistent with disk,
            #    including keys other instances wrote since our load).
            self._settings = merged
            self._dirty.clear()
            logger.debug("Settings saved to %s (merge-on-write)",
                         self._file_path)
        except OSError as exc:
            logger.error("Failed to save settings: %s", exc)

    # ------------------------------------------------------------------
    # Access API
    # ------------------------------------------------------------------
    def get(self, section: str, key: Optional[str] = None,
            default: Any = None) -> Any:
        """Read a setting value.

        Args:
            section: top-level key (e.g. "generation", "window").
            key: optional second-level key.
            default: returned if the key is not found.
        """
        section_data = self._settings.get(section, {})
        if key is None:
            return section_data
        return section_data.get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        """Write a setting value and persist immediately."""
        if section not in self._settings:
            self._settings[section] = {}
        self._settings[section][key] = value
        self._dirty.add((section, key))
        self._save()
        logger.debug("Setting updated: %s.%s = %s", section, key, value)

    def set_section(self, section: str, data: Dict[str, Any]) -> None:
        """Replace an entire section and persist."""
        self._settings[section] = data
        self._dirty.add((section, None))
        # Also drop any per-key dirty entries for this section — the whole
        # section is being replaced.
        self._dirty = {(s, k) for (s, k) in self._dirty
                       if s != section or k is None}
        self._dirty.add((section, None))
        self._save()
        logger.debug("Section replaced: %s", section)

    def get_generation_parameters(self) -> GenerationParameters:
        """Return the default generation parameters as a dataclass."""
        data = self._settings.get("generation", {})
        return GenerationParameters.from_dict(data)

    def set_generation_parameters(self, params: GenerationParameters) -> None:
        """Persist generation parameters as the new defaults."""
        self.set_section("generation", params.to_dict())

    @property
    def all_settings(self) -> Dict[str, Any]:
        """Return a deep copy of all settings (for the settings dialog)."""
        return _deep_copy(self._settings)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _deep_copy(obj: Any) -> Any:
    """Deep-copy a JSON-serialisable structure."""
    return json.loads(json.dumps(obj))


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge override into base; base provides defaults.

    Used so that new default keys added in a future version appear
    automatically even when the user's settings file was written by an
    older version.
    """
    result = _deep_copy(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = _deep_copy(value)
    return result

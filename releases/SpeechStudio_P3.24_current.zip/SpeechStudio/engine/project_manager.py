"""
SpeechStudio Engine - Project Manager
=====================================

Manages Project entities: create, load, save, list, delete.

A Project is stored as a directory structure:

    projects/
    └── <project_id>/
        ├── project.json       (Project metadata, characters, scenes)
        ├── scenes/
        │   └── <scene_id>.json
        └── characters/
            └── <character_id>.json

The project.json file contains the full Project.to_dict() including
embedded Scene and Character data. Individual scene/character files
are an optimisation for large projects (not yet implemented — Phase 2+).

Migration:
    Old .sproj files can be imported via import_sproj(path).
    Old .scene.json files can be imported via import_scene_json(path, project_id).
"""

from __future__ import annotations
import os
import json
import time
from typing import List, Optional, Dict, Any

from engine.models import Project, Scene, Character, GenerationParameters
from engine.logger import get_logger

logger = get_logger("project_manager")


class ProjectManager:
    """Manages Project entities on disk.

    Each project is stored as a directory under ``projects/`` containing
    a ``project.json`` file with the full project state.
    """

    PROJECT_FORMAT = "speechstudio-project-v2"
    FORMAT_VERSION = 2

    def __init__(self, projects_dir: str):
        self._dir = projects_dir
        os.makedirs(self._dir, exist_ok=True)

    @property
    def directory(self) -> str:
        return self._dir

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------
    def list_projects(self) -> List[Project]:
        """Return all projects, sorted by modified_at (newest first)."""
        projects = []
        if not os.path.isdir(self._dir):
            return projects
        for name in sorted(os.listdir(self._dir)):
            project_path = os.path.join(self._dir, name, "project.json")
            if not os.path.isfile(project_path):
                continue
            try:
                with open(project_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                project = Project.from_dict(data)
                projects.append(project)
            except Exception as exc:
                logger.warning("Failed to load project %s: %s", name, exc)
        projects.sort(key=lambda p: p.modified_at or p.created_at or "",
                      reverse=True)
        return projects

    def get_project(self, project_id: str) -> Optional[Project]:
        """Load a single project by ID."""
        project_path = os.path.join(self._dir, project_id, "project.json")
        if not os.path.isfile(project_path):
            return None
        try:
            with open(project_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return Project.from_dict(data)
        except Exception as exc:
            logger.error("Failed to load project %s: %s", project_id, exc)
            return None

    def save_project(self, project: Project) -> str:
        """Save a project to disk. Returns the project directory path."""
        if not project.id:
            import uuid
            project.id = str(uuid.uuid4())[:12]

        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        if not project.created_at:
            project.created_at = now
        project.modified_at = now

        # P3.21: Auto-assign sequential sort_order if all scenes have 0
        # (backward compat: old projects get ordered by insertion on first save)
        if project.scenes and all(s.sort_order == 0 for s in project.scenes):
            for i, scene in enumerate(project.scenes):
                scene.sort_order = i

        project_dir = os.path.join(self._dir, project.id)
        os.makedirs(project_dir, exist_ok=True)
        os.makedirs(os.path.join(project_dir, "scenes"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "characters"), exist_ok=True)

        data = {
            "format": self.PROJECT_FORMAT,
            "version": self.FORMAT_VERSION,
            **project.to_dict(),
        }

        project_path = os.path.join(project_dir, "project.json")
        with open(project_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.info("Saved project: %s (%s) with %d scenes, %d characters",
                    project.name, project.id,
                    len(project.scenes), len(project.characters))
        return project_dir

    def delete_project(self, project_id: str) -> bool:
        """Delete a project directory. Returns True if deleted.

        P3.23 (design record §85 — containment checks): project_id is
        untrusted input (it originates from imported project JSON and UI
        selection). A crafted ID containing "../" or an absolute path
        previously allowed rmtree of an ARBITRARY directory on disk.
        The ID must be a single safe path component and the resolved
        directory must remain inside the projects directory.
        """
        import shutil
        # Reject traversal / absolute / malformed project IDs.
        if not project_id or not isinstance(project_id, str):
            return False
        if project_id in (".", ".."):
            return False
        if ("/" in project_id or "\\" in project_id
                or "\x00" in project_id or os.path.isabs(project_id)):
            logger.warning("Rejected unsafe project id for delete: %r",
                           project_id)
            return False
        project_dir = os.path.join(self._dir, project_id)
        # Defence in depth: resolved path must stay inside projects dir.
        base_abs = os.path.abspath(self._dir)
        target_abs = os.path.abspath(project_dir)
        try:
            if os.path.commonpath([base_abs, target_abs]) != base_abs:
                logger.warning(
                    "Rejected project delete outside projects dir: %r",
                    project_id)
                return False
        except ValueError:
            return False
        if not os.path.isdir(project_dir):
            return False
        try:
            shutil.rmtree(project_dir)
            logger.info("Deleted project: %s", project_id)
            return True
        except Exception as exc:
            logger.error("Failed to delete project %s: %s", project_id, exc)
            return False

    # ------------------------------------------------------------------
    # Scene operations
    # ------------------------------------------------------------------
    def save_scene(self, project_id: str, scene: Scene) -> str:
        """Save a scene within a project. Returns the scene file path."""
        if not scene.id:
            import uuid
            scene.id = str(uuid.uuid4())[:12]
        scene.project_id = project_id

        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        if not scene.created_at:
            scene.created_at = now
        scene.modified_at = now

        scene_dir = os.path.join(self._dir, project_id, "scenes")
        os.makedirs(scene_dir, exist_ok=True)
        scene_path = os.path.join(scene_dir, f"{scene.id}.json")

        with open(scene_path, "w", encoding="utf-8") as f:
            json.dump(scene.to_dict(), f, indent=2, ensure_ascii=False)

        logger.info("Saved scene: %s (%s) in project %s",
                    scene.name, scene.id, project_id)
        return scene_path

    def load_scene(self, project_id: str, scene_id: str) -> Optional[Scene]:
        """Load a scene from a project."""
        scene_path = os.path.join(self._dir, project_id, "scenes", f"{scene_id}.json")
        if not os.path.isfile(scene_path):
            return None
        try:
            with open(scene_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return Scene.from_dict(data)
        except Exception as exc:
            logger.error("Failed to load scene %s: %s", scene_id, exc)
            return None

    # ------------------------------------------------------------------
    # Migration / Import
    # ------------------------------------------------------------------
    def import_sproj(self, sproj_path: str) -> Optional[Project]:
        """Import a legacy .sproj file as a new Project.

        Creates a Project with a single Scene containing the editor text
        and generation settings from the .sproj file.

        Args:
            sproj_path: path to the .sproj file.

        Returns:
            The created Project, or None on failure.
        """
        try:
            with open(sproj_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as exc:
            logger.error("Failed to read .sproj file: %s", exc)
            return None

        # Extract fields from legacy .sproj format
        project_name = data.get("project", "Imported Project")
        text = data.get("text", "")
        voice_id = data.get("voice_id")
        emotion = data.get("emotion")
        style = data.get("style")
        speed = data.get("speed", "Normal")
        pitch = data.get("pitch", "Normal")
        delivery = data.get("delivery", "Normal")
        params_data = data.get("parameters", {})
        params = GenerationParameters.from_dict(params_data) if params_data else None

        # Create a Scene from the .sproj content
        scene = Scene(
            name="Scene 01",
            text=text,
            emotion=emotion,
            style=style,
            speed=speed,
            pitch=pitch,
            delivery=delivery,
            parameters=params,
            status="draft",
        )

        # Create the Project
        project = Project(name=project_name)
        project.add_scene(scene)

        # If there's a voice_id, create a Character for it
        if voice_id:
            character = Character(
                name="Narrator",
                voice_profile_id=voice_id,
                role="narrator",
            )
            project.add_character(character)
            scene.character_ids.append(character.id)

        # Save the new project
        self.save_project(project)
        logger.info("Imported .sproj as project: %s (%s)", project.name, project.id)
        return project

    def import_scene_json(self, scene_path: str, project_id: str) -> Optional[Scene]:
        """Import a legacy .scene.json file into an existing project.

        Args:
            scene_path: path to the .scene.json file.
            project_id: the project to import into.

        Returns:
            The created Scene, or None on failure.
        """
        try:
            with open(scene_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as exc:
            logger.error("Failed to read .scene.json file: %s", exc)
            return None

        # Create a Scene from the dialogue scene
        scene_name = data.get("name", "Imported Scene")
        lines = data.get("lines", [])

        # Reconstruct text from dialogue lines
        text_parts = []
        for line in lines:
            speaker = line.get("speaker", "")
            line_text = line.get("text", "")
            if speaker:
                text_parts.append(f"${speaker}:\n{line_text}")
            else:
                text_parts.append(line_text)
        text = "\n\n".join(text_parts)

        scene = Scene(
            name=scene_name,
            project_id=project_id,
            text=text,
            status="draft",
        )

        # Save the scene
        self.save_scene(project_id, scene)
        logger.info("Imported .scene.json as scene: %s (%s)", scene.name, scene.id)
        return scene

    # ------------------------------------------------------------------
    # P3.7: Exported Project Import
    # ------------------------------------------------------------------
    def import_project_dir(self, export_dir: str,
                            new_id: bool = True) -> Optional[Project]:
        """Import an exported Project directory (P3.7 export structure).

        Reads the <export_dir>/project.json + scenes/*/scene.json +
        characters/*/character.json structure produced by ProjectExporter,
        reconstructs the authoritative Project, and saves it as a new
        native project under projects/.

        This is NOT a second import architecture — it reuses the same
        Project.from_dict() / Project.to_dict() model and the same
        save_project() persistence path as native projects.

        Audio assets referenced in scene.json keep their relative paths
        (pointing into the export's scenes/<name>/audio/ folder). These
        paths are preserved as-is so the exported audio is accessible
        relative to the project location. If the user wants the audio
        copied into outputs/, that is a separate concern.

        Args:
            export_dir: path to the exported project root (contains
                        project.json, scenes/, characters/).
            new_id: if True (default), generate a new project ID so the
                    imported project doesn't collide with the original.
                    If False, keep the original ID (use with care).

        Returns:
            The imported Project, or None on failure.
        """
        project_json_path = os.path.join(export_dir, "project.json")
        if not os.path.isfile(project_json_path):
            logger.error("P3.7 import: project.json not found in %s", export_dir)
            return None
        try:
            with open(project_json_path, "r", encoding="utf-8") as f:
                project_data = json.load(f)
        except Exception as exc:
            logger.error("P3.7 import: failed to read project.json: %s", exc)
            return None

        # Reconstruct the Project from the authoritative model
        project = Project.from_dict(project_data)

        # Optionally regenerate the ID to avoid collisions with the original
        if new_id:
            import uuid
            project.id = str(uuid.uuid4())[:12]
            # Re-link scenes to the new project ID
            for scene in project.scenes:
                scene.project_id = project.id

        # The project_data from the export may contain scenes with audio
        # paths relative to the export dir. When we save_project() the
        # native project.json is written — the scene audio_assets keep
        # their relative paths (they point into the export's audio/ dir).
        # This is acceptable: the metadata is preserved, and the audio
        # files are co-located with the scene data.

        # If the export also wrote individual scene.json files, we prefer
        # those (they are the per-scene export). The project.json's scenes
        # list is the authoritative source — individual scene.json files
        # are redundant but kept for human readability.
        scenes_export_dir = os.path.join(export_dir, "scenes")
        if os.path.isdir(scenes_export_dir):
            # The project.json already contains the full scenes data
            # (ProjectExporter writes both). We use the project.json data.
            pass

        # Save as a new native project
        self.save_project(project)
        logger.info("P3.7 import: imported project '%s' (id=%s, %d scenes, %d characters)",
                    project.name, project.id,
                    len(project.scenes), len(project.characters))
        return project

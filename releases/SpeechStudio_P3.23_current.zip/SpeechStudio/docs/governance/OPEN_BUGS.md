# SpeechStudio Open Bugs / Documentation Backlog

This file tracks known issues that have NOT yet been fixed. Each
entry is removed from this file only after the fix is implemented
AND independently verified.

**Status legend:**
- **OPEN** — not yet fixed
- **FIXED-PENDING-VERIFICATION** — fix implemented, awaiting
  independent verification of exact preview/model equality
- **CLOSED** — fixed and independently verified

---

## BUG-001: Advanced Preview emits invalid `expressive_normal` token

- **Status**: FIXED-PENDING-VERIFICATION
- **Severity**: Critical (prompt correctness)
- **Discovered**: Post-FINAL-CORRECTION audit
- **ADR reference**: ADR 003 §7
- **Fix applied**: `engine/prompt_state.py` `compile_continuous()`
  now skips emission of any prosody token when the effective value
  is `"Normal"` or `None` — matching `PromptBuilder.build()` behavior.

### Description

The Advanced Preview (`CanonicalPromptCompiler.compile_continuous()`)
and the center Preview (`CanonicalPromptCompiler.compile_for_generate()`
→ `PromptBuilder.build()`) did not produce identical token sequences.

`compile_continuous()` could emit:

```
<|prosody:expressive_normal|>
```

while the center Preview correctly produced NO token for "Normal"
delivery. The same issue applied to `speed_normal` and `pitch_normal`.

### Root Cause

1. `engine/higgs_tokens.py` defines placeholder
   `ProsodyDef("Normal", "expressive_normal", ...)` entries. These
   are application-level "no-op" markers — NOT valid HIGGS V3 tokens.

2. The official HIGGS V3 reference defines only:
   - Speed: `speed_very_slow`, `speed_slow`, `speed_fast`, `speed_very_fast`
   - Pitch: `pitch_low`, `pitch_high`
   - Delivery: `expressive_high`, `expressive_low`
   
   There is NO `*_normal` token in HIGGS V3.

3. `PromptBuilder.build()` correctly checked `!= "Normal"` before
   emitting. `compile_continuous()` did NOT — it emitted a token
   whenever the value changed, including to "Normal".

### Fix Applied

`compile_continuous()` (in `engine/prompt_state.py`) now skips
emission for any prosody value that is `"Normal"` or `None`. The
`prev` tracker is reset to `None` when a "Normal" value is
encountered, so that a subsequent non-Normal value correctly emits
(e.g. Normal→High→Normal emits `expressive_high` once for the
middle block, nothing for the first and last).

### Verification Performed

The following tests were run and PASS:

1. **Required test** — 3 blocks with Delivery Normal/Expressive
   High/Normal:
   - Block 1 (Normal) → no expressive token ✓
   - Block 2 (Expressive High) → `<|prosody:expressive_high|>` ✓
   - Block 3 (Normal) → no `expressive_normal` token ✓

2. **Expanded test** — Speed Normal, Pitch Normal, Delivery Normal
   individually and combined:
   - None produces a HIGGS token ✓
   - No `*_normal` token in any output ✓

3. **Preview Hard Contract** — Center Preview vs Advanced Preview
   for 10 different configurations (emotion, style, speed, pitch,
   delivery, all-Normal, all-non-Normal):
   - All 10 produce IDENTICAL prompt strings (exact match) ✓
   - No `*_normal` tokens in any path ✓

### Why Status is FIXED-PENDING-VERIFICATION (not CLOSED)

Per the user's directive: "Until exact preview/model equality is
independently demonstrated, BUG-001 remains OPEN."

The fix is implemented and the automated tests pass, but the status
remains FIXED-PENDING-VERIFICATION until an independent audit
confirms that:
1. The exact final prompt string is identical across Center Preview,
   Advanced Preview, and the actual model input.
2. No `*_normal` token reaches the model in any code path.
3. The fix survives a real generation test (not just unit tests).

An independent reviewer should re-run the tests above and additionally
verify the model input path end-to-end before marking this CLOSED.

### Related Files

- `engine/prompt_state.py` — `compile_continuous()` (fixed)
- `engine/prompt_builder.py` — `build()` (reference for correct skip behavior)
- `engine/higgs_tokens.py` — token definitions (see BUG-002)
- `ui/panels/long_narration_dialog.py` — `_on_generate()` (refactored
  to use `CanonicalPromptCompiler` instead of direct `PromptBuilder`;
  removed the `<|` hybrid shortcut)

---

## BUG-002: `expressive_normal` / `speed_normal` / `pitch_normal` are not valid HIGGS V3 tokens

- **Status**: OPEN (partially mitigated by BUG-001 fix)
- **Severity**: Medium (documentation / catalog accuracy)
- **Related**: BUG-001

### Description

`engine/higgs_tokens.py` defines three "Normal" prosody tokens that
do NOT exist in the official HIGGS V3 reference:

| Application token       | Tag               | HIGGS V3? |
|-------------------------|-------------------|-----------|
| `ProsodyDef("Normal", "speed_normal", ...)` | `speed_normal` | ❌ NOT in reference |
| `ProsodyDef("Normal", "pitch_normal", ...)` | `pitch_normal` | ❌ NOT in reference |
| `ProsodyDef("Normal", "expressive_normal", ...)` | `expressive_normal` | ❌ NOT in reference |

### Current Mitigation

BUG-001's fix ensures these tags are never emitted by
`compile_continuous()`. `PromptBuilder.build()` already skipped them.
So no `*_normal` token reaches the model.

### Remaining Work

The placeholders still exist in `higgs_tokens.py` and are referenced
in the in-app Token Guide (`ui/panels/token_guide.py`). They should
be either:
1. Marked as `application_only=True` (non-emittable), OR
2. Removed from the token catalogue and represented differently in
   the UI (e.g. a "Default" option that maps to `None`).

The Token Guide must be corrected to not list them as valid HIGGS V3
tokens.

### Verification

After the fix:
1. `grep -rn "expressive_normal\|speed_normal\|pitch_normal" engine/`
   must return no matches in token-emitting code paths.
2. The Token Guide must not list these as valid HIGGS V3 tokens.
3. All verification scripts must pass.

---

## BUG-003: Prompt Pipeline Contract is not a standalone document

- **Status**: OPEN
- **Severity**: Low (documentation gap)
- **ADR reference**: ADR 003 §10

### Description

The Prompt Pipeline Contract is referenced in the codebase
(`engine/prompt_state.py`, `ui/main_window.py`,
`ui/panels/narration_editor.py`) as the authoritative specification
for the prompt pipeline. However, the contract is currently embedded
in code comments and docstrings — there is no standalone document.

### Required Fix

Extract the contract into a standalone document:
`docs/governance/PROMPT_PIPELINE_CONTRACT.md`.

The document must explicitly distinguish:
- **Application semantics** (SpeechStudio's scope rules, precedence,
  ownership model) — these are SpeechStudio decisions.
- **HIGGS V3 model semantics** (token syntax, placement rules,
  token catalogue) — these are defined by the model, not by
  SpeechStudio.

### Verification

After the fix:
1. `docs/governance/PROMPT_PIPELINE_CONTRACT.md` exists.
2. The contract is referenced from ADR 003 and the governance README.
3. The contract clearly distinguishes application semantics from
   HIGGS V3 model semantics.

---

## BUG-004: SemanticTokenState flattens sentence-scoped tokens to one global value

- **Status**: OPEN (architectural limitation — not a regression)
- **Severity**: Low (UI workflow removed — no current user impact)
- **ADR reference**: ADR 003 §3, §8
- **Do not refactor yet** — this is documented for future planning.

### Description

`SemanticTokenState` (in `engine/prompt_state.py`) flattens all
parsed tokens to a SINGLE value per category:

```python
@dataclass
class SemanticTokenState:
    emotion: Optional[str] = None    # ONE emotion, not per-sentence
    style: Optional[str] = None      # ONE style, not per-sentence
    speed: Optional[str] = None
    pitch: Optional[str] = None
    delivery: Optional[str] = None
    ...
```

Meanwhile, `ParsedToken` already tracks `sentence_identity` and
`block_identity`:

```python
@dataclass
class ParsedToken:
    category: str
    tag: str
    offset: int
    raw: str
    placement: str = "sentence_level"
    sentence_identity: int = 0
    block_identity: Optional[str] = None
    source: str = "manual_import"
```

So the parser knows WHICH sentence/block a token belongs to, but the
state object discards that information and keeps only the last value
of each category.

### Impact

- Multiple sentence-scoped token states CANNOT coexist correctly
  inside the same document when using inline `<|...|>` tokens (the
  SemanticTokenState path).
- Example: if the user writes
  `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
  the state will have `emotion = "Awe"` (the last value wins) — the
  fear emotion for sentence one is lost.

### Current Mitigation — UI Workflow Removed

The Read Tokens UI workflow (which was the only consumer of
`SemanticTokenState`) has been **REMOVED** from the application:

- The "Read Tokens" button has been removed from the NarrationEditor
  mode bar.
- The `read_tokens_requested` signal has been removed.
- The `_on_read_tokens()` handler has been removed from MainWindow.
- The `self._token_state` instance variable has been removed from
  MainWindow. `token_state=None` is now always passed to the
  compiler.
- All "PROMPT OUT OF SYNC" stale-state checks have been removed.
- All "imported token state" UI text has been removed.

The `SemanticTokenState` and `SemanticTokenParser` classes still
exist in `engine/prompt_state.py` for engine-level API compatibility,
but they are no longer used by any UI workflow.

### No Current User Impact

This limitation does NOT affect any current user workflow:

1. **Managed Mode with Narration Blocks** — per-block overrides are
   stored on each `PromptBlock` object (NOT in `SemanticTokenState`).
   The continuous compiler (`compile_continuous`) resolves each block
   independently. Multiple block-scoped emotions/styles/prosody values
   DO coexist correctly. **Verified by regression test (see below).**

2. **Raw Mode** — the user writes literal tokens in the text. No
   parsing into `SemanticTokenState` occurs. Each token stays at its
   exact position in the text. Multiple sentence-scoped tokens
   coexist correctly by definition.

3. **Managed Mode without blocks** — only global defaults apply. There
   is only one emotion/style/prosody value per generation. No
   coexistence issue.

### Regression Test Performed

The following test verifies that Narration Blocks (the primary
multi-scope workflow) preserves per-block token states correctly:

1. **Block 1 Emotion=Fear, Block 2 Emotion=Awe**:
   - Result: `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
   - Both emotions present at correct boundaries ✓

2. **Block 1 Style=Whispering, Block 2 Style=Singing**:
   - Result: `<|style:whispering|>Sentence one. <|style:singing|>Sentence two.`
   - Both styles present at correct boundaries ✓

3. **Block 1 Pitch=Low, Block 2 Pitch=High**:
   - Result: `<|prosody:pitch_low|>Sentence one. <|prosody:pitch_high|>Sentence two.`
   - Both pitches present at correct boundaries ✓

4. **Combined (Fear+Whispering+Low / Awe+Singing+High)**:
   - All 6 tokens present, block boundaries respected ✓

The SemanticTokenState flattening was also tested and confirmed:
parsing `<|emotion:fear|>Sentence one. <|emotion:awe|>Sentence two.`
produces `state.emotion = "Awe"` (last value wins). This is the
documented limitation — but since the UI workflow that used this
path has been removed, there is no user impact.

### Future Refactor (NOT now)

If the Read Tokens workflow is ever reintroduced (which is explicitly
NOT the current UX per ADR 003 §8), `SemanticTokenState` should be
refactored to store per-sentence (or per-block) state instead of a
single flattened value. The `ParsedToken.sentence_identity` and
`block_identity` fields are already in place to support this.

Until then, this is documented as a known architectural limitation
with NO current user impact.

---

## P3.23 DEFECT FIX REGISTER (from the independent security/reliability audit)

The independent audit (SpeechStudio_AUDIT_REPORT.md, verdict: NOT RELEASE
READY) found 54 defects in the pre-P3.21 build. P3.23 re-verified each
headline finding against the P3.22/P3.23 build and fixed the following.
Each fix is covered by runtime tests in `tests/test_p3_23_regression_fixes.py`.

### AUDIT-THR-1 (was CRITICAL): thread affinity — HISTORY_UPDATED
- **Status**: CLOSED (P3.23)
- Engine emits HISTORY_UPDATED on the worker thread; the MainWindow handler
  touched widgets directly. The handler now emits `_history_changed_signal`
  (a Qt signal) — Qt queues cross-thread emissions onto the UI thread.

### AUDIT-UX-1/2: F11 and Esc completely dead ("Ambiguous shortcut overload")
- **Status**: CLOSED (P3.23)
- Both a hidden-menubar QAction AND a standalone QShortcut were registered
  for F11 and Esc — Qt disabled both. The duplicate QShortcuts were removed;
  the QAction shortcuts were promoted to ApplicationShortcut context.
  Runtime test: QTest F11 keyClick now toggles fullscreen (previously dead).

### AUDIT-UX-3: Settings dialog opened twice
- **Status**: CLOSED (P3.23)
- Duplicate `connect("settings", ...)` registration removed (was two slots
  → two dialogs). Runtime test counts exactly one dialog instantiation.

### AUDIT-DATA-1: Settings split brain (cross-instance overwrite)
- **Status**: MITIGATED (P3.23)
- SettingsManager now merges-on-write: it re-reads the disk file and applies
  only its own dirty keys, so a second instance's save no longer reverts
  the first instance's keys (the audit's proven theme-revert scenario).
  RESIDUAL (known, documented): values READ by an instance stay cached
  until that instance next saves; a single shared SettingsManager remains
  the recommended future architecture.

### AUDIT-SEC-1/2: history delete + project delete path traversal
- **Status**: CLOSED (P3.23)
- HistoryManager.delete validates the entry ID (single safe component) and
  containment within the history dir; the audio delete is containment-
  checked against the app root. ProjectManager.delete_project validates the
  project ID and containment within the projects dir (no arbitrary rmtree).

### AUDIT-API-1: Voice import API drift (AttributeError)
- **Status**: CLOSED (P3.23)
- Engine.import_voice_avatar / Engine.set_voice_speaker_metadata now exist
  and are functional (VoiceManager.import_avatar copies the image into the
  profile + records preview_image; set_speaker_metadata persists
  gender/age_range/mood on VoiceProfile). Voice import no longer fails
  whenever an avatar or speaker metadata is provided.

### Still open from the audit (NOT fixed in P3.23 — reported, not ignored):
- **AUDIT-ARCH-1** (LOW/MEDIUM): startup writes settings/build.json/logs
  into the source tree via module-relative APP_ROOT (architectural;
  requires an approved app-data redirection decision).
- **AUDIT-UX-4** (MEDIUM): "Font Status..." unreachable in TopNav Help
  menu (native menubar hidden).
- **AUDIT-UX-5** (MEDIUM): TopNav Export button opens Voice Library export
  (tooltip says "Export Audio").
- **AUDIT-THEME-1** (MEDIUM): Token Guide colors frozen at import.
- Various LOW stale-doc/dead-code items (legacy sidebar, modern_control_panel,
  feature registry F-703, README theme count).

### P3.23 CRITICAL (found + fixed during the Character/Assembly stage):
- **P3.23-CRIT-1**: Combined Audio assembly used Python's `wave` module,
  which CANNOT read the float32 (IEEE format 3) WAV files the Higgs
  pipeline actually writes — assembly failed on every REAL generated file
  (`wave.Error: unknown format: 3`). Existing tests passed only because
  they created PCM16 fixtures with the same `wave` module (fixture
  blindness). Rewritten with soundfile (float32-safe); combined output is
  24 kHz mono float WAV. Runtime tests use REAL float32 fixtures.
- **P3.23-HIGH-1**: Re-detect / Split / Merge silently DROPPED Character
  assignments (explicit design-record §25 violation). Fixed with
  similarity-based transfer + lost_character_id recovery (never silent).
- **P3.23-HIGH-2**: Multi-speaker ($SPEAKER) path ignored block Characters
  — the speaker map could override an explicit Character assignment
  (design-record §19 violation). Fixed: character_id propagates from the
  overlapping block to every SplitPart; the speaker map is only consulted
  when the Character resolves no voice.
---

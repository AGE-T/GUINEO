"""
SpeechStudio — Project/Scene Sidebar
=====================================

New Sidebar widget matching the HTML reference structure:

    [New Project]           (orange gradient CTA)
    
    [folder_open] Projects  (active by default)
    [movie_edit]  Scenes
    [groups]      Characters
    
    RECENT SCENES          [+]
    ┌ 02 Airlock          ← active (purple left border)
    │ 01 Landing
    │ 03 Corridor

The legacy Voice Library, History, Presets, and Outputs functionality
is preserved as separate signals — MainWindow can connect them to
dialogs or menus. The visible Sidebar only shows the HTML structure.

Architecture:
    - Custom QWidget with QVBoxLayout
    - New Project button (orange gradient)
    - Navigation items (Projects, Scenes, Characters) — custom NavItemButton
    - Recent Scenes section (header + add button + scrollable list)
    - Scene rows (custom SceneRowWidget with active/inactive states)

API (compatible with legacy Sidebar):
    - set_project(name)          — updates the project context
    - set_scenes(scenes)         — replaces the scene list
    - set_active_scene(scene_id) — highlights the active scene row
    - update_voices(voices)      — legacy: stores voices for dialog access
    - update_history(entries)    — legacy: stores history for dialog access
    - update_presets(presets)    — legacy: stores presets for dialog access
    - update_outputs(files)      — legacy: stores outputs for dialog access

Signals (compatible with legacy Sidebar):
    - new_project_requested     — user clicked New Project
    - new_scene_requested       — user clicked the + next to Recent Scenes
    - scene_selected(scene_id)  — user clicked a scene row
    - voice_selected(voice_id)   — legacy: emitted by voice dialog
    - (other legacy signals preserved)
"""

from __future__ import annotations
from typing import Optional, List

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QFont, QPixmap, QPainter, QIcon, QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QToolButton, QScrollArea, QFrame, QSizePolicy, QListWidget,
    QListWidgetItem,
)

from ui.typography import (
    Typography, IconSize, IconColor, make_icon,
    SVG_ADD,
)
from ui.icon_registry import IconRegistry


# Additional SVG icons for Library section
SVG_RECORD_VOICE_OVER = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 9c0-1.66 1.34-3 3-3s3 1.34 3 3-1.34 3-3 3-3-1.34-3-3zM3 19c0-3.31 5.37-6 9-6 1.61 0 3.11.42 4.35 1.15C14.87 14.71 14 16.23 14 18c0 .69.12 1.35.34 1.97C13.29 20.62 12.04 21 9 21c-3.63 0-9-2.69-9-6zm17.7-4.41l-1.41 1.41-2.79-2.79-2.79 2.79-1.41-1.41 2.79-2.79L12.3 9.7l1.41-1.41 2.79 2.79 2.79-2.79 1.41 1.41-2.79 2.79 2.79 2.79z"/></svg>'
SVG_HISTORY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>'
SVG_TUNE = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"/></svg>'
SVG_FOLDER_SPECIAL = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 6h-8l-2-2H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-4.6 11l-2.4-1.44L10.6 17l.63-2.73L9 12.76l2.79-.06L13 10l1.21 2.7 2.79.06-2.23 1.51.63 2.73z"/></svg>'
SVG_OUTPUT = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>'


class _NavItemButton(QWidget):
    """A navigation item button with icon + label.

    Uses icon_registry (bundled Material Symbols Outlined SVGs) for
    canonical Google Material icons — NOT inline SVG strings or Unicode.

    Active state: raised dark bg, purple text, filled icon.
    Inactive: transparent bg, secondary text, outline icon.
    Hover: subtle surface change.

    Icon size: 24px (matching the reference HTML's Material Symbols
    default opsz). Container: 32x32 for comfortable touch target.
    """

    clicked_signal = Signal(str)  # emits the label text

    def __init__(self, label: str, icon_name: str, parent=None):
        super().__init__(parent)
        # CRITICAL: WA_StyledBackground makes QWidget paint its own stylesheet
        # background. Without this, the background-color in the stylesheet is
        # ignored and the nav item appears to have no selection background —
        # only the child labels' styles are visible, making the selection
        # look "too small" (just around the icon/text instead of the full row).
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._label_text = label
        self._icon_name = icon_name
        self._is_active = False
        self._is_hovered = False
        # Row height 48px matches the reference HTML's py-3 (12px top + 12px
        # bottom padding) + 24px icon = 48px row.
        self.setFixedHeight(48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

        layout = QHBoxLayout(self)
        # Left margin 16px (reference px-4), top/bottom 0 (height is fixed).
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(12)

        # Icon: use IconRegistry (loads bundled Material Symbols SVGs
        # from assets/icons/). 24px matches the reference default size.
        self._icon_label = QLabel()
        icon = IconRegistry.icon(icon_name, size=24, color=IconColor.SECONDARY)
        if icon and not icon.isNull():
            self._icon_label.setPixmap(icon.pixmap(QSize(24, 24)))
        self._icon_label.setFixedSize(32, 32)
        layout.addWidget(self._icon_label)

        self._text_label = QLabel(label)
        self._text_label.setFont(Typography.body_lg())  # 16px for readability (reference text-sm=14px is too small for desktop)
        layout.addWidget(self._text_label)
        layout.addStretch()

        self._update_style()

    def _update_style(self):
        if self._is_active:
            # Reference: bg-surface-container-highest (#353534) + text-primary (#d0bcff) + font-semibold + fill icon
            self.setStyleSheet("""
                background-color: #353534;
                border-radius: 8px;
            """)
            self._text_label.setStyleSheet("color: #d0bcff; font-weight: 600;")
            # Re-render icon with filled variant for active state
            icon = IconRegistry.icon(self._icon_name, size=24, color="#d0bcff", filled=True)
            if icon and not icon.isNull():
                self._icon_label.setPixmap(icon.pixmap(QSize(24, 24)))
            self._icon_label.setStyleSheet("color: #d0bcff;")
        elif self._is_hovered:
            self.setStyleSheet("""
                background-color: #2a2a2a;
                border-radius: 8px;
            """)
            self._text_label.setStyleSheet("color: #F5F5F5;")
            # Restore outline icon
            icon = IconRegistry.icon(self._icon_name, size=24, color="#cbc3d7", filled=False)
            if icon and not icon.isNull():
                self._icon_label.setPixmap(icon.pixmap(QSize(24, 24)))
            self._icon_label.setStyleSheet("color: #cbc3d7;")
        else:
            self.setStyleSheet("""
                background-color: transparent;
                border-radius: 8px;
            """)
            # Reference: text-on-surface-variant = #cbc3d7 (not #A0A0A0)
            self._text_label.setStyleSheet("color: #cbc3d7;")
            icon = IconRegistry.icon(self._icon_name, size=24, color="#cbc3d7", filled=False)
            if icon and not icon.isNull():
                self._icon_label.setPixmap(icon.pixmap(QSize(24, 24)))
            self._icon_label.setStyleSheet("color: #cbc3d7;")

    def set_active(self, active: bool):
        self._is_active = active
        self._update_style()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked_signal.emit(self._label_text)

    def enterEvent(self, event):
        self._is_hovered = True
        if not self._is_active:
            self._update_style()

    def leaveEvent(self, event):
        self._is_hovered = False
        if not self._is_active:
            self._update_style()


class _SceneRow(QWidget):
    """A row in the Recents or Context list.

    P3.11 visual cleanup:
      - NO internal IDs (UUIDs) shown — only user-facing names
      - ONE active indicator (single left accent bar, no double border)
      - NO extra right edge line (clean right boundary)
      - Larger status indicator (16px) using Material icons from IconRegistry
      - Long names elided gracefully (status icon stays right-aligned)

    Active: single purple left accent bar (2px), subtle purple-tinted bg.
    Inactive: no border.
    Hover: subtle surface change.
    """

    clicked_signal = Signal(str)  # emits entity_id

    # P3.11: Scene status → icon name + color mapping.
    # Uses the canonical IconRegistry (Material Symbols Outlined SVGs).
    _STATUS_ICONS = {
        "draft":      ("edit", "#6B7280"),         # gray — draft/edit icon
        "ready":      ("check", "#d0bcff"),         # purple — ready check
        "generating": ("schedule", "#F59E0B"),      # amber — in progress
        "complete":   ("check_circle", "#10B981"),  # green — done
        "error":      ("error", "#EF4444"),         # red — error
    }

    def __init__(self, scene_id: str, scene_name: str, parent=None,
                 subtitle: str = "", status: str = "",
                 character_id: str = ""):
        super().__init__(parent)
        # WA_StyledBackground: ensures the stylesheet background-color is
        # actually painted on the widget.
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._scene_id = scene_id
        self._scene_name = scene_name
        self._subtitle = subtitle or ""
        self._status = status or ""
        self._character_id = character_id or ""
        self._is_active = False
        self._is_hovered = False
        # P3.11: taller rows when there's a subtitle (two-line layout)
        if self._subtitle:
            self.setFixedHeight(44)
        else:
            self.setFixedHeight(32)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        layout = QHBoxLayout(self)
        # P3.11: left margin 16px for alignment; right margin 8px.
        # NO border on the layout — the active indicator is painted via
        # the widget stylesheet (single 2px left border, not double).
        layout.setContentsMargins(16, 0, 8, 0)
        layout.setSpacing(6)

        # P3.22 Character Visual Identity: colored dot for character rows.
        # Rendered as a small 8px circle using the character's deterministic
        # color. Only shown when character_id is set.
        self._char_dot = None
        if self._character_id:
            from engine.character_colors import get_character_color
            cc = get_character_color(self._character_id)
            dot = QLabel()
            dot.setFixedSize(10, 10)
            dot.setStyleSheet(
                "background-color: {0}; border-radius: 5px; "
                "border: none;".format(cc.hex_main))
            dot.setToolTip(cc.name)
            layout.addWidget(dot, 0)
            self._char_dot = dot

        # Primary name label — elided to fit available width
        self._label = QLabel(scene_name)
        self._label.setFont(Typography.metadata_sm())
        self._label.setTextFormat(Qt.TextFormat.PlainText)
        self._label.setWordWrap(False)
        self._label.setMinimumWidth(0)
        layout.addWidget(self._label, 1)  # stretches

        # Optional subtitle label (secondary, smaller, muted)
        if self._subtitle:
            sub_label = QLabel(self._subtitle)
            sub_label.setFont(Typography.metadata_sm())
            sub_label.setStyleSheet("color: #6B7280; font-size: 11px;")
            sub_label.setTextFormat(Qt.TextFormat.PlainText)
            sub_label.setWordWrap(False)
            sub_label.setMinimumWidth(0)
            sub_label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
            layout.addWidget(sub_label, 0)
            self._sub_label = sub_label
        else:
            self._sub_label = None

        # P3.11: Status indicator — larger (16px) Material icon from IconRegistry.
        # No frame, no border, no extra line — just a clean icon label.
        self._badge = None
        if self._status and self._status in self._STATUS_ICONS:
            icon_name, color = self._STATUS_ICONS[self._status]
            badge = QLabel()
            badge.setFixedSize(16, 16)
            badge.setAlignment(Qt.Alignment.AlignCenter)
            # Use IconRegistry to get the canonical Material Symbols icon
            icon = IconRegistry.icon(icon_name, size=16, color=color)
            if icon and not icon.isNull():
                badge.setPixmap(icon.pixmap(QSize(16, 16)))
            else:
                # Fallback: larger colored dot if icon not found
                badge.setText("\u25cf")
                badge.setStyleSheet("color: {0}; font-size: 14px;".format(color))
            badge.setToolTip(self._status.upper())
            # P3.11: NO border on the badge — prevents the extra right edge line
            badge.setStyleSheet(badge.styleSheet() + "border: none; background: transparent;")
            layout.addWidget(badge, 0)
            self._badge = badge

        self._update_style()

    def resizeEvent(self, event):
        """P3.6/P3.11: Re-elide text on resize so long names always fit gracefully."""
        super().resizeEvent(event)
        self._elide_text()

    def _elide_text(self):
        """Truncate the primary label text with an ellipsis if it doesn't fit."""
        if not hasattr(self, "_label") or self._label is None:
            return
        from PySide6.QtGui import QFontMetrics
        fm = QFontMetrics(self._label.font())
        # Available width = row width minus margins minus subtitle/badge space
        available = self.width() - 32  # left+right margins
        if self._sub_label is not None:
            available -= self._sub_label.sizeHint().width() + 6
        if self._badge is not None:
            available -= 22  # 16px badge + 6px spacing
        if self._char_dot is not None:
            available -= 16  # 10px dot + 6px spacing
        if available < 40:
            available = 40
        elided = fm.elidedText(self._scene_name, Qt.TextElideMode.ElideRight, available)
        self._label.setText(elided)
        # Update tooltip to show the full name when truncated
        if elided != self._scene_name:
            tip = self._scene_name
            if self._subtitle:
                tip += "  ·  " + self._subtitle
            self.setToolTip(tip)
        elif self._subtitle:
            self.setToolTip(self._subtitle)

    def _update_style(self):
        if self._is_active:
            # P3.11: SINGLE left accent bar (2px). No double border.
            # The old style had border-left on both the widget AND a
            # transparent border creating a visual double line.
            self.setStyleSheet("""
                _SceneRow {
                    background-color: rgba(208, 188, 255, 0.08);
                    border-left: 2px solid #d0bcff;
                    border-right: none;
                    border-top: none;
                    border-bottom: none;
                    border-radius: 0px;
                }
            """)
            self._label.setStyleSheet("color: #d0bcff; font-weight: 600; border: none; background: transparent;")
            if self._sub_label is not None:
                self._sub_label.setStyleSheet(
                    "color: #d0bcff; font-size: 11px; opacity: 0.8; border: none; background: transparent;")
        elif self._is_hovered:
            self.setStyleSheet("""
                _SceneRow {
                    background-color: rgba(53, 53, 52, 0.5);
                    border-left: 2px solid transparent;
                    border-right: none;
                    border-top: none;
                    border-bottom: none;
                    border-radius: 0px;
                }
            """)
            self._label.setStyleSheet("color: #F5F5F5; border: none; background: transparent;")
            if self._sub_label is not None:
                self._sub_label.setStyleSheet("color: #6B7280; font-size: 11px; border: none; background: transparent;")
        else:
            self.setStyleSheet("""
                _SceneRow {
                    background-color: transparent;
                    border-left: 2px solid transparent;
                    border-right: none;
                    border-top: none;
                    border-bottom: none;
                    border-radius: 0px;
                }
            """)
            self._label.setStyleSheet("color: #A0A0A0; border: none; background: transparent;")
            if self._sub_label is not None:
                self._sub_label.setStyleSheet("color: #6B7280; font-size: 11px; border: none; background: transparent;")

    def set_active(self, active: bool):
        self._is_active = active
        self._update_style()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked_signal.emit(self._scene_id)

    def enterEvent(self, event):
        self._is_hovered = True
        if not self._is_active:
            self._update_style()

    def leaveEvent(self, event):
        self._is_hovered = False
        if not self._is_active:
            self._update_style()


class Sidebar(QWidget):
    """New Project/Scene Sidebar matching the HTML reference.

    Replaces the legacy Voice Library / History / Presets / Outputs
    QTabWidget with the HTML structure:
        - New Project button
        - Projects / Scenes / Characters navigation
        - Recent Scenes list

    Legacy Voice/History/Preset/Output functionality is preserved via
    signals — MainWindow can connect them to dialogs.
    """

    # New signals (HTML reference)
    new_project_requested = Signal()
    new_scene_requested = Signal()
    scene_selected = Signal(str)  # scene_id (legacy — for scene list clicks)
    recent_item_clicked = Signal(str, str)  # P3.4: (context, entity_id) — context-aware recents click
    projects_clicked = Signal()
    scenes_clicked = Signal()
    characters_clicked = Signal()
    # P3.9: context-aware "add" signals from the + button. The + button
    # now emits the appropriate signal based on the current primary nav
    # context (Projects/Scenes/Characters). History has no add action.
    add_project_requested = Signal()    # + in Projects context
    add_scene_requested = Signal()      # + in Scenes context
    add_character_requested = Signal()  # + in Characters context
    # Library section signals (legacy functionality preserved)
    voice_library_clicked = Signal()
    history_clicked = Signal()
    presets_clicked = Signal()
    outputs_clicked = Signal()

    # Legacy signals (preserved for MainWindow compatibility)
    voice_selected = Signal(str)
    create_voice_requested = Signal()
    delete_voice_requested = Signal(str)
    export_voice_requested = Signal(str)
    history_entry_selected = Signal(str)
    history_reuse_requested = Signal(str)
    history_delete_requested = Signal(str)
    history_export_requested = Signal(str)
    history_project_changed = Signal(str)
    output_file_selected = Signal(str)
    apply_preset_requested = Signal(str)
    save_preset_requested = Signal()
    delete_preset_requested = Signal(str)
    rename_preset_requested = Signal(str)
    export_preset_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        # CRITICAL: WA_StyledBackground makes QWidget paint its own stylesheet
        # background. Without this, the stylesheet background-color is ignored
        # and the widget appears transparent — the ambient bleeds through.
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setObjectName("ProjectSceneSidebar")
        self.setStyleSheet("""
            QWidget#ProjectSceneSidebar {
                background-color: #1A1A1A;
                border-radius: 12px;
                border: 1px solid #333333;
            }
        """)
        self._scenes: List[dict] = []  # [{id, name, ...}]
        self._active_scene_id: Optional[str] = None
        self._current_project: str = "Default"
        self._current_recents_context: str = "Projects"  # P3.4: tracks which recents list is shown

        # Legacy data storage (for dialog access)
        self._voices = []
        self._history = []
        self._presets = []
        self._outputs = []

        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 16, 12, 16)
        layout.setSpacing(16)

        # ---- New Project button (orange gradient CTA) ----
        self._new_project_btn = QPushButton()
        add_icon = IconRegistry.icon("add", size=IconSize.MD, color=IconColor.WHITE)
        if add_icon and not add_icon.isNull():
            self._new_project_btn.setIcon(add_icon)
            self._new_project_btn.setIconSize(QSize(IconSize.MD, IconSize.MD))
        self._new_project_btn.setText("  New Project")
        self._new_project_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._new_project_btn.setFixedHeight(40)
        # Use Typography token instead of hardcoded font-size.
        self._new_project_btn.setFont(Typography.cta_main())
        self._new_project_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #F97316, stop:1 #EA580C);
                color: #FFFFFF;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
            }
            QPushButton:hover { opacity: 0.9; }
            QPushButton:pressed { opacity: 0.8; }
        """)
        self._new_project_btn.clicked.connect(self.new_project_requested.emit)
        layout.addWidget(self._new_project_btn)

        # ---- Navigation items ----
        self._nav_projects = _NavItemButton("Projects", "folder_open")
        self._nav_projects.set_active(True)  # Projects is active by default
        self._nav_projects.clicked_signal.connect(self._on_nav_clicked)
        layout.addWidget(self._nav_projects)

        self._nav_scenes = _NavItemButton("Scenes", "movie_edit")
        self._nav_scenes.clicked_signal.connect(self._on_nav_clicked)
        layout.addWidget(self._nav_scenes)

        # P3.5 Final Correction: HISTORY is now a PRIMARY navigation context
        # (not under LIBRARY). Order: PROJECTS, SCENES, HISTORY, CHARACTERS.
        self._nav_history = _NavItemButton("History", "schedule")
        self._nav_history.clicked_signal.connect(self._on_nav_clicked)
        layout.addWidget(self._nav_history)

        self._nav_characters = _NavItemButton("Characters", "groups")
        self._nav_characters.clicked_signal.connect(self._on_nav_clicked)
        layout.addWidget(self._nav_characters)

        # ---- Recent Scenes section ----
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(8)

        header_label = QLabel("RECENT PROJECTS")
        header_label.setFont(Typography.label_caps())
        header_label.setStyleSheet(
            "color: #A0A0A0; letter-spacing: 0.5px;")
        self._recents_header_label = header_label  # P3.4: renamed for context switching
        header_layout.addWidget(header_label)
        header_layout.addStretch()

        # Add scene button (+ icon)
        self._add_scene_btn = QToolButton()
        add_icon_small = IconRegistry.icon("add", size=IconSize.SM, color=IconColor.SECONDARY)
        if add_icon_small and not add_icon_small.isNull():
            self._add_scene_btn.setIcon(add_icon_small)
            self._add_scene_btn.setIconSize(QSize(IconSize.SM, IconSize.SM))
        else:
            self._add_scene_btn.setText("+")
        self._add_scene_btn.setFixedSize(28, 28)
        self._add_scene_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._add_scene_btn.setStyleSheet("""
            QToolButton {
                background-color: transparent;
                border: none;
                color: #A0A0A0;
                border-radius: 4px;
            }
            QToolButton:hover {
                color: #d0bcff;
                background-color: #2E2E2E;
            }
        """)
        self._add_scene_btn.setToolTip("New Scene")
        # P3.9: The + button is now context-aware. Instead of always
        # emitting new_scene_requested, it calls _on_add_button_clicked
        # which dispatches to the correct signal based on the current
        # primary nav context (Projects/Scenes/Characters). For History,
        # the button is hidden (no creation action).
        self._add_scene_btn.clicked.connect(self._on_add_button_clicked)
        header_layout.addWidget(self._add_scene_btn)

        layout.addLayout(header_layout)

        # ---- Recents list (compact, max 5 items, independently scrollable) ----
        # P3.6: Recents is now COMPACT — it has a maximum height so it never
        # consumes the whole sidebar. The Context List below takes the
        # remaining vertical space. Recents remains independently scrollable
        # in case the 5 items + heading exceed the compact height.
        self._scene_scroll = QScrollArea()
        self._scene_scroll.setWidgetResizable(True)
        self._scene_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._scene_scroll.setStyleSheet("background: transparent;")
        self._scene_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        # P3.6: compact height — 5 rows × 32px + heading ≈ 200px max
        self._scene_scroll.setMaximumHeight(210)
        self._scene_scroll.setMinimumHeight(60)

        self._scene_container = QWidget()
        self._scene_container.setStyleSheet("background: transparent;")
        self._scene_list_layout = QVBoxLayout(self._scene_container)
        self._scene_list_layout.setContentsMargins(0, 0, 0, 0)
        self._scene_list_layout.setSpacing(2)
        self._scene_list_layout.addStretch()

        self._scene_scroll.setWidget(self._scene_container)
        layout.addWidget(self._scene_scroll, 0)  # does NOT stretch

        # ---- Placeholder for empty scene list ----
        self._empty_label = QLabel("No scenes yet")
        self._empty_label.setFont(Typography.metadata_sm())
        self._empty_label.setStyleSheet("color: #555555; padding: 8px 16px;")
        self._scene_list_layout.insertWidget(0, self._empty_label)

        # ---- P3.5/P3.6: Full Context List (takes remaining vertical space) ----
        # A second scrollable area that shows ALL items for the current
        # context (all Projects, all Scenes, all Characters, or all History).
        # This is separate from Recents (max 5 MRU) — it shows the
        # complete authoritative dataset.
        # P3.6: removed setMaximumHeight(200) — the context list now stretches
        # to fill the remaining sidebar height (stretch factor 1).
        ctx_header = QLabel("ALL ITEMS")
        ctx_header.setFont(Typography.label_caps())
        ctx_header.setStyleSheet(
            "color: #A0A0A0; letter-spacing: 0.5px; margin-top: 8px;")
        self._context_header_label = ctx_header
        layout.addWidget(ctx_header)

        self._context_scroll = QScrollArea()
        self._context_scroll.setWidgetResizable(True)
        self._context_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._context_scroll.setStyleSheet("background: transparent;")
        self._context_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._context_scroll.setMinimumHeight(120)  # always usable

        self._context_container = QWidget()
        self._context_container.setStyleSheet("background: transparent;")
        self._context_list_layout = QVBoxLayout(self._context_container)
        self._context_list_layout.setContentsMargins(0, 0, 0, 0)
        self._context_list_layout.setSpacing(2)
        self._context_list_layout.addStretch()

        self._context_scroll.setWidget(self._context_container)
        layout.addWidget(self._context_scroll, 1)  # P3.6: STRETCHES to fill

        # Context list empty state
        self._context_empty_label = QLabel("No items")
        self._context_empty_label.setFont(Typography.metadata_sm())
        self._context_empty_label.setStyleSheet("color: #555555; padding: 8px 16px;")
        self._context_list_layout.insertWidget(0, self._context_empty_label)

        # ---- P3.6: LIBRARY section REMOVED ----
        # The legacy LIBRARY section (Voice Library, Presets, Outputs) has
        # been removed from the sidebar. All three functionalities are
        # preserved and now have permanent homes:
        #   - Voice Library → Tools menu (Ctrl+L) + TopNav "Project" menu +
        #                     Control panel "Change Voice" button
        #   - Presets       → Tools menu "Preset Manager..." + TopNav "Project" menu
        #   - Outputs       → Tools menu "Open Output Folder" + TopNav "Project" menu
        # The sidebar now contains ONLY: New Project, Primary Navigation,
        # Recents, and the full Context List — no duplication with the top
        # navigation menus.
        # The old _nav_voices / _nav_presets / _nav_outputs attributes are
        # kept as None so any legacy references don't crash, but they are
        # no longer created or added to the layout.
        self._nav_voices = None
        self._nav_presets = None
        self._nav_outputs = None

    def _on_nav_clicked(self, label: str) -> None:
        """Handle primary navigation item clicks.

        P3.5 Final Correction: HISTORY is now a primary context alongside
        Projects, Scenes, and Characters. The four primary contexts are
        exclusive — clicking one deactivates the others.

        P3.6: The LIBRARY section has been removed, so there are no longer
        any library items to deactivate. The _nav_voices/_nav_presets/
        _nav_outputs attributes are None — guarded with hasattr checks.

        Emits the corresponding *_clicked signal so MainWindow can update
        the Recents + Context List for the new context.
        """
        # Update active state — only primary nav items are exclusive.
        # P3.5 Final Correction: History is now in this set.
        self._nav_projects.set_active(label == "Projects")
        self._nav_scenes.set_active(label == "Scenes")
        self._nav_history.set_active(label == "History")
        self._nav_characters.set_active(label == "Characters")
        # P3.6: Library items removed — no deactivation needed (they're None).

        # P3.10 FIX: Update _current_recents_context IMMEDIATELY when the
        # nav button is clicked. Previously this was only updated in
        # set_recents() (which is called later by MainWindow). This caused
        # the + button dispatcher (_on_add_button_clicked) to read the OLD
        # context and emit the wrong signal (always New Scene).
        self._current_recents_context = label

        # P3.4: Update the Recents heading based on context
        # (this also calls _update_add_button_for_context)
        self._update_recents_heading(label)

        if label == "Projects":
            self.projects_clicked.emit()
        elif label == "Scenes":
            self.scenes_clicked.emit()
        elif label == "History":
            # P3.5 Final Correction: History nav click switches the context
            # to show the full History list. It does NOT open the HistoryView
            # dialog — the dialog opens when a History ENTRY is clicked.
            # The menu bar / toolbar History action still opens the dialog.
            self.history_clicked.emit()
        elif label == "Characters":
            self.characters_clicked.emit()

    def _on_add_button_clicked(self) -> None:
        """P3.9: Context-aware + button click handler.

        Dispatches to the correct creation signal based on the current
        primary nav context:
          - Projects  → add_project_requested
          - Scenes    → add_scene_requested
          - Characters → add_character_requested
          - History   → no action (button should be hidden)
        """
        ctx = self._current_recents_context
        if ctx == "Projects":
            self.add_project_requested.emit()
        elif ctx == "Scenes":
            self.add_scene_requested.emit()
        elif ctx == "Characters":
            self.add_character_requested.emit()
        elif ctx == "History":
            # No creation action for History — button should be hidden.
            pass

    def _update_add_button_for_context(self, context: str) -> None:
        """P3.9: Update the + button tooltip + visibility for the context.

        Projects  → "Add Project" (visible)
        Scenes    → "Add Scene" (visible)
        Characters → "Add Character" (visible)
        History   → hidden (no creation action)
        """
        if not hasattr(self, "_add_scene_btn") or self._add_scene_btn is None:
            return
        tooltips = {
            "Projects": "Add Project",
            "Scenes": "Add Scene",
            "Characters": "Add Character",
        }
        if context in tooltips:
            self._add_scene_btn.setVisible(True)
            self._add_scene_btn.setEnabled(True)
            self._add_scene_btn.setToolTip(tooltips[context])
        else:
            # History or unknown — hide the button
            self._add_scene_btn.setVisible(False)

    def _update_recents_heading(self, context: str) -> None:
        """P3.4/P3.5/P3.9: Update the Recents + Context List headings based on context.

        P3.9: Also updates the + button tooltip/visibility for the context.
        """
        headings = {
            "Projects": "RECENT PROJECTS",
            "Scenes": "RECENT SCENES",
            "Characters": "RECENT CHARACTERS",
            "History": "RECENT AUDIO",
        }
        heading_text = headings.get(context, "RECENTS")
        if hasattr(self, "_recents_header_label"):
            self._recents_header_label.setText(heading_text)
        # P3.5: Update the context list header
        ctx_headers = {
            "Projects": "ALL PROJECTS",
            "Scenes": "ALL SCENES",
            "Characters": "ALL CHARACTERS",
            "History": "ALL HISTORY",
        }
        ctx_text = ctx_headers.get(context, "ALL ITEMS")
        if hasattr(self, "_context_header_label"):
            self._context_header_label.setText(ctx_text)
        # P3.9: Update the + button for this context
        self._update_add_button_for_context(context)

    def set_context_list(self, entries: list, active_id: Optional[str] = None) -> None:
        """P3.5: Replace the full context list with the given entries.

        Args:
            entries: list of dicts with 'id', 'name', 'subtitle' (optional),
                     'project_id' (optional, for scenes/characters).
            active_id: P3.5 Final Correction — the entity_id of the currently
                       active row (e.g. active project_id, scene_id, or
                       character_id). The matching row is highlighted.
                       Derived from authoritative MainWindow state; never
                       an independent boolean.
        """
        # Clear existing context list rows
        while self._context_list_layout.count() > 1:  # keep the stretch
            item = self._context_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not entries:
            # P3.6: context-specific empty state messages
            empty_messages = {
                "Projects": "No projects yet",
                "Scenes": "No scenes yet",
                "Characters": "No characters yet",
                "History": "No generated audio yet",
            }
            msg = empty_messages.get(self._current_recents_context, "No items")
            self._context_empty_label = QLabel(msg)
            self._context_empty_label.setFont(Typography.metadata_sm())
            self._context_empty_label.setStyleSheet("color: #555555; padding: 8px 16px;")
            self._context_list_layout.insertWidget(0, self._context_empty_label)
            return

        for entry in entries:
            entity_id = entry.get("id", "")
            display_name = entry.get("name", "Unknown")
            subtitle = entry.get("subtitle", "")
            status = entry.get("status", "")  # P3.6: Scene status badge
            # P3.22: Character color dot for character entries
            character_id = entry.get("character_id", "")
            # P3.6: Use the new two-line _SceneRow with subtitle + status badge.
            # The row handles its own text eliding and tooltip.
            row = _SceneRow(entity_id, display_name, self,
                            subtitle=subtitle, status=status,
                            character_id=character_id)
            # P3.5 Final Correction: apply active state derived from
            # authoritative MainWindow state.
            if active_id is not None and entity_id == active_id:
                row.set_active(True)
            # P3.5: Connect to context-aware click signal
            current_context = self._current_recents_context
            row.clicked_signal.connect(
                lambda eid, ctx=current_context: self.recent_item_clicked.emit(ctx, eid))
            self._context_list_layout.insertWidget(self._context_list_layout.count() - 1, row)

    def set_active_context_item(self, entity_id: Optional[str]) -> None:
        """P3.5 Final Correction: Update the active row in the context list.

        Iterates the existing context list rows and sets the active state
        on the row whose entity_id matches. Does NOT rebuild the list —
        this is a lightweight refresh for when the active entity changes
        (e.g. user switches Scene while viewing the Scenes context).

        Active state is derived solely from the entity_id passed in,
        which MainWindow computes from _active_project / _active_scene /
        selected Character. No independent booleans are stored here.

        Args:
            entity_id: the active entity_id, or None to clear active state.
        """
        for i in range(self._context_list_layout.count()):
            item = self._context_list_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), _SceneRow):
                row = item.widget()
                row.set_active(row._scene_id == entity_id)

    def set_recents(self, entries: list, context: str = "") -> None:
        """P3.4: Replace the Recents list with the given entries.

        Args:
            entries: list of dicts with 'id', 'name', 'subtitle' (optional).
            context: the current context name (for heading + click resolution).
        """
        if context:
            self._update_recents_heading(context)
            self._current_recents_context = context

        # Clear existing recents rows
        while self._scene_list_layout.count() > 1:  # keep the stretch
            item = self._scene_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not entries:
            empty = QLabel("No recent items")
            empty.setFont(Typography.metadata_sm())
            empty.setStyleSheet("color: #555555; padding: 8px 16px;")
            self._scene_list_layout.insertWidget(0, empty)
            return

        for entry in entries:
            entity_id = entry.get("id", "")
            display_name = entry.get("name", "Unknown")
            subtitle = entry.get("subtitle", "")  # P3.6: now passed to _SceneRow
            # P3.22: Character color dot for character recents
            character_id = entry.get("character_id", "")
            # P3.6: Use the new _SceneRow with subtitle support.
            row = _SceneRow(entity_id, display_name, self, subtitle=subtitle,
                            character_id=character_id)
            # P3.4: Connect to context-aware recent_item_clicked signal
            # instead of the legacy scene_selected signal.
            current_context = self._current_recents_context
            row.clicked_signal.connect(
                lambda eid, ctx=current_context: self.recent_item_clicked.emit(ctx, eid))
            self._scene_list_layout.insertWidget(self._scene_list_layout.count() - 1, row)

    def _on_library_clicked(self, label: str) -> None:
        """P3.6: Library section has been REMOVED from the sidebar.

        This method is retained for backward compatibility (in case any
        external caller still connects to it), but it is now a no-op —
        the Voice Library, Presets, and Outputs are reached via the
        Tools menu / TopNav "Project" menu instead.

        The signals (voice_library_clicked, presets_clicked, outputs_clicked)
        are still emitted so MainWindow's existing handlers remain connected
        and functional if anything calls this method.
        """
        # Deactivate ALL primary nav items
        self._nav_projects.set_active(False)
        self._nav_scenes.set_active(False)
        self._nav_history.set_active(False)
        self._nav_characters.set_active(False)
        # P3.6: library nav items are None — no set_active calls needed.

        if label == "Voice Library":
            self.voice_library_clicked.emit()
        elif label == "Presets":
            self.presets_clicked.emit()
        elif label == "Outputs":
            self.outputs_clicked.emit()

    # ------------------------------------------------------------------
    # Public API — Scene management
    # ------------------------------------------------------------------
    def set_project(self, project: str) -> None:
        """Set the current project name (updates context)."""
        self._current_project = project

    def set_scenes(self, scenes: List[dict]) -> None:
        """Replace the scene list.

        Args:
            scenes: List of dicts with keys: id, name.
        """
        self._scenes = list(scenes) if scenes else []

        # Clear existing scene rows (but keep the stretch at the end)
        while self._scene_list_layout.count() > 1:
            item = self._scene_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        if not self._scenes:
            self._empty_label = QLabel("No scenes yet")
            self._empty_label.setFont(Typography.metadata_sm())
            self._empty_label.setStyleSheet(
                "color: #555555; padding: 8px 16px;")
            self._scene_list_layout.insertWidget(0, self._empty_label)
        else:
            for scene in self._scenes:
                # P3.6: pass status if available for the status badge
                row = _SceneRow(scene.get("id", ""), scene.get("name", "Untitled"),
                                status=scene.get("status", ""))
                row.clicked_signal.connect(self._on_scene_clicked)
                self._scene_list_layout.insertWidget(
                    self._scene_list_layout.count() - 1, row)

        # Re-apply active scene highlight
        if self._active_scene_id:
            self.set_active_scene(self._active_scene_id)

    def set_active_scene(self, scene_id: str) -> None:
        """Highlight the active scene row."""
        self._active_scene_id = scene_id

        # Update all scene rows
        for i in range(self._scene_list_layout.count()):
            item = self._scene_list_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), _SceneRow):
                row = item.widget()
                row.set_active(row._scene_id == scene_id)

    def _on_scene_clicked(self, scene_id: str) -> None:
        """Handle scene row click."""
        self.scene_selected.emit(scene_id)

    # ------------------------------------------------------------------
    # Legacy API (preserved for MainWindow compatibility)
    # ------------------------------------------------------------------
    def update_voices(self, voices: list) -> None:
        """Legacy: store voice list for dialog access."""
        self._voices = list(voices) if voices else []

    def update_history(self, entries: list) -> None:
        """Legacy: store history for dialog access."""
        self._history = list(entries) if entries else []

    def update_presets(self, presets: list) -> None:
        """Legacy: store presets for dialog access."""
        self._presets = list(presets) if presets else []

    def update_outputs(self, files: list) -> None:
        """Legacy: store outputs for dialog access."""
        self._outputs = list(files) if files else []
